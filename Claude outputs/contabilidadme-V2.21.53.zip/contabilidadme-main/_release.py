#!/usr/bin/env python3
"""Prepara index.html para publicar: versión visible + cache-busting real.

El problema que resuelve
------------------------
index.html carga `js/app.js?v=<epoch>`, pero app.js importa los otros 47 módulos
con rutas estáticas SIN versión. El navegador se queda con la copia vieja de
cada uno: se publica un arreglo en apertura.js y el usuario sigue ejecutando el
de ayer, sin ningún indicio de que algo va mal.

La solución sin build: un import map que apunta cada módulo a su URL con la
versión. Los import maps aceptan especificadores tipo URL, así que `./js/x.js`
dentro de app.js queda redirigido a `./js/x.js?v=<epoch>`.

El mismo problema existe con `css/styles.css`, cargado con un <link> normal
sin import map: se le agrega/renueva su propio `?v=<epoch>` en cada release
(ver paso 1b) para que un cambio de CSS no quede pegado en la caché del
navegador ni en la del service worker.

Uso:  python3 _release.py v2026.08.22-0130
"""
import json,os,re,sys,time

version=sys.argv[1] if len(sys.argv)>1 else 'v'+time.strftime('%Y.%m.%d-%H%M')
epoch=str(int(time.time()))
modulos=sorted(f for f in os.listdir('js') if f.endswith('.js'))

# Versión funcional visible (V2.x.y) tomada de la primera entrada del CHANGELOG.
# Así el login no depende de editar otro valor manualmente al publicar.
release='';
try:
    ch=open('js/changelog.js',encoding='utf-8').read()
    m=re.search(r"\{version:'(V[^']+)'",ch)
    if m: release=m.group(1)
except Exception:
    pass

imports={f'./js/{m}':f'./js/{m}?v={epoch}' for m in modulos}
mapa=('<!-- Cache-busting: sin esto el navegador sirve los módulos viejos aunque\n'
      '     app.js sea nuevo. Lo genera _release.py en cada publicación. -->\n'
      '<script type="importmap">\n'
      +json.dumps({'imports':imports},indent=2,ensure_ascii=False)+
      '\n</script>')

s=open('index.html',encoding='utf-8').read()

# 1. Reemplazar (o insertar) el import map, siempre ANTES del script de app.js
s=re.sub(r'<!-- Cache-busting.*?</script>\n','',s,flags=re.S)
s=re.sub(r'<script type="importmap">.*?</script>\n','',s,flags=re.S)
anc=re.search(r'[ \t]*<script type="module" src="js/app\.js[^"]*"></script>',s)
if not anc: sys.exit('no se encontró el <script> de app.js')
s=s[:anc.start()]+mapa+'\n'+f'<script type="module" src="js/app.js?v={epoch}"></script>'+s[anc.end():]

# 1b. Hoja de estilos: mismo problema que los módulos JS, pero con un <link>
# normal (sin import map). Se le agrega/actualiza el cache-busting a mano.
if re.search(r'<link rel="stylesheet" href="css/styles\.css(\?v=[^"]*)?">', s):
    s=re.sub(r'<link rel="stylesheet" href="css/styles\.css(\?v=[^"]*)?">',
              f'<link rel="stylesheet" href="css/styles.css?v={epoch}">', s)
else:
    sys.exit('no se encontró el <link> de styles.css')

# 2. Versión visible en la barra superior
s=re.sub(r'v20\d\d\.\d\d\.\d\d-\d{4}',version,s)
s=re.sub(r'(<meta name="app-version" content=")[^"]+(">)',r'\1'+version+r'\2',s)
if release:
    if re.search(r'<meta name="app-release" content="[^"]+">',s):
        s=re.sub(r'(<meta name="app-release" content=")[^"]+(">)',r'\1'+release+r'\2',s)
    else:
        s=s.replace('<meta name="app-version" content="'+version+'">','<meta name="app-version" content="'+version+'">\n<meta name="app-release" content="'+release+'">')
    # Texto de la pantalla de login, para que no parpadee una versión antigua
    s=re.sub(r'(<strong id="login-app-release"[^>]*>)Versión [^<]*(</strong>)',r'\1Versión '+release+r'\2',s)

open('index.html','w',encoding='utf-8').write(s)

# 2b. Manifiesto de versión para instalaciones PWA ya abiertas. Se consulta
# con cache:no-store y permite forzar la actualización cuando cambia.
open('version.json','w',encoding='utf-8').write(json.dumps({
    'version':version,'release':release or None,'revision':epoch,'publicadoEn':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
},ensure_ascii=False,indent=2)+'\n')

# 3. Nombre de la caché del service worker
#
# El service worker va siempre a la red primero, así que no puede servir código
# viejo. Pero la caché de respaldo sí guardaría los archivos de la versión
# anterior para el modo sin conexión: al cambiar el nombre en cada publicación,
# activate() la borra entera y se vuelve a llenar con lo recién publicado.
sw_path='sw.js'
if os.path.exists(sw_path):
    sw=open(sw_path,encoding='utf-8').read()
    sw2=re.sub(r"const CACHE\s*=\s*'[^']*';", f"const CACHE = 'contabilidad-{epoch}';", sw, count=1)
    if sw2==sw:
        sys.exit('no se pudo actualizar el nombre de caché en sw.js')
    open(sw_path,'w',encoding='utf-8').write(sw2)

print(f'{version} · {len(modulos)} módulos versionados · epoch {epoch}')
