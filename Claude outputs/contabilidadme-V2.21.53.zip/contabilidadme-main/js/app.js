import {resumenMonitorFS, reiniciarMonitorFS} from './monitorfs.js';
import {initActualizador, verificarActualizacion} from './actualizador.js';
// app.js — Orquestador: routing, arranque y puente con el HTML.
// Importa todos los módulos, registra los callbacks de ui.js/auth.js
// y expone al scope global las funciones usadas por los onclick del HTML.

import {toast, fmtC, MESES, PDC, recalcDerivadasPDC, pn} from './core.js';
import {normalizarPDC,asegurarCuentasSistema} from './pdc-reglas.js';
import {construirPlanPlantilla, plantillaInfo} from './pdc-plantillas.js';
import {S, AUTH, getCurSec, setCurSec} from './state.js';
import {FS, initFirestore, logAccion} from './firebase.js';
import './storage.js';
import {registrarUI} from './ui.js';
import {initTema, cambiarTema, aplicarTema} from './tema.js';
import {EMPRESAS, MARCOS, marcoInfo, cargarEmpresas, empresaActiva, crearEmpresa, asegurarAccesoEmpresa,
        eliminarEmpresa, actualizarEmpresa, activarEmpresa, migrarSiHaceFalta,
        aplicarVisibilidad, puedeVerEmpresa} from './empresas.js';
import {renderEmpresas, abrirFormEmpresa, cerrarFormEmpresa, editarEmpresaCat,
        guardarEmpresaCat, seleccionarEmpresa, borrarEmpresa, onMarcoChange, onRegimenChange, onPlantillaChange,
        abrirCompartir, cerrarCompartir, guardarCompartir, reclamarEmpresa,
        restaurarEmpresa, descartarEmpresaHuerfana} from './empresas-ui.js';

// Sistema
import {initAuth, puedeVer, puedeEditar, esAdmin, ROLES, SECCIONES, permisosDeRol,
        toggleLoginMode, submitLogin, recuperarPassword, mostrarLogin, logout,
        aplicarPermisosUI, setOnAuthReady} from './auth.js';
import {cargarUsuarios, renderUsuarios, abrirInvitarUsuario, editarUsuario,
        renderPermisosForm, cerrarUsuarioForm, guardarUsuario, aprobarUsuario,
        desactivarUsuario, US} from './usuarios.js';
import {renderAuditLog} from './audit.js';
import {renderIntegridad,renderPilotoUI,guardarPilotoUI,certificarPilotoUI,invalidarPilotoUI,migrarAsientosV2,ejecutarRegresionContableUI,ejecutarPruebasProductivasUI,iniciarPruebaConcurrenciaUI,prepararPruebaConcurrenciaUI,escribirPruebaConcurrenciaUI,verificarPruebaConcurrenciaUI,ejecutarSimulacroRestauracionUI,crearSnapshotUI,verificarSnapshotUI,restaurarSnapshotUI} from './integridad.js';
import {renderCierresMensuales,cerrarMesContableOperativo,reabrirMesContableOperativo} from './cierres-mensuales.js';
import {initRecovery} from './recovery.js';
import {cargarPreproduccion,actualizarBadgeEntorno,setChecklistPreprod,habilitarEscriturasPrueba,bloquearEscriturasPrueba,activarProduccion,volverAPrueba,descargarActaHabilitacion} from './preproduccion.js';
import {cargarPiloto} from './piloto.js';

// Configuración y datos
import {fillEmpresaForm, saveEmpresa, updateHdr, aplicarRegimenEmpresa,
        onRegimenEmpresaChange, pintarRegimen} from './empresa.js';
import {savePDC, renderPDC, abrirPdcForm, editarCuenta, cerrarPdcForm,
        guardarCuenta, eliminarCuenta, resetPDC, PF} from './pdc.js';
import {renderIndicadores, guardarIndicadores, restaurarIndicadoresDefault,
        getIndicadores, IND, actualizarDesdeBancoCentral,
        renderIUSCTabla, setIUSC, addIUSCTramo, delIUSCTramo, restaurarIUSCTabla, setIUSCPrueba} from './indicadores.js';
import {renderPrevisional, guardarPrevisional, restaurarPrevisional, renderPrevisionalAccidentes, agregarTramoReforma, quitarTramoReforma} from './previsional-ui.js';
import {acBuscar, acTecla, acElegir, acCerrarDif, inputCuenta, buscarCuentas, inputCC, ccAcBuscar, ccAcTecla, ccAcElegir, ccAcCerrarDif,
        axAcBuscar, axAcTecla, axAcElegir, axAcCerrar} from './buscadorcuentas.js';
import {prAcBuscar, prAcTecla, prAcElegir, prAcCerrarDif} from './buscadorproductos.js';
import {initAvisoSalida, marcarGuardado, marcarSucio, haySinGuardar, hayBorrador, hayCambiosConfirmados,
        guardarBorradoresAhora, limpiarBorradorCampos, recargarBorradoresContexto, recordarNav, ultimaSeccion, olvidarNav,
        listarBorradoresLocales, descartarBorradorLocal, descartarTodosBorradoresLocales, continuarBorradorLocal} from './salida.js';
import {initAutoguardado, actualizarBotonGuardar, guardarTodoAhora, setAutoguardado,
        setIntervaloAutoguardado, confirmarSalida, AG} from './autoguardado.js';
import {cargarFichasAux, descargarPlantillaAux, abrirImportFichas,
        initImportFichasListener, fichasAux, fichaAux} from './importadoraux.js';
import {cargarComprobantes} from './comprobantestipo.js';
import {buscarCT, cerrarBuscarCT, navCT, aplicarCT, abrirCTModal, cerrarCTModal,
        renderCTModal, setCTCuenta, setCTCampo, setCTHeader, addCTLinea, delCTLinea, nuevoCT,
        toggleCTDist, setCTDist, addCTDist, delCTDist, repartirCTDist,
        editarCT, guardarCT, borrarCT, copiarCTaEmpresa} from './comprobantestipo-ui.js';
import {cargarCentros, cargarCierresCC, ccOpts, ccNombre, costoAcumulado} from './centroscosto.js';
import {renderAsigCC, resetAsigCC, setAsigCC, limpiarFiltrosCC, setCCMov, toggleSelCC,
        selTodosCC, limpiarSelCC, setBulkCC, asignarSelCC, exportarAsigCCExcel,
        pendientesCC, ACC} from './asigcc.js';
import {renderCentrosCosto, abrirFormCC, editarCC, cerrarFormCC, guardarCC, borrarCC,
        verDetalleCC, abrirCapitalizar, confirmarCapitalizar, onCurvaChange,
        setPct, addPctAnio, delPctAnio, onTipoCentroChange, ejecutarCierreMensual,
        revertirCierreMensual, onCierreMesChange, resetCierreMes} from './centroscosto-ui.js';
import {mesOpts, mesRango, foliosMensuales, dteVentasOpts} from './helpers.js';
import {renderCargaDatos, descargarPlantillaDatos, abrirCargaDatos,
        initCargaDatosListener, CD} from './cargadatos.js';
import {renderSistema} from './sistema.js';
import {DISPOSITIVO, renombrarDispositivo} from './dispositivo.js';
import {initAyuda, toggleAyuda, actualizarAyuda, ayudaAlNavegar} from './ayuda.js';
import {renderInicio, abrirEmpresaInicio, alternarVerOtras, botonVerOtras} from './inicio.js';
import {abrirReporteAux, cerrarReporteAux, setReporteAuxVista, renderReporteAux,
        imprimirReporteAux, exportarReporteAuxExcel} from './auxreporte.js';
import {cargarInventario,renderInventario,invSetTab,invSetFiltro,invCerrarModal,
        invAbrirGrupo,invGuardarGrupo,invAbrirBodega,invGuardarBodega,
        invAbrirProducto,invActualizarSubgrupos,invGuardarProducto,
        invDescargarPlantillaProductos,invAbrirImportProductos,invLeerProductosExcel,invAplicarImportProductos,
        invNuevoMovimiento,invMovCampo,invMovLineaCampo,invMovAgregarLinea,invMovQuitarLinea,
        invGuardarMovimiento,invVerMovimiento,invAnularMovimiento,invEditarMovimiento,
        invNuevaToma,invCrearToma,invAbrirToma,invVolverTomas,invSetFisicoToma,invSetCostoToma,
        invAgregarLineaToma,invTomaProductoCambio,invGuardarLineaToma,invCerrarToma,
        invDevolverToma,invRechazarToma,invAutorizarToma,
        invNuevaOC,invEditarOC,invOCCampo,invOCLineaCampo,invOCAgregarLinea,invOCQuitarLinea,invGuardarOC,
        invVerOC,invVolverOC,invEmitirOC,invAnularOC,invCerrarSaldoOC,invAbrirRecepcion,invRecCampo,invRecLineaCampo,invRecAgregarLote,invRecQuitarLinea,
        invGuardarRecepcion,invAnularRecepcion,invAbrirVincularFactura,invVincularFactura} from './inventario.js';

// Negocio
import {renderApertura, abrirApertura, cerrarApertura, apRenderLineas, apLCd, apLRut,
        apLVal, apDelLinea, apAddLinea, apPrellenar, apUpdCuadre, guardarApertura,
        eliminarApertura, initBalanceImportListener, abrirImpBalModal, cerrarImpBalModal,
        toggleAllBal, confirmarImportBalance, renderImpBalModal,
        descargarPlantillaBalance, APF, IMB} from './apertura.js';
import {abrirAperturaAux, cerrarAperturaAux, renderAperturaAux, apxAddDoc, apxDelDoc,
        apxCampo, apxRut, apxAuxElegido, apxActualizarCuadre, guardarAperturaAux,
        descargarPlantillaAperturaAux, initAperturaAuxListener, APX} from './aperturaaux.js';
import {onMesChangeV, limpiarFiltrosV, renderVentas, abrirVF, editarVenta, cerrarVF,
        vfRutInput, vfCheckDup, vfDteChanged, vfRefrescarDocs, vfSeleccionarReferencia, vfCalcTotals, vfAutoCalc, guardarVenta, setVfCuenta,
        eliminarVenta, VF, abrirImportSIIVentas, handleFileImportVentas,
        cambiarPeriodoImportV, toggleAllImportV, aplicarCuentaATodosV,
        renderImportModalVentas, confirmarImportacionV, cerrarImportModalVentas,
        initImportListenerV, setBulkCuentaImpV, enfocarPendienteImportV,
        toggleVSel, toggleVSelAll, limpiarVSel, eliminarVSel, cambiarFPVSel, IMV} from './ventas.js';
import {onMesChangeC, limpiarFiltrosC, renderCompras, abrirCF, editarCompra, cerrarCF,
        cfRutInput, cfCheckDup, cfDteChanged, cfRefrescarDocs, cfSeleccionarReferencia, cfCalcTotals, renderDist, addDist, delDist, updCfCheck,
        guardarCompra, eliminarCompra, abrirImportSII, abrirImportModal,
        cambiarPeriodoImport, cerrarImportModal, toggleImportDoc, toggleAllImport,
        setImportCuenta, aplicarCuentaATodos, confirmarImportacion, setImportReferencia,
        initImportListener, renderImportModal, setBulkCuentaImp, setImportCC, aplicarCCATodos, setImportGlosa, enfocarPendienteImportC,
        cambiarModoImport, verDuplicadoC, renderCDupAlert,
        toggleCSel, toggleCSelAll, limpiarCSel, eliminarCSel, CF, IM} from './compras.js';
import {renderHon, setHonCampo, uhon, addHon, delHon, saveHon, abrirHonComprobante, cerrarHonComprobante, actualizarPreviewHon, guardarHonComprobante, anularHonDesdeComprobante, seleccionarPrestadorHon} from './honorarios.js';
import {renderAsientos, abrirForm, cerrarForm, editarAsiento, duplicarAsiento,
        anularAsiento, eliminarAsiento, guardarAsiento, addLinea, delLinea, renderLineas,
        lCd, lVal, lValFmt, lValFmtBlur, lRut, toggleAs, updCuadre, limpiarFormAsiento, sigAsiento,
        abrirDteModal, cerrarDteModal, dtmGuardar, dtmTipoChanged, dtmRefresh, dtmCalcTotals, dtmRutInput,
        dtmCheckDup, dtmAddDist, dtmDelDist, dtmRenderDist, dtmUpdDistCheck, dtmRemover,
        quitarDte, folioPreviewDte, abrirAsientoDesde, cuentasOpts, lAuxElegido,
        proxFolioAsiento, proxFolioComprobante, migrarFoliosComprobante, AF} from './asientos.js';
import {asegurarNumerosContables} from './correlativo-contable.js';
import {renderActivoFijo, abrirFormAF, onCatAF, onCompraAF, cerrarFormAF, previewAF, guardarAF,
        editarAF, eliminarAF, generarAsientoDepreciacion, AFB} from './activofijo.js';
import {renderRemuneraciones, abrirFormTrabajador, cerrarFormTrabajador, onSaludChange, onGratModoChange,
        previewLiq, guardarTrabajador, editarTrabajador, eliminarTrabajador,
        onParamRem, verLiquidacion, generarAsientoRemuneraciones, REMF, onTipoPagoChange, imprimirLiquidacion, sugerirNombresPrevired} from './remuneraciones.js';
import {exportarPrevired, mostrarValidacionPrevired, setCfgPrevired, setCodigoPrevired} from './previred.js';
import {exportarImposicionesExcel} from './imposiciones.js';
import {renderFiniquitos, nuevoFiniquito, editarFiniquito, volverFiniquitos, onFinCambio, agregarFilaFin, quitarFilaFin,
        previewFiniquito, editarTextoFiniquito, quitarTextoFiniquito, subirTextoFiniquito, guardarFiniquito, verFiniquito,
        eliminarFiniquito, marcarRatificado, imprimirFiniquito, verPlantillasFiniquito, editarPlantillaFin, nuevaPlantillaFin,
        duplicarPlantillaFin, cancelarPlantillaFin, subirPlantillaFin, guardarPlantillaFin, restaurarPlantillaFin,
        eliminarPlantillaFin, insertarMarcadorFin, abrirAsientoFiniquito, cerrarAsientoFiniquito, onAsientoFinCambio,
        generarAsientoFiniquito} from './finiquitos.js';
import {pdfLiquidacionesMasivo, pdfLiquidacion, pdfLibroRem} from './pdf-rem.js';
import {renderVacaciones, abrirFormVacaciones, abrirConfigVacaciones, guardarConfigVacaciones, guardarVacaciones,
        guardarFeriadosExtra, previewVacaciones, exportarVacacionesExcel} from './vacaciones.js';
import {renderAsistencia, abrirFormAsistencia, editarEventoAsistencia, cerrarFormAsistencia, guardarEventoAsistencia,
        eliminarEventoAsistencia, setHorasMes, onAsisTipoChange} from './asistencia.js';
import {cargarLibroRem, libroDelMes, renderLibroRem, setRemView, getRemView, tabsRemuneraciones,
        cerrarMesRem, reabrirMesRem, exportarLibroRemExcel} from './libroremuneraciones.js';
import {exportarLRECSV, mostrarValidacionLRE, validarLibroLRE, construirRegistroLRE, LRE_CONCEPTOS} from './lre-dt.js';
import {renderCierre, generarAsientoCierre, reabrirEjercicio, renderProvisiones, previewProvInc,
        previewProvFer, generarProvisionIncobrables, generarProvisionFeriado,
        renderCorreccion, previewCM} from './cierre.js';

// Reportes
import {genDiario, renderDiario, setDiarioQ, buildMayor, renderMayor, renderBalance, renderBalance8, exportarBalance8Excel,
        poblarCmpSelect, onCmpYear, renderResultados, corregirDesdeDiario, editarAsientoRef,
        onDiarioMes, setDiarioFecha, limpiarFiltrosDiario, exportarDiarioExcel,
        onMayorMes, setMayorFecha, setMayorQ, limpiarFiltrosMayor, renderMayorTabla,
        exportarMayorExcel, toggleMayorCuenta} from './reportes.js';
import {renderLibrosCV,setLibroCVTipo,setLibroCVMes,setLibroCVDte,exportarLibroCVExcel,exportarLibroCVCSV} from './libroscv.js';
import {initMoneyInputs,normalizarMontos} from './money-inputs.js';
import {cmpHdrBuscar, cmpHdrTecla, cmpHdrCerrar, cmpHdrElegir, renderComprobantes, setCmpFiltro, limpiarCmpFiltro, toggleCmpDet, cmpNumeroBuscar, renderCmpNumeroList, cmpNumeroElegir, cmpNumeroElegirResultado, corregirDescuadreCmp,
        abrirCmpModal, cerrarCmpModal, cmpModalEditar, cmpModalCancelar, cmpModalGuardar,
        eliminarComprobante, anularComprobante,
        setCmpEdGlosa, setCmpEdFecha, setCmpEdCuenta, setCmpEdCampo, setCmpEdMonto, setCmpEdMontoBlur, addCmpEdLinea, delCmpEdLinea,
        abrirCmpEdDte, cerrarCmpEdDte, setCmpDteCampo, setCmpDteTipo, setCmpDteRut, cmpDteAutoTotal, guardarCmpEdDte} from './comprobantes.js';
import {renderPagos, setPagTipo, setPagCampo, setPagFiltro, limpiarPagFiltro, togglePagSel, togglePagAll, setPagMontoParcial, ejecutarPago, abrirAsociarNota, cerrarAsociarNota, confirmarAsociar, quitarReferencia} from './pagos.js';
import {abrirNuevoHonorario, cerrarNuevoHonorario, guardarNuevoHonorario, hdRutInput, hdProvSel, hdRecalc, hdAddDist, hdDelDist, hdDistCampo, hdProvBuscar, hdProvElegir, hdProvCerrar, hdProvTecla, hdNuevoAuxiliar} from './honorariodoc.js';
import {abrirEditorPago, cerrarEditorPago, guardarEditorPago, peCampo, peLineaCampo, peDelLinea, pePickBuscar, pePickAdd, pePickCerrar} from './pagoeditor.js';
import {setAuxTab, setAuxView, setAuxQ, verTodosAux, ocultarTodosAux, toggleAux, renderAuxiliares, calcularAging,
        toggleAgingDetalle, AUX_TAB,
        abrirFichaAux, abrirFichaAuxNueva, fichaRutInput, cerrarFichaAux, setFichaCuenta, guardarFichaAuxUI,
        auxPorRut, abrirReporteAuxDe} from './auxiliares.js';
// AUX_TAB también viene de auxiliares.js — se recupera desde window.
import {renderF29, renderPPM, IVAC, renderCompensacionIVA, generarAsientoIVA,
        setIvacCuenta, setIvacCampo, resetIvacCuentas, crearCuentaRemanente,
        PAGOF29, renderPagoF29, generarAsientoPagoF29, setPagoF29Cuenta, setPagoF29Campo,
        setPagoF29Monto, togglePagoF29, resetPagoF29, usarSugeridoF29, cargarDeclaracionesF29,
        setF29Declarado, setF29DeclCampo, setF29UTM, copiarCalculadoAF29, guardarBorradorF29, presentarF29, reabrirF29, setRemanenteInicialF29} from './tributario.js';
import {setUTMManual, buscarUTMNuevas} from './utm-historico.js';
import {DJ, renderDJ, cargarDJ, resetDJ, setDJVerTodas, setDJEstado, editarDJ, nuevaDJ,
        cerrarEditorDJ, guardarDJ, borrarDJ, restaurarCatalogoDJ, exportarDJExcel} from './djrenta.js';
import {renderRenta, setRentaTab, setRentaParam, restaurarTasaLegal, toggleRechazada,
        addRentaLinea, setRentaLinea, delRentaLinea, setRentaCredito, exportRentaXLSX,
        resetRenta} from './renta.js';
import {setFCView, renderFlujoCaja} from './flujocaja.js';
import {renderConciliacion, onSaldoBancoChange, toggleConciliado,
        marcarTodosConciliados, cargarCartola, autoConciliarCartola} from './conciliacion.js';
import {abrirBusqueda, cerrarBusqueda, ejecutarBusqueda, navBusqueda,
        irAResultado} from './busqueda.js';
import {prepararImpresion} from './impresion.js';
import {renderFoliosSII, agregarRangoFolios, activarRangoFolios, recalcularPreview, actualizarCfg, imprimirPruebaFolios, reservarEImprimir, reimprimirReserva, cerrarReserva, exportarControlFolios} from './folios-sii.js';
import {exportarExcelManual, conectarBD, fsBackupToCloud, fsRestoreFromCloud,
        importarExcelBD, initBDImportListener, bdRestaurarHandle, bdStatusSet, BD} from './backup.js';

// ═══ STORAGE ═══
// Guarda todo el estado en curso. `silencioso` lo usa el autoguardado para no
// llenar la pantalla de toasts. Devuelve true/false según haya podido guardar.
//
// Ojo: antes esta función empezaba con `document.querySelector('.btn-save-all').textContent=…`
// sin comprobar que el botón existiera. Al sacar el botón de la barra superior
// quedó en null y saveAll() reventaba en la primera línea sin guardar nada.
async function saveAll({silencioso=false}={}){
  const btn=document.getElementById('btn-guardar-todo');
  const rotulo=btn?btn.innerHTML:'';
  if(btn){btn.innerHTML='⏳';btn.disabled=true;}
  let ok=false;
  try{
    const y=S.empresa.anio;
    const nr=await asegurarNumerosContables();
    if(!nr.ok)throw new Error(nr.motivo||'correlativo-contable');
    const entradas=[
      {key:'empresa',value:JSON.stringify(S.empresa)},
      {key:'ventas-'+y,value:JSON.stringify(S.ventas)},
      {key:'compras-'+y,value:JSON.stringify(S.compras)},
      {key:'honorarios-'+y,value:JSON.stringify(S.honorarios)},
      {key:'asientos-'+y,value:JSON.stringify(S.asientos)},
      {key:'cierresContables-'+y,value:JSON.stringify(S.cierresContables||[])},
    ];
    if(S.activos&&S.activos.length)entradas.push({key:'activos',value:JSON.stringify(S.activos)});
    if(S.trabajadores&&S.trabajadores.length)entradas.push({key:'trabajadores',value:JSON.stringify(S.trabajadores)});
    if(S.asistencia&&(S.asistencia.eventos||[]).length)entradas.push({key:'asistencia',value:JSON.stringify(S.asistencia)});
    if(S.centros&&S.centros.length)entradas.push({key:'centros',value:JSON.stringify(S.centros)});
    if(S.cierresCC&&S.cierresCC.length)entradas.push({key:'cierresCC',value:JSON.stringify(S.cierresCC)});
    if(S.comprobantesTipo&&S.comprobantesTipo.length)entradas.push({key:'comprobantesTipo',value:JSON.stringify(S.comprobantesTipo)});
    if(S.fichasAux)entradas.push({key:'fichasAux',value:JSON.stringify(S.fichasAux)});
    const r=typeof window.storage.setMany==='function'?await window.storage.setMany(entradas):null;
    if(r&&r.ok===false){
      const clave=r.clave?` · ${r.clave}`:'';
      const detalle=r.detalle?` · ${r.detalle}`:'';
      throw new Error((r.motivo||'fallo-persistencia')+clave+detalle);
    }
    if(!r){
      for(const e of entradas){const rr=await window.storage.set(e.key,e.value);if(!rr||rr.ok===false)throw new Error(rr?.motivo||`fallo-${e.key}`);}
    }
    ok=true;
    marcarGuardado();
    if(!silencioso)toast('✅ Todos los datos guardados');
  }catch(e){
    console.error('saveAll',e);
    toast('❌ No se pudo guardar: '+e.message,'e');   // el error se avisa siempre
  }
  if(btn){btn.disabled=false;btn.innerHTML=rotulo||'<span aria-hidden="true">💾</span><span class="save-lbl">Guardar</span>';}
  actualizarBotonGuardar();
  return ok;
}
// Carga los datos del ejercicio.
//
// Cada lectura que falla se ve EXACTAMENTE igual que "no hay datos": la sección
// aparece vacía. Antes eso se tragaba en silencio (`catch(e){}`) y, al primer
// guardado, la app escribía ese vacío encima del dato bueno de la nube.
//
// Ahora se distingue el error y se registra: storage bloquea la escritura de
// esas claves y `S.cargaFallida` deja constancia para avisar en pantalla.
// Pantalla de espera del cruce: es corta, pero conviene decir qué está pasando
function pantallaCruce(txt,detalle){
  let el=document.getElementById('cruce-overlay');
  if(!el){
    el=document.createElement('div');
    el.id='cruce-overlay';
    el.style.cssText='position:fixed;inset:0;background:var(--bg,#0d1117);z-index:9000;display:flex;'+
      'flex-direction:column;align-items:center;justify-content:center;gap:12px;text-align:center;padding:24px';
    document.body.appendChild(el);
  }
  el.innerHTML=`<div style="font-size:34px">☁️</div>
    <div style="font-size:15px;font-weight:700">${txt}</div>
    <div style="font-size:12px;color:var(--mt);font-family:var(--mono);min-height:18px">${detalle||''}</div>`;
  return el;
}
const cerrarPantallaCruce=()=>{const el=document.getElementById('cruce-overlay');if(el)el.remove();};

// Versión del esquema del plan de cuentas guardado (clave pdc_v).
const PDC_VERSION=3;

// V2.21.27 — Plan de cuentas tipo elegido al crear la empresa.
// Se aplica una sola vez: cuando la empresa tiene plantilla en el catálogo y
// la nube CONFIRMA que todavía no tiene plan guardado. Si la lectura falla no
// se toca nada (un error de red no debe pisar un plan existente).
async function aplicarPlantillaPdcSiCorresponde(){
  const e=empresaActiva();
  const id=e&&e.plantillaPdc;
  if(!id||!plantillaInfo(id))return false;
  try{
    const r=await window.storage.leerConEstado('pdc');
    if(r.fuente==='error'||r.value!=null)return false;
    const rv=await window.storage.leerConEstado('pdc_v');
    if(rv.fuente==='error')return false;
    const plan=construirPlanPlantilla(id);
    if(!plan||!plan.length)return false;
    normalizarPDC(plan);asegurarCuentasSistema(plan);
    const w=await window.storage.setMany([
      {key:'pdc',value:JSON.stringify(plan)},
      {key:'pdc_v',value:String(PDC_VERSION)},
    ]);
    if(!w||!w.ok){console.warn('No se pudo aplicar la plantilla del plan de cuentas:',w);return false;}
    PDC.length=0;plan.forEach(c=>PDC.push(c));recalcDerivadasPDC();
    toast('📒 Plan de cuentas creado con la plantilla '+plantillaInfo(id).nm+' ('+plan.length+' cuentas)');
    return true;
  }catch(err){console.warn('Plantilla PDC:',err);return false;}
}

async function cruzarAlIniciar(){
  if(!FS.enabled){return null;}
  const claves=window.storage.clavesDeLaEmpresa(S.empresa.anio||new Date().getFullYear());
  pantallaCruce('Sincronizando con la nube…',`0 de ${claves.length}`);
  let r;
  try{
    r=await window.storage.cruzarConLaNube(claves,(hechas,total,clave)=>{
      pantallaCruce('Sincronizando con la nube…',`${hechas} de ${total} · ${clave}`);
    });
  }catch(e){
    cerrarPantallaCruce();
    console.error('Cruce con la nube:',e);
    return null;
  }
  cerrarPantallaCruce();
  if(r.fallidas.length){
    toast(`🚫 ${r.fallidas.length} registro(s) no se pudieron leer — el guardado quedó bloqueado para protegerlos`,'e');
    console.error('Cruce incompleto:',r.fallidas);
  }else if(r.actualizadas.length){
    toast(`☁️ ${r.actualizadas.length} registro(s) actualizados desde la nube`);
    console.log('Actualizados en el cruce:',r.actualizadas);
  }
  return r;
}

function renombrarEsteDispositivo(){
  const n=prompt('Nombre de este equipo\n\nSirve para reconocerlo en los avisos de cambios simultáneos.',DISPOSITIVO.nombre);
  if(n===null)return;
  if(renombrarDispositivo(n)){toast('🖥 Ahora este equipo se llama "'+DISPOSITIVO.nombre+'"');renderSistema();}
}

async function loadYear(y){
  S.ventas=[];S.compras=[];S.honorarios=[];S.asientos=[];S.apertura=null;S.activos=[];S.trabajadores=[];S.asistencia={eventos:[],horas:{}};S.cierresContables=[];S.hardeningCert=null;
  S.cargaFallida=[];
  resetRenta(); // los ajustes del F22 son por empresa+año: se recargan al entrar a la sección
  resetDJ();    // ídem el catálogo y el control de declaraciones juradas
  resetAsigCC(); // ídem los filtros de asignación de centros de costo
  resetCierreMes(); // el mes elegido para cerrar costos es de este ejercicio

  const leer=async(clave,aplicar)=>{
    const r=await window.storage.leerConEstado(clave);
    if(r.fuente==='error'){
      S.cargaFallida.push({clave,motivo:r.error});
      console.error('No se pudo cargar',clave,'—',r.error);
      return;
    }
    if(r.value==null)return;
    try{aplicar(JSON.parse(r.value));}
    catch(e){
      S.cargaFallida.push({clave,motivo:'contenido ilegible'});
      console.error('Contenido ilegible en',clave,e);
    }
  };

  for(const[k,d] of [['ventas-'+y,'ventas'],['compras-'+y,'compras'],['honorarios-'+y,'honorarios'],['asientos-'+y,'asientos']]){
    await leer(k,parsed=>{
      if(Array.isArray(parsed)&&parsed.length>0&&(d==='ventas'||d==='compras')&&parsed[0]&&'mes' in parsed[0]&&!('tipoDTE' in parsed[0])){
        S[d]=[];   // formato antiguo por mes: se ignora
      }else if(Array.isArray(parsed)){
        S[d]=parsed;
      }
    });
  }
  await leer('apertura-'+y,p=>{S.apertura=p;});
  await leer('cierresContables-'+y,p=>{if(Array.isArray(p))S.cierresContables=p;});
  await leer('hardening-certificacion-'+y,p=>{if(p&&typeof p==='object')S.hardeningCert=p;});
  // Activos fijos y trabajadores: claves GLOBALES de la empresa (persisten entre años)
  await leer('activos',p=>{if(Array.isArray(p))S.activos=p;});
  await leer('trabajadores',p=>{if(Array.isArray(p))S.trabajadores=p;});
  await leer('asistencia',p=>{if(p&&typeof p==='object'&&!Array.isArray(p))S.asistencia=p;});
  S.finiquitos=null;await leer('finiquitos',p=>{if(p&&typeof p==='object'&&!Array.isArray(p))S.finiquitos=p;});

  if(S.cargaFallida.length){
    toast(`🚫 No se pudieron cargar ${S.cargaFallida.length} registro(s) — el guardado quedó bloqueado para protegerlos`,'e');
  }
  try{actualizarBotonGuardar();}catch(e){}
  return S.cargaFallida;
}
async function changeYear(y){S.empresa.anio=y;await loadYear(y);recargarBorradoresContexto();await cargarPreproduccion();await cargarPiloto();await cargarDeclaracionesF29(true);rerender();}
async function init(){
  // Firestore y Auth arrancan EN PARALELO.
  // Antes se esperaba a que Firestore terminara de conectar para recién empezar
  // a autenticar. En un teléfono que reabre la app con la red todavía dormida,
  // esa espera podía durar varios segundos con la pantalla de login a la vista,
  // y se leía como "me cerró la sesión". La verificación de permisos ya sabe
  // esperar a Firestore por su cuenta, así que no hace falta bloquear aquí.
  const conectando=initFirestore();
  // Inicializar Auth — mostrará el login si no hay sesión
  await initAuth();
  await conectando;
  // El resto de la inicialización de la app se hace en initApp(), que se llama
  // desde verificarUsuarioAutorizado() una vez que hay usuario válido.
}

async function initApp(){
  // ── Multiempresa: migrar datos antiguos, cargar catálogo y fijar el prefijo
  // ANTES de leer cualquier dato (si no, se leería con el prefijo equivocado).
  await migrarSiHaceFalta();
  await cargarEmpresas();
  // Si el catálogo no se pudo leer, avisar fuerte y NO seguir cargando datos
  // con un prefijo equivocado (se leería vacío y parecería que no hay nada).
  if(EMPRESAS.errorCarga){
    toast('🚫 No se pudo leer el catálogo desde la nube — revisa Empresas','e');
    nav('empresas');
    return;
  }
  // Rol Consulta sin empresas compartidas: no hay nada que abrir
  if(EMPRESAS.sinEmpresas){
    toast('ℹ️ Aún no tienes empresas asignadas. Pide a un administrador o al dueño que te comparta una.','e');
    nav('empresas');
    return;
  }
  window.storage.setPrefijo(EMPRESAS.activa);
  renderSelectorEmpresa();
  // La ficha de acceso de la empresa activa tiene que estar en la nube ANTES
  // del cruce: si no, las reglas niegan la lectura y el guardado se bloquea.
  await asegurarAccesoEmpresa(EMPRESAS.activa);

  // ── Cruce con la nube ANTES de dejar trabajar ──
  // Arrancar con una foto vieja es la causa de fondo de los conflictos y de que
  // una fusión reviva registros borrados. Este paso demora un poco la apertura
  // a cambio de que el equipo empiece sincronizado.
  await cruzarAlIniciar();

  const ys=document.getElementById('year-sel');
  const cy=new Date().getFullYear();
  for(let y=cy+1;y>=cy-5;y--){const o=document.createElement('option');o.value=y;o.textContent=y;if(y===cy)o.selected=true;ys.appendChild(o);}

  try{const r=await window.storage.get('empresa');if(r)S.empresa={...S.empresa,...JSON.parse(r.value)};}catch(e){}
  aplicarRegimenEmpresa();
  await aplicarPlantillaPdcSiCorresponde();
  try{
    const vr=await window.storage.get('pdc_v');
    const savedV=vr?+vr.value:0;
    if(savedV===PDC_VERSION){
      const r=await window.storage.get('pdc');
      if(r){
        const loaded=JSON.parse(r.value);
        if(Array.isArray(loaded)&&loaded.length>0){
          PDC.length=0;loaded.forEach(c=>PDC.push(c));normalizarPDC(PDC);recalcDerivadasPDC();
        }
      }
    }else if(savedV>0){
      console.log('Plan de cuentas actualizado a v'+PDC_VERSION+' (anterior: v'+savedV+')');
      normalizarPDC(PDC);
      await window.storage.set('pdc',JSON.stringify(PDC));
    }
    await window.storage.set('pdc_v',String(PDC_VERSION));
  }catch(e){console.warn('Error cargando PDC:',e);}
  try{if(asegurarCuentasSistema(PDC))await window.storage.set('pdc',JSON.stringify(PDC));}catch(e){console.warn('No se pudo persistir cuentas de sistema:',e);}
  ys.value=S.empresa.anio;
  await loadYear(S.empresa.anio);
  await cargarDeclaracionesF29(true);
  await cargarCentros();await cargarCierresCC();await cargarComprobantes();await cargarFichasAux();await cargarLibroRem();await cargarInventario();
  // Migración de folios de comprobante para datos preexistentes:
  // asigna folioComp a asientos manuales, compras, ventas y apertura que no
  // lo tengan, respetando el orden cronológico.
  const migrados=migrarFoliosComprobante();
  if(migrados){
    console.log(`Migración: ${migrados} elementos recibieron folio de comprobante`);
    // Persistir los cambios de migración
    try{
      const entradas=[];
      if(S.asientos?.length)entradas.push({key:'asientos-'+S.empresa.anio,value:JSON.stringify(S.asientos)});
      if(S.compras?.length)entradas.push({key:'compras-'+S.empresa.anio,value:JSON.stringify(S.compras)});
      if(S.ventas?.length)entradas.push({key:'ventas-'+S.empresa.anio,value:JSON.stringify(S.ventas)});
      if(entradas.length){
        const r=window.storage.setMany?await window.storage.setMany(entradas):null;
        if(r&&r.ok===false)throw new Error(r.motivo||'fallo-migracion-folios');
      }
    }catch(e){console.warn('Error persistiendo migración de folios:',e);toast('⚠️ No se pudo persistir la migración de folios. Revisa la conexión antes de continuar.','e');}
  }
  // V2.15.3: cada asiento maestro obtiene un número contable definitivo.
  // La secuencia se reserva en Firebase; si no hay conexión, no inventamos
  // números locales que pudieran chocar con otro equipo.
  try{
    const nr=await asegurarNumerosContables();
    if(nr.ok&&nr.asignados){
      const r=await window.storage.set('asientos-'+S.empresa.anio,JSON.stringify(S.asientos));
      if(!r||r.ok===false)throw new Error(r?.motivo||'fallo-persistencia-numeracion');
      console.log(`Numeración contable: ${nr.asignados} asiento(s) numerados`);
    }else if(!nr.ok){
      toast('☁️ Numeración contable pendiente: conecta Firebase antes de crear nuevos asientos.','e');
    }
  }catch(e){console.warn('Numeración contable:',e);toast('⚠️ No se pudo completar la numeración contable definitiva.','e');}

  fillEmpresaForm();recargarBorradoresContexto();updateHdr();renderInicio();
  initImportListener();
  initImportListenerV();
  initImportFichasListener();
  initCargaDatosListener();
  initBDImportListener();
  initBalanceImportListener();
  bdStatusSet('offline');
  if(BD.supported)await bdRestaurarHandle();
  // V2.15.4: cargar índice de snapshots y activar respaldo automático periódico.
  try{await initRecovery();}catch(e){console.warn('Recovery init:',e);}
  // V2.15.7: recién ahora se activa la guardia PRUEBA/PRODUCCIÓN, después de migraciones de arranque.
  try{await cargarPreproduccion();await cargarPiloto();}catch(e){console.warn('Preproducción/Piloto init:',e);}
  // Aplicar permisos por si el usuario no puede ver la sección actual
  aplicarPermisosUI();
  initNavGroups();
  retomarUltimaSeccion();
}

// Volver a la pantalla donde se estaba.
// Instalada en el teléfono, Android descarta el proceso de la app apenas pasas
// un rato en otra aplicación. Al volver, la app arranca de cero: con la sesión
// recordada ya no pide la contraseña, y con esto tampoco pierde la pantalla.
function retomarUltimaSeccion(){
  try{
    const s=ultimaSeccion();
    if(!s||s==='inicio')return;
    if(!document.getElementById('s-'+s))return;   // sección que ya no existe
    if(!puedeVer(s))return;                        // sin permiso, a la portada
    nav(s);
  }catch(e){}
}


// ═══ NAV ═══
function toggleNav(){
  const nav=document.querySelector('nav');
  const ov=document.getElementById('nav-overlay');
  const abierto=nav.classList.toggle('open');
  if(abierto&&!nav.querySelector('.nav-group.open')){
    const activa=nav.querySelector('.nav-item.active');
    const g=activa?.closest('.nav-group');if(g)abrirNavGroup(g.dataset.navGroup,false);
  }
  if(ov)ov.classList.toggle('open',abierto);
}
function cerrarNavMovil(){
  const nav=document.querySelector('nav');
  const ov=document.getElementById('nav-overlay');
  if(nav)nav.classList.remove('open');
  if(ov)ov.classList.remove('open');
}

const NAV_GRUPO_KEY='cv:nav-grupo-abierto';
function abrirNavGroup(id,guardar=true){
  const grupos=[...document.querySelectorAll('.nav-group')];
  grupos.forEach(g=>{
    const abrir=!!id&&g.dataset.navGroup===id;
    g.classList.toggle('open',abrir);
    const b=g.querySelector('.nav-group-toggle');if(b)b.setAttribute('aria-expanded',abrir?'true':'false');
  });
  if(guardar){try{id?localStorage.setItem(NAV_GRUPO_KEY,id):localStorage.removeItem(NAV_GRUPO_KEY);}catch(e){}}
}
function toggleNavGroup(id){
  const g=document.querySelector(`.nav-group[data-nav-group="${String(id).replace(/"/g,'')}"]`);
  if(!g)return;
  abrirNavGroup(g.classList.contains('open')?'':id,true);
}
function abrirGrupoDeSeccion(s,guardar=true){
  const item=document.querySelector(`.nav-item[data-s="${String(s).replace(/"/g,'')}"]`);
  const g=item?.closest('.nav-group');
  if(g)abrirNavGroup(g.dataset.navGroup,guardar);
}
function initNavGroups(){
  let guardado='';try{guardado=localStorage.getItem(NAV_GRUPO_KEY)||'';}catch(e){}
  const activa=document.querySelector('.nav-item.active');
  const gid=guardado||activa?.closest('.nav-group')?.dataset.navGroup||'';
  abrirNavGroup(gid,false);
}
function nav(s){
  document.querySelectorAll('.section').forEach(x=>x.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));
  const sec=document.getElementById('s-'+s);
  if(sec)sec.classList.add('active');
  const item=document.querySelector('.nav-item[data-s="'+s+'"]');
  if(item)item.classList.add('active');   // hay secciones sin ítem de menú
  if(item)abrirGrupoDeSeccion(s,true);    // el menú recuerda y muestra la categoría actual
  // Resaltar el acceso directo de la barra superior que corresponda
  document.querySelectorAll('.qn-btn').forEach(b=>b.classList.toggle('active',b.getAttribute('data-s')===s));
  // Contexto móvil: siempre mostrar dónde está el usuario. Preferimos el título
  // visible de la sección y, como respaldo, el texto del menú lateral.
  try{
    const mt=document.getElementById('mobile-section-title');
    const ms=document.getElementById('mobile-section-sub');
    const titulo=sec?.querySelector('.sec-title')?.textContent?.trim()
      ||item?.textContent?.replace(/^\s*[^A-Za-zÁÉÍÓÚÜÑ0-9]+/,'').trim()
      ||'Contabilidad';
    if(mt)mt.textContent=titulo;
    if(ms){
      const sub=sec?.querySelector('.sec-sub')?.textContent?.trim();
      ms.textContent=sub||(s==='inicio'?'Panel principal':'Empresa · '+(S?.empresa?.anio||''));
    }
    const volver=document.getElementById('mobile-back');
    if(volver)volver.style.visibility=(s==='inicio'?'hidden':'visible');
    const inicio=document.getElementById('mobile-home');
    if(inicio)inicio.style.visibility=(s==='inicio'?'hidden':'visible');
  }catch(e){}
  setCurSec(s);renderSec(s);
  recordarNav(s);      // para que el botón atrás deshaga un paso, no salte a Inicio
  ayudaAlNavegar(s);   // aplicar la preferencia de ayuda de esta pantalla
  cerrarNavMovil(); // en móvil, cerrar el drawer tras elegir sección
}
function renderSec(s){
  // Las pantallas de administración y sus alertas no se exponen aunque se
  // intente abrirlas mediante un enlace o un estado de navegación antiguo.
  if(AUTH.user&&['usuarios','auditlog','integridad'].includes(s)&&AUTH.user.rol!=='admin'){
    const sec=document.getElementById('s-'+s);
    if(sec)sec.innerHTML='<div class="empty"><div class="ei">🔒</div>Sección disponible sólo para administración.</div>';
    return;
  }
  // Verificar permiso de acceso a la sección.
  // 'empresa' y 'usuarios' se excluyen del bloqueo genérico: empresa es la landing,
  // y usuarios tiene su propio control de admin dentro de renderUsuarios().
  if(AUTH.user&&s!=='inicio'&&s!=='empresa'&&s!=='usuarios'&&s!=='auditlog'&&!puedeVer(s)){
    const sec=document.getElementById('s-'+s);
    if(sec)sec.innerHTML='<div class="empty"><div class="ei">🚫</div>No tienes permiso para acceder a esta sección.<br><br>Contacta a un administrador para solicitar acceso.</div>';
    return;
  }
  if(s==='empresa')fillEmpresaForm();
  else if(s==='empresas')renderEmpresas();
  else if(s==='centroscosto')renderCentrosCosto();
  else if(s==='pdc')renderPDC();
  else if(s==='cargadatos')renderCargaDatos();
  else if(s==='sistema')renderSistema();
  else if(s==='indicadores')renderIndicadores();
  else if(s==='apertura')renderApertura();
  else if(s==='usuarios')renderUsuarios();
  else if(s==='auditlog')renderAuditLog();
  else if(s==='integridad')renderIntegridad();
  else if(s==='ventas')renderVentas();
  else if(s==='compras')renderCompras();
  else if(s==='inventario')renderInventario();
  else if(s==='honorarios')renderHon();
  else if(s==='remuneraciones')renderRemuneraciones();
  // 'asientos' dejó de ser un módulo: los manuales viven dentro de Comprobantes.
  // Se mantiene el caso por si algún enlace viejo todavía navega ahí.
  else if(s==='asientos')renderComprobantes();
  else if(s==='auxiliares')renderAuxiliares();
  else if(s==='diario')renderDiario();
  else if(s==='libroscv')renderLibrosCV();
  else if(s==='foliossii')renderFoliosSII();
  else if(s==='mayor')renderMayor();
  else if(s==='balance')renderBalance();
  else if(s==='balance8')renderBalance8();
  else if(s==='resultados')renderResultados();
  else if(s==='flujocaja')renderFlujoCaja();
  else if(s==='conciliacion')renderConciliacion();
  else if(s==='comprobantes')renderComprobantes();
  else if(s==='pagos')renderPagos();
  else if(s==='f29')renderF29();
  else if(s==='inicio')renderInicio();
  else if(s==='ppm')renderPPM();
  else if(s==='renta')renderRenta();
  else if(s==='dj')renderDJ();
  else if(s==='asigcc')renderAsigCC();
  else if(s==='activofijo')renderActivoFijo();
  else if(s==='provisiones')renderProvisiones();
  else if(s==='correccion')renderCorreccion();
  else if(s==='cierresmensuales')renderCierresMensuales();
  else if(s==='cierre')renderCierre();
}
function rerender(){updateHdr();renderSec(getCurSec());}



// ═══ MULTIEMPRESA ═══
// Selector en el header + cambio de empresa (recarga todos los datos).
function renderSelectorEmpresa(){
  const sel=document.getElementById('empresa-sel');
  if(!sel)return;
  // Si el catálogo aún no está cargado, al menos mostrar la empresa en curso
  const lista=EMPRESAS.lista.length?EMPRESAS.lista:[{id:EMPRESAS.activa||'',nombre:S.empresa.nombre||'(sin empresa)'}];
  sel.innerHTML=lista.map(e=>
    `<option value="${e.id}" ${e.id===EMPRESAS.activa?'selected':''}>${e.nombre}</option>`
  ).join('')+'<option value="__gestionar">⚙️ Gestionar empresas…</option>';
  // Nombre visible del contexto: el de la empresa activa del catálogo, y si
  // aún no hay catálogo, el de la ficha cargada.
  const ctx=document.getElementById('ctx-empresa-nombre');
  if(ctx){
    const act=EMPRESAS.lista.find(e=>e.id===EMPRESAS.activa);
    ctx.textContent=(act&&act.nombre)||S.empresa.nombre||'Configura los datos de empresa';
  }
}

async function onCambiarEmpresa(){
  const sel=document.getElementById('empresa-sel');
  const v=sel.value;
  if(v==='__gestionar'){ renderSelectorEmpresa(); nav('empresas'); return; }
  if(v===EMPRESAS.activa)return;
  await activarEmpresa(v);
  await recargarEmpresaActiva();
  const e=empresaActiva();
  toast('🏢 Empresa activa: '+(e?e.nombre:''));
}

// Recarga TODO el estado desde la empresa activa (tras cambiarla)
async function recargarEmpresaActiva(){
  // La guardia del entorno anterior no debe bloquear migraciones técnicas al cambiar de empresa.
  window.__entornoBypass=true;
  // Resetear estado en memoria
  S.ventas=[];S.compras=[];S.honorarios=[];S.asientos=[];
  S.activos=[];S.trabajadores=[];S.asistencia={eventos:[],horas:{}};S.finiquitos=null;S.apertura=null;
  await asegurarAccesoEmpresa(EMPRESAS.activa);
  S.inventario={cargado:false,grupos:[],bodegas:[],productos:[],movimientos:[],tomas:[],ordenesCompra:[],recepciones:[]};
  S.empresa={...S.empresa,nombre:'',rut:'',domicilio:'',giro:'',codigo:'',ciudad:'',comuna:'',rep:'',rutrep:''};
  // Cargar datos de la nueva empresa
  try{const r=await window.storage.get('empresa');if(r)S.empresa={...S.empresa,...JSON.parse(r.value)};}catch(e){}
  aplicarRegimenEmpresa();
  await aplicarPlantillaPdcSiCorresponde();
  try{
    const r=await window.storage.get('pdc');
    if(r){const l=JSON.parse(r.value);if(Array.isArray(l)&&l.length){PDC.length=0;l.forEach(c=>PDC.push(c));normalizarPDC(PDC);recalcDerivadasPDC();}}
  }catch(e){}
  try{if(asegurarCuentasSistema(PDC))await window.storage.set('pdc',JSON.stringify(PDC));}catch(e){console.warn('No se pudo persistir cuentas de sistema:',e);}
  await loadYear(S.empresa.anio);
  await cargarPreproduccion();
  await cargarPiloto();
  window.__entornoBypass=false;
  await cargarDeclaracionesF29(true);
  await cargarCentros();await cargarCierresCC();await cargarComprobantes();await cargarFichasAux();await cargarLibroRem();await cargarInventario(true);
  fillEmpresaForm();updateHdr();renderSelectorEmpresa();renderInicio();
  try{aplicarPermisosUI();}catch(e){}
  rerender();
}

// ═══ REGISTRO DE CALLBACKS (inversión de dependencias) ═══
// ui.js expone wrappers; aquí inyectamos las implementaciones reales.
registrarUI({rerender, nav, renderSec});
// auth.js llama esto tras un login exitoso, sin importar app.js.
setOnAuthReady(initApp);

// ═══ EXPOSICIÓN GLOBAL PARA onclick DEL HTML ═══
// El HTML usa onclick="renderVentas()" etc. Los módulos ES tienen scope propio,
// así que hay que publicar esas funciones en window.
// Objetos de estado usados directamente en onclick del HTML
Object.assign(window,{
  renderFoliosSII, agregarRangoFolios, activarRangoFolios, recalcularPreview, actualizarCfg, imprimirPruebaFolios, reservarEImprimir, reimprimirReserva, cerrarReserva, exportarControlFolios,AF, VF, CF, REMF, AFB, PF, APF, IMB, IM, IMV, US, BD, S, getCurSec, CD, IVAC, PAGOF29, DJ, ACC});

Object.assign(window,{reiniciarMonitorFS, resumenMonitorFS, 
  // utilidades
  toast, normalizarMontos,
  // navegación y arranque
  nav, rerender, renderSec, toggleNav, cerrarNavMovil, toggleNavGroup, changeYear, saveAll, init, initApp,
  // auth / usuarios
  toggleLoginMode, submitLogin, recuperarPassword, mostrarLogin, logout,
  olvidarNav,
  renderUsuarios, abrirInvitarUsuario, editarUsuario, renderPermisosForm,
  cerrarUsuarioForm, guardarUsuario, aprobarUsuario, desactivarUsuario, renderAuditLog, renderIntegridad, migrarAsientosV2,
  // empresa / pdc / indicadores
  fillEmpresaForm, saveEmpresa, updateHdr,
  renderPDC, abrirPdcForm, editarCuenta, cerrarPdcForm, guardarCuenta, eliminarCuenta, resetPDC,
  renderIndicadores, guardarIndicadores, restaurarIndicadoresDefault, actualizarDesdeBancoCentral,
  renderIUSCTabla, setIUSC, addIUSCTramo, delIUSCTramo, restaurarIUSCTabla, setIUSCPrueba,
  renderPrevisional, guardarPrevisional, restaurarPrevisional, renderPrevisionalAccidentes, agregarTramoReforma, quitarTramoReforma,
  renderCentrosCosto, abrirFormCC, editarCC, cerrarFormCC, guardarCC, borrarCC,
  renderInventario, invSetTab, invSetFiltro, invCerrarModal,
  invAbrirGrupo, invGuardarGrupo, invAbrirBodega, invGuardarBodega,
  invAbrirProducto, invActualizarSubgrupos, invGuardarProducto,
  invDescargarPlantillaProductos, invAbrirImportProductos, invLeerProductosExcel, invAplicarImportProductos,
  invNuevoMovimiento, invMovCampo, invMovLineaCampo, invMovAgregarLinea, invMovQuitarLinea,
  invGuardarMovimiento, invVerMovimiento, invAnularMovimiento, invEditarMovimiento,
  invNuevaToma, invCrearToma, invAbrirToma, invVolverTomas, invSetFisicoToma, invSetCostoToma,
  invAgregarLineaToma, invTomaProductoCambio, invGuardarLineaToma, invCerrarToma,
  invDevolverToma, invRechazarToma, invAutorizarToma,
  invNuevaOC, invEditarOC, invOCCampo, invOCLineaCampo, invOCAgregarLinea, invOCQuitarLinea, invGuardarOC,
  invVerOC, invVolverOC, invEmitirOC, invAnularOC, invCerrarSaldoOC, invAbrirRecepcion, invRecCampo, invRecLineaCampo, invRecAgregarLote, invRecQuitarLinea,
  invGuardarRecepcion, invAnularRecepcion, invAbrirVincularFactura, invVincularFactura,
  verDetalleCC, abrirCapitalizar, confirmarCapitalizar, ccOpts, ccNombre,
  onCurvaChange, setPct, addPctAnio, delPctAnio, onTipoCentroChange,
  ejecutarCierreMensual, revertirCierreMensual, onCierreMesChange, resetCierreMes,
  acBuscar, acTecla, acElegir, acCerrarDif, inputCuenta, buscarCuentas, inputCC, ccAcBuscar, ccAcTecla, ccAcElegir, ccAcCerrarDif,
  axAcBuscar, axAcTecla, axAcElegir, axAcCerrar, lAuxElegido,
  prAcBuscar, prAcTecla, prAcElegir, prAcCerrarDif,
  marcarGuardado, marcarSucio, haySinGuardar, hayBorrador, hayCambiosConfirmados, guardarBorradoresAhora, limpiarBorradorCampos, recargarBorradoresContexto, listarBorradoresLocales, descartarBorradorLocal, descartarTodosBorradoresLocales, continuarBorradorLocal,
  actualizarBotonGuardar, guardarTodoAhora, setAutoguardado, setIntervaloAutoguardado, confirmarSalida, AG,
  abrirImportSIIVentas, cambiarPeriodoImportV, toggleAllImportV, aplicarCuentaATodosV, setBulkCuentaImpV, setBulkCuentaImp, setImportCC, aplicarCCATodos, setImportGlosa, enfocarPendienteImportC, enfocarPendienteImportV,
  toggleCSel, toggleCSelAll, limpiarCSel, eliminarCSel, toggleVSel, toggleVSelAll, limpiarVSel, eliminarVSel, cambiarFPVSel,
  abrirFichaAux, abrirFichaAuxNueva, fichaRutInput, cerrarFichaAux, setFichaCuenta, guardarFichaAuxUI,
  cmpHdrBuscar, cmpHdrTecla, cmpHdrCerrar, cmpHdrElegir, renderComprobantes, setCmpFiltro, limpiarCmpFiltro, toggleCmpDet, cmpNumeroBuscar, renderCmpNumeroList, cmpNumeroElegir, cmpNumeroElegirResultado, corregirDescuadreCmp,
  abrirCmpModal, cerrarCmpModal, cmpModalEditar, cmpModalCancelar, cmpModalGuardar,
  eliminarComprobante, anularComprobante,
  setCmpEdGlosa, setCmpEdFecha, setCmpEdCuenta, setCmpEdCampo, setCmpEdMonto, setCmpEdMontoBlur, addCmpEdLinea, delCmpEdLinea,
  abrirCmpEdDte, cerrarCmpEdDte, setCmpDteCampo, setCmpDteTipo, setCmpDteRut, cmpDteAutoTotal, guardarCmpEdDte,
  renderPagos, setPagTipo, setPagCampo, setPagFiltro, limpiarPagFiltro, togglePagSel, togglePagAll, setPagMontoParcial, ejecutarPago,
  abrirAsociarNota, cerrarAsociarNota, confirmarAsociar, quitarReferencia,
  abrirNuevoHonorario, cerrarNuevoHonorario, guardarNuevoHonorario, hdRutInput, hdProvSel, hdRecalc, hdAddDist, hdDelDist, hdDistCampo, hdProvBuscar, hdProvElegir, hdProvCerrar, hdProvTecla, hdNuevoAuxiliar,
  abrirEditorPago, cerrarEditorPago, guardarEditorPago, peCampo, peLineaCampo, peDelLinea, pePickBuscar, pePickAdd, pePickCerrar,
  corregirDesdeDiario, editarAsientoRef,
  descargarPlantillaAux, abrirImportFichas, descargarPlantillaAuxActual, abrirImportFichasActual,
  renderImportModalVentas, confirmarImportacionV, cerrarImportModalVentas,
  buscarCT, cerrarBuscarCT, navCT, aplicarCT, abrirCTModal, cerrarCTModal, renderCTModal,
  setCTCuenta, setCTCampo, setCTHeader, addCTLinea, delCTLinea, nuevoCT, editarCT, guardarCT,
  toggleCTDist, setCTDist, addCTDist, delCTDist, repartirCTDist,
  borrarCT, copiarCTaEmpresa,
  // apertura
  renderApertura, abrirApertura, cerrarApertura, apRenderLineas, apLCd, apLRut, apLVal,
  apDelLinea, apAddLinea, apPrellenar, apUpdCuadre, guardarApertura, eliminarApertura,
  abrirImpBalModal, cerrarImpBalModal, toggleAllBal, confirmarImportBalance, renderImpBalModal,
  descargarPlantillaBalance,
  abrirAperturaAux, cerrarAperturaAux, renderAperturaAux, apxAddDoc, apxDelDoc,
  apxCampo, apxRut, apxAuxElegido, apxActualizarCuadre, guardarAperturaAux,
  descargarPlantillaAperturaAux, APX,
  // ventas
  onMesChangeV, limpiarFiltrosV, renderVentas, abrirVF, editarVenta, cerrarVF,
  vfRutInput, vfCheckDup, vfDteChanged, vfRefrescarDocs, vfSeleccionarReferencia, vfCalcTotals, vfAutoCalc, guardarVenta, setVfCuenta, eliminarVenta,
  // compras
  onMesChangeC, limpiarFiltrosC, renderCompras, abrirCF, editarCompra, cerrarCF,
  cfRutInput, cfCheckDup, cfDteChanged, cfRefrescarDocs, cfSeleccionarReferencia, cfCalcTotals, renderDist, addDist, delDist, updCfCheck,
  guardarCompra, eliminarCompra, abrirImportSII, abrirImportModal, cambiarPeriodoImport,
  cerrarImportModal, toggleImportDoc, toggleAllImport, setImportCuenta,
  aplicarCuentaATodos, confirmarImportacion, setImportReferencia, renderImportModal, pn,
  cambiarModoImport, verDuplicadoC, renderCDupAlert,
  // honorarios
  renderHon, setHonCampo, uhon, addHon, delHon, saveHon, abrirHonComprobante, cerrarHonComprobante, actualizarPreviewHon, guardarHonComprobante, anularHonDesdeComprobante, seleccionarPrestadorHon,
  // asientos
  renderAsientos, abrirForm, cerrarForm, editarAsiento, duplicarAsiento, anularAsiento,
  eliminarAsiento, guardarAsiento, addLinea, delLinea, renderLineas, lCd, lVal, lValFmt, lValFmtBlur, lRut,
  toggleAs, updCuadre, limpiarFormAsiento, sigAsiento, abrirDteModal, cerrarDteModal,
  dtmGuardar, dtmTipoChanged, dtmRefresh, dtmCalcTotals, dtmRutInput, dtmCheckDup, dtmAddDist, dtmDelDist,
  dtmRenderDist, dtmUpdDistCheck, dtmRemover, quitarDte, folioPreviewDte, abrirAsientoDesde,
  // activo fijo
  renderActivoFijo, abrirFormAF, onCatAF, onCompraAF, cerrarFormAF, previewAF, guardarAF, editarAF,
  eliminarAF, generarAsientoDepreciacion,
  // remuneraciones
  renderRemuneraciones, abrirFormTrabajador, cerrarFormTrabajador, onSaludChange, onGratModoChange,
  renderLibroRem, setRemView, getRemView, tabsRemuneraciones, cerrarMesRem, reabrirMesRem,
  exportarLibroRemExcel, exportarLRECSV, mostrarValidacionLRE, validarLibroLRE, construirRegistroLRE, LRE_CONCEPTOS, libroDelMes,
  previewLiq, guardarTrabajador, editarTrabajador, eliminarTrabajador, onParamRem,
  verLiquidacion, generarAsientoRemuneraciones, onTipoPagoChange, imprimirLiquidacion, sugerirNombresPrevired,
  exportarPrevired, mostrarValidacionPrevired, setCfgPrevired, setCodigoPrevired, exportarImposicionesExcel,
  renderFiniquitos, nuevoFiniquito, editarFiniquito, volverFiniquitos, onFinCambio, agregarFilaFin, quitarFilaFin,
        previewFiniquito, editarTextoFiniquito, quitarTextoFiniquito, subirTextoFiniquito, guardarFiniquito, verFiniquito,
        eliminarFiniquito, marcarRatificado, imprimirFiniquito, verPlantillasFiniquito, editarPlantillaFin, nuevaPlantillaFin,
        duplicarPlantillaFin, cancelarPlantillaFin, subirPlantillaFin, guardarPlantillaFin, restaurarPlantillaFin,
        eliminarPlantillaFin, insertarMarcadorFin, abrirAsientoFiniquito, cerrarAsientoFiniquito, onAsientoFinCambio,
        generarAsientoFiniquito,
  pdfLiquidacionesMasivo, pdfLiquidacion, pdfLibroRem, imprimirRemuneraciones,
  renderVacaciones, abrirFormVacaciones, abrirConfigVacaciones, guardarConfigVacaciones, guardarVacaciones,
  guardarFeriadosExtra, previewVacaciones, exportarVacacionesExcel,
  renderAsistencia, abrirFormAsistencia, editarEventoAsistencia, cerrarFormAsistencia, guardarEventoAsistencia,
  eliminarEventoAsistencia, setHorasMes, onAsisTipoChange,
  // cierre
  renderCierre, generarAsientoCierre, reabrirEjercicio, renderProvisiones, previewProvInc, previewProvFer,
  generarProvisionIncobrables, generarProvisionFeriado, renderCorreccion, previewCM,
  // reportes
  renderDiario, setDiarioQ, renderMayor, renderBalance, renderBalance8, exportarBalance8Excel, onCmpYear, renderResultados,
  renderLibrosCV,setLibroCVTipo,setLibroCVMes,setLibroCVDte,exportarLibroCVExcel,exportarLibroCVCSV,
  onDiarioMes, setDiarioFecha, limpiarFiltrosDiario, exportarDiarioExcel,
  onMayorMes, setMayorFecha, setMayorQ, limpiarFiltrosMayor, renderMayorTabla, exportarMayorExcel, toggleMayorCuenta,
  renderIntegridad,renderPilotoUI,guardarPilotoUI,certificarPilotoUI,invalidarPilotoUI,migrarAsientosV2,renderCierresMensuales,cerrarMesContableOperativo,reabrirMesContableOperativo,
  setChecklistPreprod,habilitarEscriturasPrueba,bloquearEscriturasPrueba,activarProduccion,volverAPrueba,descargarActaHabilitacion,actualizarBadgeEntorno,
  ejecutarRegresionContableUI,ejecutarPruebasProductivasUI,iniciarPruebaConcurrenciaUI,prepararPruebaConcurrenciaUI,escribirPruebaConcurrenciaUI,verificarPruebaConcurrenciaUI,ejecutarSimulacroRestauracionUI,crearSnapshotUI,verificarSnapshotUI,restaurarSnapshotUI,
  renderCargaDatos, descargarPlantillaDatos, abrirCargaDatos, renderSistema,
  renombrarEsteDispositivo,
  renderCompensacionIVA, generarAsientoIVA, setIvacCuenta, setIvacCampo, resetIvacCuentas, crearCuentaRemanente,
  renderPagoF29, generarAsientoPagoF29, setPagoF29Cuenta, setPagoF29Campo, setPagoF29Monto,
  togglePagoF29, resetPagoF29, usarSugeridoF29,
  setAuxTab, setAuxView, setAuxQ, verTodosAux, ocultarTodosAux, toggleAux, renderAuxiliares, toggleAgingDetalle,
  auxPorRut, abrirReporteAuxDe, abrirReporteAux, cerrarReporteAux, setReporteAuxVista,
  renderReporteAux, imprimirReporteAux, exportarReporteAuxExcel,
  renderF29, renderPPM, setF29Declarado, setF29DeclCampo, setF29UTM, setRemanenteInicialF29, setUTMManual, buscarUTMNuevas, copiarCalculadoAF29, guardarBorradorF29, presentarF29, reabrirF29, setFCView, renderFlujoCaja,
  // asignación manual de centros de costo
  renderAsigCC, resetAsigCC, setAsigCC, limpiarFiltrosCC, setCCMov, toggleSelCC, selTodosCC,
  limpiarSelCC, setBulkCC, asignarSelCC, exportarAsigCCExcel, pendientesCC,
  // declaraciones juradas de renta
  renderDJ, cargarDJ, resetDJ, setDJVerTodas, setDJEstado, editarDJ, nuevaDJ, cerrarEditorDJ,
  guardarDJ, borrarDJ, restaurarCatalogoDJ, exportarDJExcel,
  renderRenta, setRentaTab, setRentaParam, restaurarTasaLegal, toggleRechazada,
  onRegimenEmpresaChange, pintarRegimen, onRegimenChange, aplicarPermisosUI,
  toggleAyuda, actualizarAyuda, renderInicio, abrirEmpresaInicio, alternarVerOtras, botonVerOtras, verificarActualizacion,
  addRentaLinea, setRentaLinea, delRentaLinea, setRentaCredito, exportRentaXLSX,
  renderConciliacion, onSaldoBancoChange, toggleConciliado, marcarTodosConciliados,
  cargarCartola, autoConciliarCartola,
  // búsqueda / backup
  abrirBusqueda, cerrarBusqueda, ejecutarBusqueda, navBusqueda, irAResultado,
  cambiarTema, aplicarTema, onCambiarEmpresa, renderSelectorEmpresa, recargarEmpresaActiva,
  renderEmpresas, abrirFormEmpresa, cerrarFormEmpresa, editarEmpresaCat, guardarEmpresaCat,
  abrirCompartir, cerrarCompartir, guardarCompartir, reclamarEmpresa, restaurarEmpresa, descartarEmpresaHuerfana, aplicarVisibilidad,
  seleccionarEmpresa, borrarEmpresa, onMarcoChange, onPlantillaChange,
  exportarExcelManual, conectarBD, fsBackupToCloud, fsRestoreFromCloud, importarExcelBD,
});

// Encabezado de impresión
window.addEventListener('beforeprint', prepararImpresion);


// Puentes que traducen el tab activo a 'cliente'/'proveedor'
function tipoAuxActual(){
  return (typeof AUX_TAB!=='undefined'?AUX_TAB:'c')==='c'?'cliente':'proveedor';
}
function descargarPlantillaAuxActual(){descargarPlantillaAux(tipoAuxActual());}
function abrirImportFichasActual(){abrirImportFichas(tipoAuxActual());}

// ═══ ARRANQUE ═══
initActualizador(); // bloquea y actualiza obligatoriamente si el servidor publica otra versión
initTema();
initMoneyInputs();   // montos enteros con separador de miles en toda la aplicación
initAyuda();         // ampolleta 💡 por sección: las ayudas quedan plegadas
initAvisoSalida();   // aviso si se cierra con cambios sin guardar
initAutoguardado();  // temporizador + guardado al dejar la pestaña o cerrar
// storage llama esto cuando frena una escritura sobre una clave no leída
let _avisoBloqueo=0;
// Otro equipo escribió el mismo libro: se fusionó, hay que avisarlo
window.__avisarFusion=(clave,r)=>{
  const de=r.otro?` de ${r.otro}`:'';
  let msg=`🔀 "${clave}" se fusionó con los cambios${de}`;
  if(r.agregados)msg+=` · ${r.agregados} registro(s) tuyos agregados`;
  if(r.revividos>0)msg+=` · ${r.revividos} venían del otro equipo`;
  toast(msg+' — recarga para verlo completo');
  console.warn('Fusión en',clave,r);
};
// No se pudo fusionar solo (no es una lista de registros): decide el usuario
window.__avisarConflicto=(clave,otro)=>{
  toast(`⚠️ "${clave}" fue modificado desde ${otro||'otro equipo'} — no se guardó para no pisarlo. Recarga y vuelve a aplicar tu cambio.`,'e');
  console.error('Conflicto sin fusión posible en',clave,'—',otro);
};
window.__avisarBloqueo=(clave,motivo)=>{
  try{actualizarBotonGuardar();}catch(e){}
  const ahora=Date.now();
  if(ahora-_avisoBloqueo<8000)return;      // no repetir en cada tecla
  _avisoBloqueo=ahora;
  toast(`🚫 No se guardó "${clave}": no se pudo leer desde la nube (${motivo}). Recarga la página.`,'e');
};   // aplicar tema guardado antes de renderizar
init();
