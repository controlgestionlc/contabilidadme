// auxdocs.js — Cómo se ordenan y se saldan los documentos de un auxiliar.
//
// Módulo compartido por la vista Detalle de Auxiliares y por el reporte por
// auxiliar, para que ambos muestren exactamente lo mismo.
//
// Dos reglas:
//
//  1. Una nota de crédito o débito CON folio de referencia se muestra colgando
//     de su factura, no suelta en la línea del tiempo. Leer el auxiliar de un
//     proveedor con muchas notas era imposible cuando cada una aparecía por su
//     fecha, lejos del documento que corrige.
//
//  2. El saldo de una factura es su total menos los pagos y menos el efecto de
//     las notas que la referencian. Es el saldo que de verdad queda por cobrar
//     o pagar, y el que decide si un documento entra en la vista «sólo con
//     saldo pendiente».

import {S} from './state.js';
import {dteV, dteC} from './core.js';
import {pagosDocumento} from './motor-contable.js';

// Documento original en el libro de ventas o compras, si el movimiento viene
// de ahí. Los movimientos de asientos manuales y de apertura no lo tienen.
export function docOriginal(d,tipo){
  if(!d||!d.docOriginalId)return null;
  const arr=tipo==='cliente'?S.ventas:S.compras;
  return arr.find(x=>x.id===d.docOriginalId)||null;
}

const signoDe=(tipoDTE,tipo)=>((tipo==='cliente'?dteV(tipoDTE):dteC(tipoDTE))?.signo)||1;

// ¿Es nota de crédito o débito? (signo negativo, o ND 56)
export function esNota(d,tipo){
  if(!d||d.tipo!=='doc')return false;
  return signoDe(d.tipoDTE,tipo)<0||+d.tipoDTE===56;
}

// Folio de la factura referenciada por un documento (nota de crédito/débito).
// Reconoce dos orígenes: `folioRef` (asociación manual desde el auxiliar/Pagos)
// y `referencia.folio` (referencia capturada en el importador RCV o en el
// formulario). La manual tiene prioridad como override.
export function refFolioDoc(orig){
  if(!orig)return '';
  if(orig.folioRef)return String(orig.folioRef).trim();
  if(orig.referencia&&orig.referencia.folio)return String(orig.referencia.folio).trim();
  return '';
}

// Folio de la factura que referencia esta nota, o '' si va suelta
export function folioRefDe(d,tipo){
  return refFolioDoc(docOriginal(d,tipo));
}

// ── Saldo por documento ──
// Para una factura: total − pagos − efecto de sus notas referenciadas.
// Para una nota suelta: su propio monto menos lo que se le haya pagado.
// Devuelve {total, pagado, notas, saldo} en moneda con signo de presentación
// (positivo = queda por cobrar/pagar).
export function saldoDeDocumento(d,tipo,notasHijas){
  const orig=docOriginal(d,tipo);
  if(!orig)return {total:d.montoSigno||0,pagado:0,notas:0,saldo:d.montoSigno||0,sinLibro:true};
  const signo=signoDe(orig.tipoDTE,tipo);
  const total=(orig.total||0)*signo;
  const pagado=pagosDocumento(orig,tipo==='cliente'?'cliente':'proveedor',S.asientos).reduce((s,p)=>s+(p.monto||0),0);
  const notas=(notasHijas||[]).reduce((s,n)=>{
    const o=docOriginal(n,tipo);
    if(!o)return s;
    return s+((o.total||0)*signoDe(o.tipoDTE,tipo));
  },0);
  return {total,pagado,notas,saldo:total+notas-pagado,sinLibro:false};
}

// ── Ordenar poniendo cada nota bajo su factura ──
//
// Devuelve una lista plana lista para pintar, donde cada elemento lleva:
//   .__nivel      0 = documento principal, 1 = nota colgando de él
//   .__notas      (sólo en las facturas) las notas que la referencian
//   .__saldoDoc   resultado de saldoDeDocumento, para filtrar y mostrar
//
// Las notas sin referencia y los movimientos que no son documentos conservan
// su lugar cronológico: no cuelgan de nada.
export function ordenarConNotas(docs,tipo){
  const lista=[...(docs||[])].sort((x,y)=>String(x.fecha||'').localeCompare(String(y.fecha||'')));

  // Agrupar las notas referenciadas por el folio al que apuntan
  const notasPorFolio={};
  const colgadas=new Set();
  lista.forEach(d=>{
    if(!esNota(d,tipo))return;
    const ref=folioRefDe(d,tipo);
    if(!ref)return;
    (notasPorFolio[ref]||(notasPorFolio[ref]=[])).push(d);
  });

  // Agrupar los pagos/cobros que referencian un documento, por docId (preferido)
  // o por folio. Así se muestran colgando de su factura y no como línea suelta.
  const pagosPorDocId={}, pagosPorFolio={};
  lista.forEach(d=>{
    if(d.tipo!=='manual'||!d.esPago)return;
    if(d.refDocId)(pagosPorDocId[String(d.refDocId)]||(pagosPorDocId[String(d.refDocId)]=[])).push(d);
    else if(d.refFolio)(pagosPorFolio[d.refFolio]||(pagosPorFolio[d.refFolio]=[])).push(d);
  });
  // ¿Existe en este auxiliar la factura a la que apunta el pago?
  const facturaPresente=(docId,folio)=>lista.some(f=>f.tipo==='doc'&&!esNota(f,tipo)&&(
    (docId&&String(f.docOriginalId||'')===String(docId))||
    (folio&&String(f.numero||'').trim()===String(folio))));

  const salida=[];
  lista.forEach(d=>{
    if(colgadas.has(d))return;
    // ¿Es una nota que ya va colgada de una factura presente en este auxiliar?
    if(esNota(d,tipo)){
      const ref=folioRefDe(d,tipo);
      if(ref&&lista.some(f=>!esNota(f,tipo)&&String(f.numero||'').trim()===ref))return;
    }
    // ¿Es un pago que cuelga de una factura presente? Se pinta bajo ella.
    if(d.tipo==='manual'&&d.esPago&&facturaPresente(d.refDocId,d.refFolio))return;

    const num=String(d.numero||'').trim();
    const esDocPrincipal=d.tipo==='doc'&&!esNota(d,tipo);
    // Notas hijas: afectan el saldo del documento.
    const notasH=(esDocPrincipal&&num&&notasPorFolio[num])?notasPorFolio[num]:[];
    // Pagos hijos: NO se restan otra vez (saldoDeDocumento ya descuenta lo pagado
    // vía pagosDocumento); solo se muestran bajo la factura.
    const pagosH=esDocPrincipal
      ?[...(pagosPorDocId[String(d.docOriginalId||'')]||[]),...(pagosPorFolio[num]||[])]
      :[];
    notasH.forEach(n=>colgadas.add(n));
    pagosH.forEach(p=>colgadas.add(p));
    d.__nivel=0;
    d.__notas=notasH;                 // solo notas para el cálculo de saldo
    d.__hijas=[...notasH,...pagosH];  // todo lo que cuelga, para "sólo con saldo"
    d.__saldoDoc=d.tipo==='doc'?saldoDeDocumento(d,tipo,notasH):null;
    salida.push(d);
    // Render de las hijas (notas + pagos) en orden cronológico
    [...notasH,...pagosH]
      .sort((a,b)=>String(a.fecha||'').localeCompare(String(b.fecha||'')))
      .forEach(h=>{
        h.__nivel=1;
        h.__notas=[];h.__hijas=[];
        h.__saldoDoc=h.tipo==='doc'?saldoDeDocumento(h,tipo,[]):null;
        salida.push(h);
      });
  });
  return salida;
}

// ¿Este documento queda con saldo pendiente?
// Una nota colgada no se evalúa por su cuenta: vive con su factura.
export function tieneSaldo(d){
  if(d.__nivel===1)return false;
  if(!d.__saldoDoc)return Math.abs(d.montoSigno||0)>1;   // movimientos manuales
  return Math.abs(d.__saldoDoc.saldo)>1;
}

// Filtra dejando sólo los documentos con saldo, arrastrando sus notas.
export function soloConSaldo(lista){
  const salida=[];
  lista.forEach(d=>{
    if(d.__nivel===1)return;              // notas y pagos entran con su factura
    if(!tieneSaldo(d))return;
    salida.push(d);
    (d.__hijas||d.__notas||[]).forEach(n=>salida.push(n));
  });
  return salida;
}
