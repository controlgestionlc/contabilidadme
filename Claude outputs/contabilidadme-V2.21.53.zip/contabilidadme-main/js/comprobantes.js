// comprobantes.js — Vista unificada de asientos del libro diario
//
// A diferencia de "Asientos Manuales", que solo lista los que el usuario
// escribió a mano, esta vista muestra TODOS los asientos del libro diario:
// apertura, resúmenes automáticos de ventas/compras/honorarios, y manuales.
//
// Cada uno permite editarse: los manuales abren el editor de asientos, los
// automáticos llevan al origen (Libro de Ventas/Compras/Honorarios) para
// que se corrijan los documentos que los generaron.

import {fmt, fmtC, MESES, pdcNm, today, toast, rutFmt, dteV, dteC, rutParse, DTE_VENTAS, DTE_COMPRAS, IVA, pn} from './core.js';
import {S, getCurSec} from './state.js';
import {nav, rerender} from './ui.js';
import {genDiario, destinoEdicion, corregirDesdeDiario, editarAsientoRef} from './reportes.js';
import {editarAsiento, proxFolioAsiento, CUENTAS_AUX, esAux, asegurarFormNuevo} from './asientos.js';
import {inputCuenta} from './buscadorcuentas.js';
import {logAccion} from './firebase.js';
import {ejercicioCerrado,persistirAsientosCritico,persistirClavesCritico,anularDocumentoContabilizado,anularAsientoDocumento} from './contabilidad-v2.js';
import {inferirDteDesdeAsiento} from './dte-autocompletar.js';
import {abrirEditorPago} from './pagoeditor.js';
import {infoReversa, eliminarAsientoAuto} from './reversas.js';

// Filtros
let CMP_FILTRO={mes:'',origen:'',texto:'',numero:''};

function mesOptsCmp(){
  let h='<option value="">Todos los meses</option>';
  for(let i=0;i<12;i++)h+=`<option value="${i+1}" ${CMP_FILTRO.mes===String(i+1)?'selected':''}>${MESES[i]}</option>`;
  return h;
}

function origenLbl(e){
  if(e.origen==='apertura')return {ic:'🔰',nm:'Apertura',c:'#c9a227'};
  if(e.origen==='manual')return {ic:'✏️',nm:'Manual',c:'#3fb950'};
  if(e.fuente==='ventas')return {ic:'🛒',nm:'Ventas',c:'#58a6ff'};
  if(e.fuente==='compras')return {ic:'🧾',nm:'Compras',c:'#f0883e'};
  if(e.fuente==='honorarios')return {ic:'📝',nm:'Honorarios',c:'#c377dc'};
  return {ic:'⚙️',nm:'Automático',c:'var(--mt)'};
}

// Escapa comillas para poder meter el texto en un atributo title="…"
const attr=t=>String(t||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');

let CMP_ENTRIES=[];        // cachea las entries actuales para el modal
let CMP_ALERT_ENTRIES=[];  // descuadres exactos mostrados en la alerta
let CMP_NUM_ENTRIES=[];    // resultados exactos del buscador por número
let CMP_MODAL={mode:'view',idx:-1,edit:null};

function mismaEntradaCmp(a,b){
  if(!a||!b)return false;
  if(a.asientoId||b.asientoId)return !!a.asientoId&&a.asientoId===b.asientoId;
  if(a.docId||b.docId)return !!a.docId&&a.docId===b.docId&&a.fuente===b.fuente;
  if(a.origen==='apertura'||b.origen==='apertura')return a.origen==='apertura'&&b.origen==='apertura';
  return a.origen===b.origen&&String(a.n)===String(b.n)&&a.fecha===b.fecha&&a.glosa===b.glosa;
}
function entradaActualCmp(ref){return genDiario().find(e=>mismaEntradaCmp(e,ref))||null;}
function abrirEntradaCmp(ref){
  const actual=entradaActualCmp(ref)||ref;if(!actual)return;
  CMP_FILTRO.numero=String(actual.n??'');
  CMP_FILTRO.mes='';CMP_FILTRO.origen='';CMP_FILTRO.texto='';
  renderCmpNumeroList([]);renderComprobantes();
  const idx=(CMP_ENTRIES||[]).findIndex(e=>mismaEntradaCmp(e,actual));
  if(idx>=0)setTimeout(()=>abrirCmpModal(idx),100);
}

export function renderComprobantes(){
  const cont=document.getElementById('comprobantes-content');
  if(!cont)return;
  // Comprobantes abre en modo registro: formulario de asiento nuevo listo.
  // Solo si la sección está a la vista (cerrarForm también llama aquí).
  const secActual=getCurSec();
  if(secActual==='comprobantes'||secActual==='asientos')asegurarFormNuevo();

  let entries=genDiario();
  const entriesGlobal=[...entries];

  // Filtros
  if(CMP_FILTRO.mes){
    const m=+CMP_FILTRO.mes;
    entries=entries.filter(e=>{
      const em=+String(e.fecha).slice(5,7);
      return em===m;
    });
  }
  if(CMP_FILTRO.origen){
    entries=entries.filter(e=>{
      if(CMP_FILTRO.origen==='apertura')return e.origen==='apertura';
      if(CMP_FILTRO.origen==='manual')return e.origen==='manual';
      if(CMP_FILTRO.origen==='auto')return e.origen==='auto';
      // filtros por fuente
      return e.fuente===CMP_FILTRO.origen;
    });
  }
  if(CMP_FILTRO.texto){
    const t=CMP_FILTRO.texto.toLowerCase().trim();
    // Buscar también por N° de comprobante (folio) — coincidencia exacta o parcial
    entries=entries.filter(e=>{
      if(String(e.n||'').includes(t))return true;
      if((e.glosa||'').toLowerCase().includes(t))return true;
      return e.movs.some(m=>String(m.cd).includes(t)||(m.nm||'').toLowerCase().includes(t));
    });
  }
  if(CMP_FILTRO.numero){
    // Búsqueda EXACTA o "empieza con" del N° de comprobante
    const q=String(CMP_FILTRO.numero).trim();
    entries=entries.filter(e=>String(e.n||'').startsWith(q));
  }

  // Detectar comprobantes descuadrados (útil para el filtro y para la alerta)
  const cuadraE=e=>{
    const d=e.movs.reduce((s,m)=>s+(m.debe||0),0);
    const h=e.movs.reduce((s,m)=>s+(m.haber||0),0);
    return Math.abs(d-h)<0.000001;
  };
  const descuadresGlobal=entriesGlobal.filter(e=>!cuadraE(e));
  if(CMP_FILTRO.origen==='descuadrados'){
    entries=entries.filter(e=>!cuadraE(e));
  }
  // La alerta es global, no depende del filtro visual activo. Así no puede
  // desaparecer sólo porque el usuario filtró otro mes/origen; se elimina
  // únicamente cuando el asiento realmente vuelve a cuadrar.
  const descuadres=descuadresGlobal;
  CMP_ALERT_ENTRIES=[...descuadres];

  // Resumen
  const totD=entries.reduce((s,e)=>s+e.movs.reduce((ss,m)=>ss+(m.debe||0),0),0);
  const totH=entries.reduce((s,e)=>s+e.movs.reduce((ss,m)=>ss+(m.haber||0),0),0);
  const cntAuto=entries.filter(e=>e.origen==='auto').length;
  const cntMan=entries.filter(e=>e.origen==='manual').length;
  const cntAp=entries.filter(e=>e.origen==='apertura').length;
  const totalFiltrado=entries.length;

  // Panel de alerta cuando hay descuadres (y no estamos ya filtrando solo por ellos)
  let alerta='';
  if(descuadres.length&&CMP_FILTRO.origen!=='descuadrados'){
    const botonNumero=(e,i)=>{const n=String(e.n??e.numeroContable??'S/N');return `<button type="button" class="cmp-alert-link" onclick="corregirDescuadreCmp(${i})" title="Abrir y corregir comprobante N° ${attr(n)}">N° ${attr(n)}</button>`;};
    const detalleNumeros=descuadres.length<=6
      ? descuadres.map(botonNumero).join(' ')
      : `${descuadres.slice(0,6).map(botonNumero).join(' ')} <span style="font-size:11px;color:var(--mt)">y ${descuadres.length-6} más</span>`;
    alerta=`<div style="background:rgba(248,81,73,.08);border:1px solid var(--err);border-radius:8px;padding:12px 14px;margin-bottom:14px;display:flex;align-items:center;gap:10px;flex-wrap:wrap">
      <span style="font-size:16px">⚠️</span>
      <span style="font-weight:700;color:var(--err)">${descuadres.length} comprobante${descuadres.length===1?'':'s'} descuadrado${descuadres.length===1?'':'s'}</span>
      <span style="font-size:11px;color:var(--mt)">— toca el N° para abrir el origen y corregirlo</span>
      <div style="display:flex;gap:6px;flex-wrap:wrap;flex:1 1 100%;color:var(--err)" aria-label="Números de comprobantes descuadrados">${detalleNumeros}</div>
      <button class="btn btn-d" style="font-size:11px;margin-left:auto" onclick="setCmpFiltro('origen','descuadrados')">Ver solo descuadrados</button>
    </div>`;
  }

  let h=alerta+`<div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap">
    <button class="btn btn-p" onclick="abrirNuevoHonorario()" title="Registrar una boleta de honorarios como documento del prestador (proveedor)">📝 Nuevo honorario</button>
  </div>
  <div class="filter-row" style="margin-bottom:14px;flex-wrap:wrap;align-items:flex-end">
    <span class="f-lbl">Filtrar:</span>
    <select onchange="setCmpFiltro('mes',this.value)">${mesOptsCmp()}</select>
    <select onchange="setCmpFiltro('origen',this.value)">
      <option value="">Todos los orígenes</option>
      <option value="apertura" ${CMP_FILTRO.origen==='apertura'?'selected':''}>🔰 Apertura</option>
      <option value="manual" ${CMP_FILTRO.origen==='manual'?'selected':''}>✏️ Manuales</option>
      <option value="auto" ${CMP_FILTRO.origen==='auto'?'selected':''}>⚙️ Todos automáticos</option>
      <option value="ventas" ${CMP_FILTRO.origen==='ventas'?'selected':''}>🛒 Auto ventas</option>
      <option value="compras" ${CMP_FILTRO.origen==='compras'?'selected':''}>🧾 Auto compras</option>
      <option value="honorarios" ${CMP_FILTRO.origen==='honorarios'?'selected':''}>📝 Auto honorarios</option>
      <option value="descuadrados" ${CMP_FILTRO.origen==='descuadrados'?'selected':''}>⚠️ Solo descuadrados</option>
    </select>
    <div style="position:relative;min-width:150px">
      <input type="text" id="cmp-num-input" inputmode="numeric" placeholder="N° comprobante…" autocomplete="off"
        value="${CMP_FILTRO.numero.replace(/"/g,'&quot;')}"
        oninput="cmpNumeroBuscar(this.value)"
        onfocus="cmpNumeroBuscar(this.value)"
        onblur="setTimeout(()=>renderCmpNumeroList([]),160)"
        style="width:100%">
      <div id="cmp-num-list" class="ac-lista" style="display:none;min-width:280px"></div>
    </div>
    <input type="search" id="cmp-texto-input" placeholder="Buscar por glosa o cuenta…" autocomplete="off" enterkeyhint="search"
      value="${CMP_FILTRO.texto.replace(/"/g,'&quot;')}"
      oninput="setCmpFiltro('texto',this.value)" style="min-width:180px">
    <button class="btn btn-g" onclick="limpiarCmpFiltro()">Limpiar</button>
    <span class="doc-count">${entries.length} comprobantes${cntAp?' · '+cntAp+' apertura':''}${cntAuto?' · '+cntAuto+' automáticos':''}${cntMan?' · '+cntMan+' manuales':''}</span>
  </div>`;

  if(!entries.length){
    h+=`<div style="text-align:center;padding:40px;color:var(--mt)">
      <div style="font-size:36px;margin-bottom:8px">📖</div>
      No hay comprobantes que coincidan con los filtros
    </div>`;
    cont.innerHTML=h;
    return;
  }

  // Sin filtro activo: mostrar solo los últimos 5 (los más recientes) para no
  // cargar cientos de filas. Al buscar/filtrar se muestran todos los que
  // coincidan. genDiario viene ordenado ascendente, así que "últimos" = final.
  const hayFiltro=!!(CMP_FILTRO.mes||CMP_FILTRO.origen||CMP_FILTRO.texto||CMP_FILTRO.numero);
  const LIMITE_CMP=5;
  let ocultosCmp=0;
  if(!hayFiltro&&entries.length>LIMITE_CMP){
    ocultosCmp=entries.length-LIMITE_CMP;
    entries=entries.slice(-LIMITE_CMP);
  }
  if(ocultosCmp){
    h+=`<div style="background:rgba(88,166,255,.06);border:1px solid rgba(88,166,255,.25);color:var(--info);border-radius:8px;padding:10px 14px;margin-bottom:14px;font-size:12px">
      📄 Mostrando los <strong>${LIMITE_CMP} más recientes</strong> de ${totalFiltrado}. Usa el buscador o los filtros para ver el resto.
    </div>`;
  }

  // En móvil los comprobantes se presentan como fichas: una tabla de siete
  // columnas obliga a desplazarse horizontalmente y termina partiendo los
  // montos en varias líneas. Escritorio conserva la tabla completa.
  h+='<div class="cmp-mobile-list">';
  entries.forEach((e,i)=>{
    const o=origenLbl(e);
    const d=e.movs.reduce((s,m)=>s+(+m.debe||0),0),a=e.movs.reduce((s,m)=>s+(+m.haber||0),0);
    const desc=Math.abs(d-a)>=0.000001;
    const dst=destinoEdicion(e);
    const accion=dst?`<button class="btn ${desc?'btn-d':'btn-i'} cmp-mobile-action" onclick="event.stopPropagation();${dst.fn}">${desc?'⚠️ Corregir':dst.ic+' '+dst.lbl}</button>`:`<button class="btn btn-g cmp-mobile-action" onclick="event.stopPropagation();abrirCmpModal(${i})">👁 Ver</button>`;
    h+=`<article class="cmp-mobile-card${desc?' is-error':''}" onclick="abrirCmpModal(${i})">
      <div class="cmp-mobile-head"><strong>N° ${e.n}</strong><span>${e.fecha}</span><span class="cmp-mobile-origin" style="--cmp-origin:${o.c}">${o.ic} ${o.nm}</span></div>
      <div class="cmp-mobile-glosa">${e.glosa||'(sin glosa)'}${desc?`<span class="cmp-mobile-error">⚠ Descuadre ${fmtC(Math.abs(d-a))}</span>`:''}</div>
      <div class="cmp-mobile-money"><div><small>DEBE</small><strong>${fmtC(d)}</strong></div><div><small>HABER</small><strong>${fmtC(a)}</strong></div></div>
      <div class="cmp-mobile-foot"><span>${e.movs.length} línea${e.movs.length===1?'':'s'}</span>${accion}</div>
    </article>`;
  });
  h+='</div>';

  // Tabla de comprobantes para escritorio/tablet ancho.
  h+='<div class="card-np cmp-desktop-wrap" style="margin-bottom:14px"><div class="tw"><table class="cmp-desktop-table" style="font-size:12px">';
  h+=`<thead><tr>
    <th class="tl" style="width:50px">N°</th>
    <th class="tl" style="width:90px">FECHA</th>
    <th class="tl" style="width:110px">ORIGEN</th>
    <th class="tl">GLOSA</th>
    <th style="text-align:right;width:120px">DEBE</th>
    <th style="text-align:right;width:120px">HABER</th>
    <th style="width:110px"></th>
  </tr></thead><tbody>`;

  entries.forEach((e,i)=>{
    const o=origenLbl(e);
    const totED=e.movs.reduce((s,m)=>s+(m.debe||0),0);
    const totEH=e.movs.reduce((s,m)=>s+(m.haber||0),0);
    const detId='cmp-det-'+i;
    const anulado=e.anulado?' opacity:.5;text-decoration:line-through;':'';
    const descuadrado=Math.abs(totED-totEH)>=0.000001;
    const estiloFila=(anulado||descuadrado)?` style="${anulado}${descuadrado?'background:rgba(248,81,73,.05);':''}"`:'';
    const estiloTotal=descuadrado?'color:var(--err);font-weight:700':'font-family:var(--mono)';
    const badgeDescuadre=descuadrado
      ?` <span style="background:rgba(248,81,73,.15);color:var(--err);padding:1px 6px;border-radius:3px;font-size:9px;font-weight:700;margin-left:6px">⚠ DESCUADRE ${fmtC(Math.abs(totED-totEH))}</span>`
      :'';

    // Acción según origen — el destino lo decide destinoEdicion(), la misma
    // función que usa el Libro Diario, para que el botón haga lo mismo en las
    // dos pantallas. Si hay descuadre la etiqueta cambia a "Corregir".
    // Ningún comprobante queda sin acción: los orígenes que no tienen editor
    // propio ofrecen abrir el comprobante, donde sí se puede convertir a manual.
    const dst=destinoEdicion(e);
    const btnEditar=dst
      ? `<button class="btn btn-i" style="font-size:10px" onclick="${dst.fn}" title="${attr(dst.hint)}">${dst.ic} ${descuadrado?'Corregir':dst.lbl}</button>`
      : `<button class="btn btn-g" style="font-size:10px" onclick="abrirCmpModal(${i})" title="Ver el comprobante completo">👁 Ver</button>`;

    // Toda la fila abre el modal de vista/edición del comprobante
    // (el índice del array `entries` va como referencia)
    h+=`<tr${estiloFila} style="${estiloFila?estiloFila.slice(8,-1)+';':''}cursor:pointer" onclick="abrirCmpModal(${i})">
      <td class="tl" style="font-family:var(--mono);font-weight:600">${e.n}</td>
      <td class="tl" style="font-family:var(--mono);font-size:11px">${e.fecha}</td>
      <td class="tl">
        <span style="display:inline-flex;align-items:center;gap:4px;background:${o.c}22;color:${o.c};padding:2px 8px;border-radius:100px;font-size:10px;font-weight:600">${o.ic} ${o.nm}</span>
      </td>
      <td class="tl">
        ${e.glosa||''}${badgeDescuadre}
        <span style="font-size:10px;color:var(--mt);margin-left:6px">▸ ${e.movs.length} línea${e.movs.length===1?'':'s'}</span>
      </td>
      <td style="text-align:right;${estiloTotal}">${fmtC(totED)}</td>
      <td style="text-align:right;${estiloTotal}">${fmtC(totEH)}</td>
      <td style="text-align:right;white-space:nowrap" onclick="event.stopPropagation()">${btnEditar}</td>
    </tr>`;
  });

  h+=`<tfoot><tr>
    <td colspan="4" class="tl" style="font-weight:700">TOTALES</td>
    <td style="text-align:right;font-family:var(--mono);font-weight:700">${fmtC(totD)}</td>
    <td style="text-align:right;font-family:var(--mono);font-weight:700">${fmtC(totH)}</td>
    <td style="text-align:right;font-size:10px;color:${Math.abs(totD-totH)<0.000001?'var(--ach)':'var(--err)'}">
      ${Math.abs(totD-totH)<0.000001?'✓ cuadra':'⚠️ diff '+fmtC(Math.abs(totD-totH))}
    </td>
  </tr></tfoot>`;
  h+='</table></div></div>';

  cont.innerHTML=h;
  CMP_ENTRIES=entries;
}

// La alerta de descuadres es derivada en tiempo real desde genDiario(): no se
// guarda como estado. Por eso, al corregir el origen y volver a Comprobantes,
// el aviso desaparece automáticamente si Debe = Haber. El número es un acceso
// directo al editor correcto, no una etiqueta pasiva.
function corregirDescuadreCmp(indice){
  const ref=CMP_ALERT_ENTRIES[+indice];
  const e=entradaActualCmp(ref);
  const numero=ref?.n??'';
  if(!e){toast('⚠️ El comprobante fue modificado o ya no existe.','e');renderComprobantes();return;}
  const debe=(e.movs||[]).reduce((s,m)=>s+(+m.debe||0),0);
  const haber=(e.movs||[]).reduce((s,m)=>s+(+m.haber||0),0);
  if(Math.abs(debe-haber)<0.000001){toast(`✅ El comprobante N°${numero} ya está cuadrado`);renderComprobantes();return;}
  if(e.referenciaDoc?.fuente&&e.referenciaDoc?.docId){
    corregirDesdeDiario(e.referenciaDoc.fuente,e.referenciaDoc.docId);return;
  }
  if((e.fuente==='compras'||e.fuente==='ventas')&&e.docId){
    corregirDesdeDiario(e.fuente,e.docId);return;
  }
  if(e.origen==='manual'){
    editarAsientoRef(e.asientoId||e.numeroContable||e.ref||e.n);return;
  }
  if(e.origen==='apertura'){nav('apertura');return;}
  if(e.fuente==='honorarios'&&e.docId&&window.abrirHonComprobante){
    window.abrirHonComprobante(e.docId);return;
  }
  // Orígenes sin editor específico: abrir el comprobante completo.
  abrirEntradaCmp(e);
}

let _cmpTextoTimer=0;
let _cmpTextoSel={ini:0,fin:0};

function _restaurarFocoCmpTexto(){
  const el=document.getElementById('cmp-texto-input');
  if(!el)return;
  // Volver a enfocar el input recién recreado evita que Android cierre el
  // teclado al filtrar. preventScroll mantiene estable la lista mientras se
  // escribe y el cursor vuelve a la misma posición.
  try{el.focus({preventScroll:true});}catch(_){el.focus();}
  try{
    const max=String(el.value||'').length;
    const ini=Math.min(_cmpTextoSel.ini??max,max);
    const fin=Math.min(_cmpTextoSel.fin??ini,max);
    el.setSelectionRange(ini,fin);
  }catch(_){/* algunos WebView no exponen selectionRange en search */}
}

function setCmpFiltro(campo,valor){
  CMP_FILTRO[campo]=valor;
  if(campo==='texto'){
    const activo=document.activeElement;
    if(activo&&activo.id==='cmp-texto-input'){
      _cmpTextoSel={
        ini:Number.isFinite(activo.selectionStart)?activo.selectionStart:String(valor||'').length,
        fin:Number.isFinite(activo.selectionEnd)?activo.selectionEnd:String(valor||'').length
      };
    }else{
      const n=String(valor||'').length;
      _cmpTextoSel={ini:n,fin:n};
    }
    clearTimeout(_cmpTextoTimer);
    // Esperar brevemente permite escribir palabras completas sin reconstruir
    // el DOM en cada pulsación. Al filtrar se restaura inmediatamente el foco.
    _cmpTextoTimer=setTimeout(()=>{
      renderComprobantes();
      requestAnimationFrame(()=>requestAnimationFrame(_restaurarFocoCmpTexto));
    },220);
    return;
  }
  clearTimeout(_cmpTextoTimer);
  renderComprobantes();
}

// Búsqueda dinámica por N° de comprobante: filtra los entries del año actual
// que empiecen con el número tipeado y muestra una lista dropdown.
function cmpNumeroBuscar(q){
  const box=document.getElementById('cmp-num-list');
  if(!box)return;
  const qs=String(q||'').trim();
  if(!qs){
    // sin query: limpiar filtro y ocultar lista
    if(CMP_FILTRO.numero){
      CMP_FILTRO.numero='';
      renderComprobantes();
    }else{
      renderCmpNumeroList([]);
    }
    return;
  }
  // Obtener el universo actual de comprobantes del año
  const todos=genDiario();
  const filtrados=todos.filter(e=>String(e.n||'').startsWith(qs)).slice(0,15);
  renderCmpNumeroList(filtrados);
}

function renderCmpNumeroList(items){
  const box=document.getElementById('cmp-num-list');
  if(!box)return;
  CMP_NUM_ENTRIES=[...(items||[])];
  if(!items.length){box.style.display='none';box.innerHTML='';return;}
  box.innerHTML=items.map((e,i)=>`
    <div class="ac-item" onmousedown="cmpNumeroElegirResultado(${i})">
      <span style="font-family:var(--mono);color:var(--info);font-weight:700">N°${e.n}</span>
      <span style="margin-left:8px;color:var(--mt);font-size:11px">${e.fecha}</span>
      <span style="margin-left:8px">${(e.glosa||'').slice(0,50)}</span>
    </div>`).join('');
  box.style.display='block';
}

function cmpNumeroElegirResultado(i){
  const e=CMP_NUM_ENTRIES[+i];if(e)abrirEntradaCmp(e);
}

function cmpNumeroElegir(n){
  const candidatos=genDiario().filter(e=>String(e.n)===String(n));
  // Compatibilidad para llamadas antiguas: si el número está duplicado,
  // priorizar el que realmente está descuadrado.
  const e=candidatos.find(x=>{const d=x.movs.reduce((s,m)=>s+(+m.debe||0),0),h=x.movs.reduce((s,m)=>s+(+m.haber||0),0);return Math.abs(d-h)>=0.000001;})||candidatos[0];
  if(e)abrirEntradaCmp(e);
}

// ── Abrir el comprobante de un registro cualquiera ──
// Lo usa el buscador global: da lo mismo si el resultado es una factura, un
// asiento manual o la apertura — lo que interesa es ver su comprobante.
//
// Se resuelve a través del N° y se reutiliza `cmpNumeroElegir`, porque sin
// filtro la lista sólo cachea los 5 comprobantes más recientes y el buscado
// podría no estar entre ellos.
function abrirComprobantePor(criterio){
  const entries=genDiario();
  const e=entries.find(x=>{
    if(criterio.docId)return x.docId===criterio.docId;
    if(criterio.asientoN!=null)return x.origen==='manual'&&+x.ref===+criterio.asientoN;
    if(criterio.apertura)return x.origen==='apertura';
    if(criterio.honorariosMes!=null)return x.fuente==='honorarios'&&+x.mes===+criterio.honorariosMes;
    return false;
  });
  if(!e)return false;
  nav('comprobantes');
  // Un respiro para que la sección esté visible antes de abrir el modal
  setTimeout(()=>abrirEntradaCmp(e),60);
  return true;
}

// ═══ BUSCADOR DEL ENCABEZADO ═══
// Busca entre todos los comprobantes del ejercicio por N°, glosa o monto.
// Al elegir un manual, se carga en el formulario de arriba para editarlo.
// Los automáticos, los vinculados a un documento y la apertura no se editan
// en ese formulario, así que se abren en su comprobante (desde ahí se puede
// ir al documento de origen).
let CMP_HDR={items:[],sel:-1,universo:null};
const soloDig=t=>String(t||'').replace(/[^0-9]/g,'');
function totalAsiento(e){return Math.round(e.movs.reduce((s,m)=>s+(+m.debe||0),0));}
function editableEnFormulario(e){
  if(e.origen!=='manual'||!e.asientoId)return false;
  const f=e.referenciaDoc?.fuente||'';
  return !(f==='ventas'||f==='compras');
}

function buscarComprobantesHdr(q,universo){
  const qs=String(q||'').trim();
  if(!qs)return[];
  const qt=qs.toLowerCase();
  // Es "numérico" si solo trae dígitos, puntos, comas, espacios o $
  const esNum=/^[\s$.,0-9]+$/.test(qs)&&soloDig(qs).length>0;
  const qd=esNum?soloDig(qs):'';
  const res=[];
  universo.forEach(e=>{
    let score=null;
    const nStr=String(e.n??'');
    const tot=totalAsiento(e);
    if(esNum){
      if(nStr===qd)score=0;
      else if(String(tot)===qd)score=1;
      else if(e.movs.some(m=>String(Math.round(+m.debe||+m.haber||0))===qd))score=2;
      else if(nStr.startsWith(qd))score=3;
      else if(qd.length>=3&&String(tot).includes(qd))score=4;
    }
    if(score==null){
      if((e.glosa||'').toLowerCase().includes(qt))score=5;
      else if(e.movs.some(m=>(m.desc||'').toLowerCase().includes(qt)||(m.razonSocial||'').toLowerCase().includes(qt)))score=6;
    }
    if(score!=null)res.push({e,score});
  });
  // Mejor coincidencia primero; a igual puntaje, el más reciente arriba
  res.sort((a,b)=>a.score-b.score||String(b.e.fecha||'').localeCompare(String(a.e.fecha||''))||(+b.e.n||0)-(+a.e.n||0));
  return res.slice(0,12).map(r=>r.e);
}

function cmpHdrBuscar(q){
  // El universo se calcula una vez por búsqueda y no en cada tecla
  if(!CMP_HDR.universo||!String(q||'').trim())CMP_HDR.universo=genDiario();
  CMP_HDR.items=buscarComprobantesHdr(q,CMP_HDR.universo);
  CMP_HDR.sel=CMP_HDR.items.length?0:-1;
  renderCmpHdrLista(String(q||'').trim());
}

function renderCmpHdrLista(q){
  const box=document.getElementById('cmp-hdr-list');if(!box)return;
  if(!q){box.style.display='none';box.innerHTML='';return;}
  if(!CMP_HDR.items.length){
    box.innerHTML=`<div class="ac-item" style="color:var(--mt);cursor:default">Sin comprobantes que coincidan</div>`;
    box.style.display='block';return;
  }
  box.innerHTML=CMP_HDR.items.map((e,i)=>{
    const o=origenLbl(e);
    return `<div class="ac-item${i===CMP_HDR.sel?' sel':''}" onmousedown="cmpHdrElegir(${i})" style="display:flex;align-items:center;gap:8px">
      <span style="font-family:var(--mono);color:var(--info);font-weight:700;min-width:48px">N°${attr(String(e.n??""))}</span>
      <span style="font-family:var(--mono);color:var(--mt);font-size:11px">${attr(e.fecha)}</span>
      <span style="background:${o.c}22;color:${o.c};padding:1px 6px;border-radius:100px;font-size:10px;white-space:nowrap">${o.ic} ${o.nm}</span>
      <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${attr(e.glosa)}">${attr(e.glosa)}</span>
      <span style="font-family:var(--mono);font-size:11px;white-space:nowrap">${fmtC(totalAsiento(e))}</span>
    </div>`;
  }).join('');
  box.style.display='block';
}

function cmpHdrTecla(ev){
  const n=CMP_HDR.items.length;
  if(ev.key==='ArrowDown'&&n){ev.preventDefault();CMP_HDR.sel=(CMP_HDR.sel+1)%n;renderCmpHdrLista('x');}
  else if(ev.key==='ArrowUp'&&n){ev.preventDefault();CMP_HDR.sel=(CMP_HDR.sel-1+n)%n;renderCmpHdrLista('x');}
  else if(ev.key==='Enter'&&CMP_HDR.sel>=0){ev.preventDefault();cmpHdrElegir(CMP_HDR.sel);}
  else if(ev.key==='Escape'){cmpHdrCerrar();ev.target.blur();}
}

function cmpHdrCerrar(){
  const box=document.getElementById('cmp-hdr-list');
  if(box){box.style.display='none';box.innerHTML='';}
  CMP_HDR.universo=null;
}

function cmpHdrElegir(i){
  const e=CMP_HDR.items[i];if(!e)return;
  const inp=document.getElementById('cmp-hdr-q');if(inp){inp.value='';inp.blur();}
  cmpHdrCerrar();
  if(editableEnFormulario(e)){
    editarAsiento(e.asientoId);
    toast(`✏️ Asiento N°${e.n} cargado para editar`);
    return;
  }
  abrirEntradaCmp(e);
}

function limpiarCmpFiltro(){
  clearTimeout(_cmpTextoTimer);
  CMP_FILTRO={mes:'',origen:'',texto:'',numero:''};
  renderCmpNumeroList([]);
  renderComprobantes();
}

function toggleCmpDet(id){
  const t=document.getElementById(id);
  if(!t)return;
  t.style.display=t.style.display==='none'?'':'none';
}

// Nota: la navegación a "editar" vive en reportes.js (editarAsientoRef y
// corregirDesdeDiario), a donde apunta destinoEdicion(). Antes había aquí una
// copia de ambas y las dos pantallas podían quedar haciendo cosas distintas.

// ═══ MODAL VER / EDITAR COMPROBANTE ═══
//
// Al clicar cualquier fila, se abre este modal en modo VER. Muestra el asiento
// completo (glosa, N°, fecha, movimientos con debe/haber).
//
// Botón "Editar" conmuta a modo EDITAR:
//   - Manuales: se editan directamente, guardando de vuelta en S.asientos.
//   - Automáticos (compras/ventas): se convierten a manual en el momento.
//     Esto crea un asiento manual con las líneas actuales que reemplaza al
//     resumen automático de ese documento (se marca el documento con
//     `excluidoAuto:true` para que genDiario ya no lo agregue automáticamente).
//   - Apertura: se edita directamente el S.apertura.
//
// El guardado exige cuadratura de partida doble (Debe = Haber, diferencia < 1).

function abrirCmpModal(idx){
  const e=CMP_ENTRIES[idx];
  if(!e)return;
  CMP_MODAL={mode:'view',idx,edit:null};
  document.getElementById('cmp-modal').classList.add('open');
  renderCmpModal();
}

function cerrarCmpModal(){
  document.getElementById('cmp-modal').classList.remove('open');
  CMP_MODAL={mode:'view',idx:-1,edit:null};
}

function renderCmpModal(){
  const box=document.getElementById('cmp-modal-body');
  if(!box)return;
  const e=CMP_ENTRIES[CMP_MODAL.idx];
  if(!e)return;
  const o=origenLbl(e);

  if(CMP_MODAL.mode==='view')renderCmpModalView(box,e,o);
  else renderCmpModalEdit(box,e,o);
}

function renderCmpModalView(box,e,o){
  const totD=e.movs.reduce((s,m)=>s+(m.debe||0),0);
  const totH=e.movs.reduce((s,m)=>s+(m.haber||0),0);
  const cuadra=Math.abs(totD-totH)<0.000001;
  const editable=e.origen==='manual'||e.origen==='apertura'||e.fuente==='compras'||e.fuente==='ventas'||e.tipo==='pago';

  box.innerHTML=`
    <div style="padding:16px 20px">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;flex-wrap:wrap">
        <span style="display:inline-flex;align-items:center;gap:6px;background:${o.c}22;color:${o.c};padding:4px 12px;border-radius:100px;font-size:11px;font-weight:700">${o.ic} ${o.nm}</span>
        <span style="font-family:var(--mono);font-size:12px;color:var(--mt)">N° ${e.n} · ${e.fecha}</span>
        ${!cuadra?`<span style="background:rgba(248,81,73,.15);color:var(--err);padding:2px 8px;border-radius:3px;font-size:10px;font-weight:700">⚠ DESCUADRE ${fmtC(Math.abs(totD-totH))}</span>`:''}
      </div>
      <div style="font-size:14px;font-weight:600;margin-bottom:14px">${e.glosa||'(sin glosa)'}</div>

      <div class="cmp-tbl-wrap">
      <table class="tbl-cmp">
        <thead><tr style="border-bottom:1px solid var(--bd);color:var(--mt);text-transform:uppercase;font-size:10px">
          <th class="tl">CÓDIGO</th>
          <th class="tl">CUENTA</th>
          <th class="tl">DESCRIPCIÓN</th>
          <th style="text-align:right">DEBE</th>
          <th style="text-align:right">HABER</th>
        </tr></thead>
        <tbody>${e.movs.map(m=>{
          const desc=m.desc||'';
          return `<tr style="border-bottom:1px solid rgba(48,54,61,.5)">
          <td class="tl c-cod">${m.cd}</td>
          <td class="tl c-cta">${m.nm||pdcNm(m.cd)}</td>
          <td class="tl c-desc" title="${attr(desc)}">${desc||'—'}</td>
          <td class="c-num">${m.debe?fmtC(m.debe):'—'}</td>
          <td class="c-num">${m.haber?fmtC(m.haber):'—'}</td>
        </tr>`;}).join('')}</tbody>
        <tfoot><tr style="background:var(--sf2);font-weight:700">
          <td colspan="3" class="tl">TOTALES</td>
          <td class="c-num" style="color:${cuadra?'var(--tx)':'var(--err)'}">${fmtC(totD)}</td>
          <td class="c-num" style="color:${cuadra?'var(--tx)':'var(--err)'}">${fmtC(totH)}</td>
        </tr></tfoot>
      </table>
      </div>

      <div style="display:flex;justify-content:space-between;gap:8px;margin-top:16px;flex-wrap:wrap">
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          ${borrable(e)?`<button class="btn btn-d" onclick="eliminarComprobante()">🗑 Eliminar</button>`:''}
          ${(e.origen==='manual'||e.tipo==='pago'||asientoAutoDe(e))?`<button class="btn btn-g" onclick="anularComprobante()" title="Mantiene el N° correlativo pero excluye sus efectos">🚫 Anular</button>`:''}
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-g" onclick="cerrarCmpModal()">Cerrar</button>
          ${editable?`<button class="btn btn-p" onclick="cmpModalEditar()">✏️ Editar</button>`:''}
        </div>
      </div>
    </div>`;
}

// ── Eliminar comprobante ──
// Un comprobante automático NO existe como registro propio: es el reflejo
// contable de un documento del libro. Por eso "eliminar" significa cosas
// distintas según el origen, y el diálogo lo dice con todas sus letras.
//
// Cada comprobante automático de honorarios queda vinculado a una boleta
// individual; anularlo deriva al flujo de anulación documental con trazabilidad.
function borrable(e){
  if(e.tipo==='pago')return true;   // pagos/cobros agrupados: eliminables (restauran saldos)
  if(e.origen==='manual'||e.origen==='apertura')return true;
  if(e.origen==='auto'&&['ventas','compras','honorarios'].includes(e.fuente)&&!!e.docId)return true;
  return !!asientoAutoDe(e);
}
// V2.21.42 — Asiento automático (F29, remuneraciones, depreciación, cierres
// de costos, capitalización, provisiones…) que se puede eliminar o anular a
// mano con su reversa.
function asientoAutoDe(e){
  if(!e||!e.asientoId||e.origen==='manual'||e.tipo==='pago')return null;
  const a=(S.asientos||[]).find(x=>x.id===e.asientoId);
  return a&&infoReversa(a)?a:null;
}
async function eliminarOAnularAuto(e,modo){
  const a=asientoAutoDe(e);if(!a)return false;
  const r=await eliminarAsientoAuto(a,{modo});
  if(!r.ok){
    if(r.motivo==='cancelado')return true;
    if(r.motivo==='bloqueado'){toast('🔒 '+r.detalle,'e');return true;}
    toast(`❌ No se pudo ${modo==='anular'?'anular':'eliminar'} el asiento (${r.motivo}). No se realizaron cambios.`,'e');return true;
  }
  cerrarCmpModal();rerender();
  toast(`${modo==='anular'?'🚫 Asiento N°'+r.info.num+' anulado':'🗑 Asiento N°'+r.info.num+' eliminado'}${r.info.reversa?' · registros vinculados revertidos':''}`);
  if(r.avisos&&r.avisos.length)setTimeout(()=>toast('⚠️ '+r.avisos.join(' '),'e'),1200);
  return true;
}

async function eliminarComprobante(){
  const e=CMP_ENTRIES[CMP_MODAL.idx];
  if(!e)return;

  // ── Pago / Cobro agrupado ──
  // El asiento de pago es el registro maestro: los saldos de cada documento se
  // DERIVAN de él. Al eliminarlo, esos documentos vuelven a quedar pendientes
  // solos, sin tocar nada más. Es la forma de deshacer un pago mal registrado.
  if(e.tipo==='pago'){
    const a=S.asientos.find(x=>x.id===e.asientoId)||S.asientos.find(x=>x.n===e.ref);
    if(!a){toast('⚠️ No se encontró el asiento de pago','e');return;}
    if(ejercicioCerrado()){toast('🔒 No se puede eliminar el pago con el ejercicio cerrado.','e');return;}
    const nDocs=(a.documentos||[]).length;
    const nComp=a.numeroContable||a.n||'?';
    if(!confirm(
      `¿Eliminar "${a.glosa||'pago/cobro'}"?\n\n`+
      `Se borra por completo y ${nDocs} documento${nDocs===1?'':'s'} vuelve${nDocs===1?'':'n'} a quedar pendiente${nDocs===1?'':'s'}.\n`+
      `El N° ${nComp} queda libre y el correlativo pierde continuidad.\n`+
      `Si prefieres conservar el N°, usa "Anular" en vez de eliminar.\n\n`+
      `Esta acción no se puede deshacer.`))return;
    const r=await persistirAsientosCritico(()=>{S.asientos=S.asientos.filter(x=>x!==a);});
    if(!r.ok){toast('❌ No se pudo eliminar el pago. No se realizaron cambios.','e');return;}
    logAccion('Eliminó pago/cobro',`${a.glosa||''} — ${nDocs} doc · N°${nComp}`);
    cerrarCmpModal();rerender();toast('🗑 Pago eliminado — los documentos vuelven a quedar pendientes');
    return;
  }

  // ── Manual ──
  if(e.origen==='manual'){
    const a=S.asientos.find(x=>x.n===e.ref)||S.asientos.find(x=>x.folioComp===e.n);
    if(!a){toast('⚠️ No se encontró el asiento de origen','e');return;}
    if(!confirm(
      `¿Eliminar el asiento manual N°${a.n}?\n\n`+
      `"${a.glosa||'(sin glosa)'}"\n\n`+
      `El N° ${a.n} queda libre y el correlativo pierde continuidad.\n`+
      `Si lo que quieres es dejar constancia, usa "Anular" en vez de eliminar.\n\n`+
      `Esta acción no se puede deshacer.`))return;
    const r=await persistirAsientosCritico(()=>{S.asientos=S.asientos.filter(x=>x!==a);});
    if(!r.ok){toast('❌ No se pudo eliminar el asiento. No se realizaron cambios.','e');return;}
    logAccion('Eliminó asiento',`N°${a.n} — ${a.glosa}`);
    cerrarCmpModal();rerender();toast('🗑 Asiento eliminado');
    return;
  }

  // ── Apertura ──
  if(e.origen==='apertura'){
    if(!confirm(
      `¿Eliminar el Balance de Apertura ${S.empresa.anio}?\n\n`+
      `Es el asiento N°0 del ejercicio: se van sus ${e.movs.length} líneas y con ellas\n`+
      `los saldos iniciales del Mayor, el Balance y los auxiliares.\n\n`+
      `Esta acción no se puede deshacer.`))return;
    if(ejercicioCerrado()){toast('🔒 No se puede eliminar la apertura con el ejercicio cerrado.','e');return;}
    const snap=JSON.stringify(S.apertura);
    S.apertura=null;
    try{const r=await window.storage.delete('apertura-'+S.empresa.anio);if(r&&r.ok===false)throw new Error(r.motivo||'fallo-persistencia');}
    catch(err){S.apertura=JSON.parse(snap);toast('❌ No se pudo eliminar la apertura. No se realizaron cambios.','e');return;}
    logAccion('Eliminó apertura',`Ejercicio ${S.empresa.anio}`);
    cerrarCmpModal();rerender();toast('🗑 Balance de apertura eliminado');
    return;
  }

  // ── Automático de ventas o compras: se borra el DOCUMENTO ──
  if(e.origen==='auto'&&(e.fuente==='ventas'||e.fuente==='compras')&&e.docId){
    const esVenta=e.fuente==='ventas';
    const lista=esVenta?S.ventas:S.compras;
    const d=lista.find(x=>x.id===e.docId);
    if(!d){toast('⚠️ No se encontró el documento de origen','e');return;}
    const libro=esVenta?'Libro de Ventas':'Libro de Compras';
    if(!confirm(
      `Este comprobante es automático: lo genera un documento del ${libro}.\n\n`+
      `Para que desaparezca hay que eliminar el documento que lo origina:\n\n`+
      `   ${esVenta?dteV(d.tipoDTE)?.nm||'DTE '+d.tipoDTE:dteC(d.tipoDTE)?.nm||'DTE '+d.tipoDTE} N°${d.numero}\n`+
      `   ${d.razonSocial||''}\n`+
      `   ${fmtC(d.total||0)}\n\n`+
      `Se borra del ${libro} y de todos los reportes.\n`+
      `Esta acción no se puede deshacer.`))return;
    const rr=await anularDocumentoContabilizado(e.fuente,d,lista);
    if(!rr.ok){toast('❌ No se pudo anular el documento. No se realizaron cambios.','e');return;}
    logAccion('Eliminó documento',`${libro} — N°${d.numero} ${d.razonSocial||''}`);
    cerrarCmpModal();rerender();toast('🚫 Documento anulado — se conserva la trazabilidad y el comprobante deja de afectar la contabilidad');
    return;
  }

  // ── Honorarios: cada boleta y su pago tienen comprobantes vinculados ──
  if(e.fuente==='honorarios'){
    cerrarCmpModal();
    if(e.docId)window.anularHonDesdeComprobante?.(e.docId);
    else nav('honorarios');
    return;
  }

  // ── Automáticos con reversa (F29, remuneraciones, depreciación, cierres…) ──
  if(await eliminarOAnularAuto(e,'eliminar'))return;

  toast('⚠️ Este comprobante no se puede eliminar desde aquí','e');
}

// Anular deja el N° en su sitio y excluye los efectos: es lo correcto en
// contabilidad, donde el correlativo no debería tener huecos.
async function anularComprobante(){
  const e=CMP_ENTRIES[CMP_MODAL.idx];
  if(!e)return;
  if(e.origen!=='manual'&&e.tipo!=='pago'){await eliminarOAnularAuto(e,'anular');return;}
  const a=S.asientos.find(x=>x.id===e.asientoId)||S.asientos.find(x=>x.n===e.ref)||S.asientos.find(x=>x.folioComp===e.n);
  if(!a){toast('⚠️ No se encontró el asiento de origen','e');return;}
  const nComp=a.numeroContable||a.n||'';
  const esPago=a.tipo==='pago';
  const nDocs=(a.documentos||[]).length;
  const msg=esPago
    ? `¿Anular "${a.glosa||'pago/cobro'}"?\n\n`+
      `NO borra el N° ${nComp} — el correlativo queda intacto y sin huecos —\n`+
      `pero deja de afectar la contabilidad y ${nDocs} documento${nDocs===1?'':'s'} vuelve${nDocs===1?'':'n'} a\n`+
      `quedar pendiente${nDocs===1?'':'s'} de pago/cobro.\n\n`+
      `Si en cambio quieres borrarlo por completo, usa "Eliminar".`
    : `¿Anular el asiento N°${a.n}?\n\n`+
      `"${a.glosa||'(sin glosa)'}"\n\n`+
      `NO borra el N° ${a.n} — el correlativo queda intacto — pero sus montos\n`+
      `dejan de sumar en el Mayor, el Balance y los auxiliares.\n\n`+
      `Como el libro diario excluye los anulados, el comprobante deja de\n`+
      `aparecer en esta lista. Queda visible y se puede reactivar desde\n`+
      `"Asientos Manuales".`;
  if(!confirm(msg))return;
  const r=await persistirAsientosCritico(()=>{a.anulado=true;a.anuladoEn=new Date().toISOString();});
  if(!r.ok){toast('❌ No se pudo anular el asiento. No se realizaron cambios.','e');return;}
  logAccion(esPago?'Anuló pago/cobro':'Anuló asiento',`N°${nComp||a.n} — ${a.glosa}`);
  cerrarCmpModal();rerender();
  toast(esPago
    ?'🚫 Pago anulado — los documentos vuelven a quedar pendientes'
    :'🚫 Asiento N°'+a.n+' anulado — reactivable desde Asientos Manuales');
}

function renderCmpModalEdit(box,e,o){
  const ed=CMP_MODAL.edit;
  const totD=ed.movs.reduce((s,m)=>s+(+m.debe||0),0);
  const totH=ed.movs.reduce((s,m)=>s+(+m.haber||0),0);
  const dif=totD-totH;
  const cuadra=Math.abs(dif)<0.000001;

  const filas=ed.movs.map((m,i)=>{
    const busc=inputCuenta({
      id:`cmp-ed-cd-${i}`,
      value:m.cd||'',
      onPick:`setCmpEdCuenta(${i},'%CD%')`,
      placeholder:'Buscar cuenta…',
      clase:'linea-inp',
    });
    // Si la cuenta maneja auxiliar (proveedor / cliente / honorario),
    // mostramos un resumen de los datos DTE ya asociados y un botón para
    // editarlos en un modal aparte.
    const aux=m.cd?CUENTAS_AUX[m.cd]:'';
    let dteBloque='';
    if(aux){
      const d=m.dte||{};
      const dteInfo=aux==='cliente'?dteV(d.tipoDTE):dteC(d.tipoDTE);
      const dteNm=dteInfo?.nm||(d.tipoDTE?`DTE ${d.tipoDTE}`:'sin definir');
      const tieneDatos=d.rutCodigo&&d.numero;
      dteBloque=`<div style="margin-top:4px;padding:6px 8px;background:${tieneDatos?'rgba(88,166,255,.06)':'rgba(255,193,7,.08)'};border:1px solid ${tieneDatos?'rgba(88,166,255,.3)':'rgba(255,193,7,.35)'};border-radius:4px;font-size:10px">
        ${tieneDatos
          ? `<span style="color:var(--info);font-weight:600">📄 ${dteNm} N°${d.numero||'?'}</span> · ${d.fecha||''} · ${d.rutCodigo?rutFmt(d.rutCodigo,d.rutDV):''} · ${d.razonSocial||''}${d.total?` · <b>${fmtC(d.total)}</b>`:''}`
          : `<span style="color:var(--warn)">⚠️ Falta ${aux==='cliente'?'datos del cliente':aux==='proveedor'?'datos del proveedor':'datos del honorario'}</span>`}
        <button class="btn btn-i" style="padding:2px 8px;font-size:10px;margin-left:8px" onclick="abrirCmpEdDte(${i})">${tieneDatos?'✏️ Editar':'+ Agregar'} datos</button>
      </div>`;
    }
    return `<tr>
      <td style="padding:4px 6px">${busc}${dteBloque}</td>
      <td style="padding:4px 6px"><input type="text" class="linea-inp" placeholder="Descripción"
        value="${(m.desc||'').replace(/"/g,'&quot;')}" oninput="setCmpEdCampo(${i},'desc',this.value)"></td>
      <td style="padding:4px 6px"><input type="text" class="linea-num-inp" inputmode="numeric" placeholder="0"
        value="${m.debe?new Intl.NumberFormat('es-CL').format(Math.round(m.debe)):''}"
        oninput="setCmpEdMonto(${i},'debe',this)" onblur="setCmpEdMontoBlur(${i},'debe',this)" onfocus="this.select()"></td>
      <td style="padding:4px 6px"><input type="text" class="linea-num-inp" inputmode="numeric" placeholder="0"
        value="${m.haber?new Intl.NumberFormat('es-CL').format(Math.round(m.haber)):''}"
        oninput="setCmpEdMonto(${i},'haber',this)" onblur="setCmpEdMontoBlur(${i},'haber',this)" onfocus="this.select()"></td>
      <td style="padding:4px 6px;text-align:center">
        <button class="btn btn-d" style="padding:3px 8px;font-size:10px" onclick="delCmpEdLinea(${i})" ${ed.movs.length<=2?'disabled':''}>✕</button>
      </td>
    </tr>`;
  }).join('');

  const infoOrigen=(e.origen==='auto')
    ? `<div style="background:rgba(255,193,7,.08);border:1px solid rgba(255,193,7,.35);border-radius:6px;padding:10px 14px;margin-bottom:12px;font-size:11px;color:var(--tx)">
        ⚠️ Este comprobante es <strong>automático</strong> (generado desde ${e.fuente==='ventas'?'Libro de Ventas':e.fuente==='compras'?'Libro de Compras':'un libro'}).
        Si guardas los cambios se creará un asiento manual que <strong>reemplazará</strong> al automático de ese documento — el documento origen queda excluido de la generación automática.
      </div>`
    : '';

  box.innerHTML=`
    <div style="padding:16px 20px">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;flex-wrap:wrap">
        <span style="display:inline-flex;align-items:center;gap:6px;background:${o.c}22;color:${o.c};padding:4px 12px;border-radius:100px;font-size:11px;font-weight:700">${o.ic} ${o.nm}</span>
        <span style="font-family:var(--mono);font-size:12px;color:var(--mt)">N° ${e.n} · ${e.fecha}</span>
        <span style="background:rgba(88,166,255,.15);color:var(--info);padding:2px 8px;border-radius:3px;font-size:10px;font-weight:600">MODO EDICIÓN</span>
      </div>

      ${infoOrigen}

      <div style="margin-bottom:14px;display:grid;grid-template-columns:1fr 140px;gap:10px">
        <div>
          <label style="font-size:10px;color:var(--mt);text-transform:uppercase;letter-spacing:.06em;font-weight:700">Glosa</label>
          <input type="text" id="cmp-ed-glosa" style="width:100%;padding:6px 10px;margin-top:4px" value="${(ed.glosa||'').replace(/"/g,'&quot;')}" oninput="setCmpEdGlosa(this.value)">
        </div>
        <div>
          <label style="font-size:10px;color:var(--mt);text-transform:uppercase;letter-spacing:.06em;font-weight:700">Fecha</label>
          <input type="date" id="cmp-ed-fecha" style="width:100%;padding:6px 10px;margin-top:4px" value="${ed.fecha||''}" oninput="setCmpEdFecha(this.value)">
        </div>
      </div>

      <table style="width:100%;font-size:12px;table-layout:fixed">
        <colgroup><col style="width:30%"><col><col style="width:84px"><col style="width:84px"><col style="width:30px"></colgroup>
        <thead><tr style="border-bottom:1px solid var(--bd);color:var(--mt);text-transform:uppercase;font-size:10px">
          <th class="tl" style="padding:6px">CUENTA</th>
          <th class="tl" style="padding:6px">DESCRIPCIÓN</th>
          <th class="tl" style="padding:6px">DEBE</th>
          <th class="tl" style="padding:6px">HABER</th>
          <th></th>
        </tr></thead>
        <tbody>${filas}</tbody>
      </table>

      <div style="display:flex;gap:8px;margin-top:8px;align-items:center;flex-wrap:wrap">
        <button class="btn btn-i" onclick="addCmpEdLinea()">+ Agregar línea</button>
        <div data-cuadre-bar style="flex:1;padding:6px 12px;border-radius:6px;background:${cuadra?'rgba(46,160,67,.08)':'rgba(248,81,73,.08)'};border:1px solid ${cuadra?'var(--ach)':'var(--err)'};display:flex;gap:16px;font-size:12px;font-weight:600">
          <span>DEBE <span style="font-family:var(--mono)">${fmtC(totD)}</span></span>
          <span>HABER <span style="font-family:var(--mono)">${fmtC(totH)}</span></span>
          <span style="color:${cuadra?'var(--ach)':'var(--err)'};margin-left:auto">${cuadra?'✅ Cuadrado':'⚠️ Diferencia '+fmtC(Math.abs(dif))}</span>
        </div>
      </div>

      <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:16px">
        <button class="btn btn-g" onclick="cmpModalCancelar()">Cancelar</button>
        <button data-btn-guardar class="btn ${cuadra?'btn-p':'btn-g'}" onclick="cmpModalGuardar()" ${cuadra?'':'disabled'} title="${cuadra?'Guardar cambios':'Cuadra el Debe y Haber antes de guardar'}">
          💾 ${cuadra?'Guardar cambios':'Cuadrar para guardar'}
        </button>
      </div>
    </div>`;
}

function cmpModalEditar(){
  const e=CMP_ENTRIES[CMP_MODAL.idx];
  if(!e)return;
  // Los comprobantes de pago/cobro tienen su propio editor dedicado, que
  // mantiene la referencia documento↔pago y recalcula el banco.
  if(e.tipo==='pago'){cerrarCmpModal();abrirEditorPago(e.asientoId||e.ref);return;}
  // Los documentos se corrigen en su origen y regeneran EL MISMO asiento.
  // Nunca convertir la edición en un alta manual con otro número.
  const rd=e.referenciaDoc;
  const fuente=rd?.fuente||e.fuente,docId=rd?.docId||e.docId;
  if(['compras','ventas'].includes(fuente)&&docId){
    cerrarCmpModal();
    corregirDesdeDiario(fuente,docId);
    return;
  }
  CMP_MODAL.mode='edit';

  // Si el comprobante viene de un doc de compras/ventas, buscamos ese doc
  // para pre-poblar los datos DTE en la línea del auxiliar (proveedor/cliente).
  let docOrigen=null;
  if(e.docId&&(e.fuente==='compras'||e.fuente==='ventas')){
    const arr=e.fuente==='compras'?S.compras:S.ventas;
    docOrigen=arr.find(x=>x.id===e.docId);
  }

  CMP_MODAL.edit={
    glosa:e.glosa||'',
    fecha:e.fecha||today(),
    movs:e.movs.map(m=>{
      // Conservar centro de costo, docId, tributo, auxiliar y cualquier otro
      // metadato de la línea. Perderlos hacía que un asiento visualmente
      // cuadrado fuera rechazado por la validación central al guardar.
      const linea={...m,
        cd:m.cd||'',
        nm:m.nm||pdcNm(m.cd)||'',
        desc:m.desc||'',
        debe:+m.debe||0,
        haber:+m.haber||0,
      };
      // Si la cuenta es auxiliar y hay un doc origen, poblar los datos DTE
      const aux=m.cd?CUENTAS_AUX[m.cd]:'';
      if(aux&&docOrigen&&(aux==='proveedor'||aux==='cliente')){
        linea.dte={
          fecha:docOrigen.fecha||e.fecha,
          fechaVencimiento:docOrigen.fechaVencimiento||'',
          tipoDTE:docOrigen.tipoDTE,
          numero:docOrigen.numero,
          rutCodigo:docOrigen.rutCodigo,
          rutDV:docOrigen.rutDV,
          razonSocial:docOrigen.razonSocial,
          neto:docOrigen.neto||0,
          exento:docOrigen.exento||0,
          iva:docOrigen.iva||0,
          otrosImpuestos:docOrigen.otrosImpuestos||0,
          retencion:docOrigen.retencion||0,
          total:docOrigen.total||0,
        };
      }
      // Preservar los datos DTE si ya venían en el mov (asientos manuales)
      if(m.dte)linea.dte={...linea.dte,...m.dte};
      // Preservar campos que traía el mov original
      if(m.rutCodigo&&!linea.dte){
        linea.dte={
          fecha:e.fecha,tipoDTE:m.tipoDTE,numero:m.folio,
          rutCodigo:m.rutCodigo,rutDV:m.rutDV,
        };
      }
      return linea;
    }),
  };
  // Asegurar al menos 2 líneas
  while(CMP_MODAL.edit.movs.length<2)CMP_MODAL.edit.movs.push({cd:'',nm:'',desc:'',debe:0,haber:0});
  renderCmpModal();
}

function cmpModalCancelar(){
  if(confirm('¿Descartar los cambios sin guardar?')){
    CMP_MODAL.mode='view';
    CMP_MODAL.edit=null;
    renderCmpModal();
  }
}

function setCmpEdGlosa(v){CMP_MODAL.edit.glosa=v;}
function setCmpEdFecha(v){CMP_MODAL.edit.fecha=v;}
function setCmpEdCuenta(i,cd){
  if(!CMP_MODAL.edit.movs[i])return;
  CMP_MODAL.edit.movs[i].cd=cd;
  CMP_MODAL.edit.movs[i].nm=pdcNm(cd);
  renderCmpModal();
}
function setCmpEdCampo(i,campo,v){
  if(!CMP_MODAL.edit.movs[i])return;
  const m=CMP_MODAL.edit.movs[i];
  if(campo==='debe'||campo==='haber'){
    m[campo]=+v||0;
    // Débito y crédito son excluyentes por línea
    if(campo==='debe'&&+v)m.haber=0;
    if(campo==='haber'&&+v)m.debe=0;
    renderCmpModal();   // re-render para actualizar cuadratura
  }else{
    m[campo]=v;
  }
}

// Setter para inputs con formato de miles: reformatea al vuelo sin perder foco.
// No re-renderiza el modal completo (para no perder el foco del input); solo
// actualiza los totales de cuadratura en la barra inferior.
function setCmpEdMonto(i,campo,inp){
  if(!CMP_MODAL.edit.movs[i])return;
  const raw=String(inp.value||'').replace(/[^\d]/g,'');
  const num=+raw||0;
  const m=CMP_MODAL.edit.movs[i];
  m[campo]=num;
  // Excluyente: si escribe debe, limpia haber (y viceversa)
  if(campo==='debe'&&num>0)m.haber=0;
  if(campo==='haber'&&num>0)m.debe=0;
  // Reformatear con miles conservando el cursor al final si allí está.
  const formatted=num?new Intl.NumberFormat('es-CL').format(num):'';
  const posEnd=inp.selectionStart===inp.value.length;
  if(inp.value!==formatted){
    inp.value=formatted;
    if(posEnd)try{inp.setSelectionRange(formatted.length,formatted.length);}catch(e){}
  }
  // Actualizar la barra de cuadratura sin re-renderizar todo el modal
  actualizarBarraCuadre();
}

function setCmpEdMontoBlur(i,campo,inp){
  if(!CMP_MODAL.edit.movs[i])return;
  const num=+CMP_MODAL.edit.movs[i][campo]||0;
  inp.value=num?new Intl.NumberFormat('es-CL').format(num):'';
  // Al perder foco es buen momento de re-renderizar para reflejar cualquier
  // limpieza de la pareja debe/haber en el otro input.
  renderCmpModal();
}

// Actualiza solo la barra de cuadratura (Debe / Haber / Diferencia) del modal
// de edición, sin volver a renderizar toda la vista. Se usa mientras el usuario
// escribe montos, para no perder el foco del input.
function actualizarBarraCuadre(){
  const ed=CMP_MODAL.edit;
  if(!ed)return;
  const box=document.getElementById('cmp-modal-body');
  if(!box)return;
  const totD=ed.movs.reduce((s,m)=>s+(+m.debe||0),0);
  const totH=ed.movs.reduce((s,m)=>s+(+m.haber||0),0);
  const dif=totD-totH;
  const cuadra=Math.abs(dif)<0.000001;
  const barra=box.querySelector('[data-cuadre-bar]');
  if(barra){
    barra.style.background=cuadra?'rgba(46,160,67,.08)':'rgba(248,81,73,.08)';
    barra.style.borderColor=cuadra?'var(--ach)':'var(--err)';
    barra.innerHTML=`
      <span>DEBE <span style="font-family:var(--mono)">${fmtC(totD)}</span></span>
      <span>HABER <span style="font-family:var(--mono)">${fmtC(totH)}</span></span>
      <span style="color:${cuadra?'var(--ach)':'var(--err)'};margin-left:auto">${cuadra?'✅ Cuadrado':'⚠️ Diferencia '+fmtC(Math.abs(dif))}</span>`;
  }
  // Actualizar botón guardar
  const btnG=box.querySelector('[data-btn-guardar]');
  if(btnG){
    btnG.className='btn '+(cuadra?'btn-p':'btn-g');
    btnG.textContent=cuadra?'💾 Guardar cambios':'💾 Cuadrar para guardar';
    btnG.title=cuadra?'Guardar cambios':'Cuadra el Debe y Haber antes de guardar';
    btnG.disabled=!cuadra;
  }
}
function addCmpEdLinea(){
  CMP_MODAL.edit.movs.push({cd:'',nm:'',desc:'',debe:0,haber:0});
  renderCmpModal();
}
function delCmpEdLinea(i){
  if(CMP_MODAL.edit.movs.length<=2)return;   // mínimo 2 líneas (partida doble)
  CMP_MODAL.edit.movs.splice(i,1);
  renderCmpModal();
}

async function cmpModalGuardar(){
  const ed=CMP_MODAL.edit;
  if(!ed)return;
  const e=CMP_ENTRIES[CMP_MODAL.idx];
  if(!e)return;
  if((['compras','ventas'].includes(e.fuente)&&e.docId)||e.referenciaDoc?.docId){
    toast('Los comprobantes vinculados se guardan desde su documento de origen.','e');
    return;
  }
  if(ejercicioCerrado()){
    toast('🔒 El ejercicio está cerrado. Reabre antes de modificar comprobantes.','e');
    return;
  }

  // La puerta contable central no admite persistir asientos descuadrados. El
  // editor debe comunicar la misma regla y conservar el formulario abierto.
  const totD=ed.movs.reduce((s,m)=>s+(+m.debe||0),0);
  const totH=ed.movs.reduce((s,m)=>s+(+m.haber||0),0);
  const dif=totD-totH;
  if(Math.abs(dif)>=0.000001){
    toast(`⚠️ No se puede guardar: falta cuadrar ${fmtC(Math.abs(dif))}. Los cambios permanecen abiertos para corregirlos.`,'e');return;
  }
  // Requerir cuenta en todas las líneas con monto
  const sinCuenta=ed.movs.filter(m=>(m.debe||m.haber)&&!m.cd);
  if(sinCuenta.length){
    toast(`⚠️ ${sinCuenta.length} línea${sinCuenta.length===1?'':'s'} sin cuenta asignada`,'e');
    return;
  }
  // Filtrar líneas vacías (preservando los datos DTE en cuentas auxiliares)
  const movsClean=ed.movs.filter(m=>m.cd&&(m.debe||m.haber)).map(m=>{
    const mv={...m,
      cd:m.cd, nm:pdcNm(m.cd), desc:m.desc||'',
      debe:+m.debe||0, haber:+m.haber||0,
    };
    return mv;
  });
  if(movsClean.length<2){
    toast('⚠️ El asiento debe tener al menos 2 líneas con monto','e');
    return;
  }

  if(e.origen==='manual'){
    const a=S.asientos.find(x=>x.id===e.asientoId)||S.asientos.find(x=>+x.numeroContable===+e.n)||S.asientos.find(x=>x.n===e.ref);
    if(!a){toast('❌ No se encontró el asiento manual','e');return;}
    try{
      const r=await persistirAsientosCritico(async()=>{
        const actual=S.asientos.find(x=>x.id===a.id);
        if(!actual)throw new Error('asiento no encontrado');
        actual.glosa=ed.glosa;actual.fecha=ed.fecha;actual.movs=movsClean;
        return actual;
      });
      if(!r?.ok)throw new Error(r?.motivo||'fallo-persistencia');
    }catch(err){toast(`❌ No se pudo guardar el asiento: ${err.message||'validación contable'}`,'e');return;}
    logAccion('Editó asiento manual desde Comprobantes',`N°${e.n} · ${ed.glosa}`);
    toast(`✅ Asiento N°${e.n} actualizado`);
  }else if(e.origen==='apertura'){
    const snap=JSON.stringify(S.apertura||null);
    if(!S.apertura)S.apertura={};
    S.apertura.glosa=ed.glosa;S.apertura.fecha=ed.fecha;S.apertura.movs=movsClean;
    try{
      const r=await window.storage.set('apertura-'+S.empresa.anio,JSON.stringify(S.apertura));
      if(!r||r.ok===false)throw new Error(r?.motivo||'fallo-persistencia');
    }catch(err){S.apertura=JSON.parse(snap);toast('❌ No se pudo guardar la apertura. No se aplicaron cambios.','e');return;}
    logAccion('Editó balance de apertura desde Comprobantes',ed.glosa);
    toast('✅ Balance de apertura actualizado');
  }
  cerrarCmpModal();
  rerender();
}

// ═══ MODAL DE DATOS DTE PARA LÍNEA AUXILIAR ═══
//
// Cuando en el editor de comprobantes hay una línea con cuenta auxiliar
// (proveedor / cliente / honorario), este modal permite editar todos los
// campos del documento asociado: fecha, RUT, razón social, tipo DTE, folio,
// fecha vencimiento, neto, IVA, retención, total.
//
// Es un modal secundario que se abre sobre el editor principal.

let CMP_DTE={lineaIdx:-1,dte:null,tipoAux:'',autoBase:false};

function abrirCmpEdDte(lineaIdx){
  const l=CMP_MODAL.edit.movs[lineaIdx];
  if(!l||!l.cd)return;
  const tipoAux=CUENTAS_AUX[l.cd];
  if(!tipoAux)return;
  const base=l.dte?{...l.dte}:{
    fecha:CMP_MODAL.edit.fecha||today(),
    fechaVencimiento:'',
    tipoDTE:'', numero:'',
    rutCodigo:'', rutDV:'', razonSocial:'',
    neto:0, exento:0, iva:0, otrosImpuestos:0, retencion:0, total:0,
  };
  const autoBase=!(Number(l.dte?.neto)||Number(l.dte?.exento));
  CMP_DTE={lineaIdx,tipoAux,autoBase,dte:inferirDteDesdeAsiento({
    movs:CMP_MODAL.edit.movs,lineaIdx,tipoAux,tipoDTE:base.tipoDTE,
    actual:base,fecha:CMP_MODAL.edit.fecha||today(),glosa:CMP_MODAL.edit.glosa||''
  })};
  document.getElementById('cmp-dte-modal').classList.add('open');
  renderCmpDteModal();
}

function cerrarCmpEdDte(){
  document.getElementById('cmp-dte-modal').classList.remove('open');
  CMP_DTE={lineaIdx:-1,dte:null,tipoAux:'',autoBase:false};
}

function renderCmpDteModal(){
  const box=document.getElementById('cmp-dte-modal-body');
  if(!box)return;
  const d=CMP_DTE.dte;
  const tipoAux=CMP_DTE.tipoAux;
  const tipoLbl=tipoAux==='cliente'?'Cliente':tipoAux==='proveedor'?'Proveedor':'Honorario';
  const rutLbl=tipoAux==='cliente'?'RUT Cliente':tipoAux==='proveedor'?'RUT Proveedor':'RUT Prestador';

  // Opciones de DTE según tipo auxiliar
  let dteOpts='<option value="">— tipo documento —</option>';
  if(tipoAux==='cliente'){
    DTE_VENTAS.forEach(x=>{dteOpts+=`<option value="${x.cod}" ${+d.tipoDTE===x.cod?'selected':''}>${x.cod} — ${x.nm}</option>`;});
  }else if(tipoAux==='proveedor'){
    DTE_COMPRAS.forEach(x=>{dteOpts+=`<option value="${x.cod}" ${+d.tipoDTE===x.cod?'selected':''}>${x.cod} — ${x.nm}</option>`;});
  }else{
    dteOpts+=`<option value="70" ${+d.tipoDTE===70?'selected':''}>70 — Boleta de Honorarios</option>
              <option value="71" ${+d.tipoDTE===71?'selected':''}>71 — Boleta de Honorarios Electrónica</option>`;
  }

  const rutFmt2=d.rutCodigo?`${d.rutCodigo}-${d.rutDV||''}`:'';
  const esHono=tipoAux==='honorario';

  box.innerHTML=`
    <div style="padding:16px 20px">
      <div style="background:var(--sf2);border-radius:6px;padding:10px 14px;margin-bottom:14px;display:flex;align-items:center;gap:10px">
        <span style="font-size:11px;color:var(--mt);text-transform:uppercase;font-weight:700">${tipoLbl}</span>
        <span style="font-family:var(--mono);font-size:11px">${pdcNm(CMP_MODAL.edit.movs[CMP_DTE.lineaIdx]?.cd||'')}</span>
      </div>

      <div class="fg">
        <div class="grp"><label>Fecha emisión</label>
          <input type="date" id="cmpdte-fecha" value="${d.fecha||''}" oninput="setCmpDteCampo('fecha',this.value)"></div>
        <div class="grp"><label>Fecha vencimiento</label>
          <input type="date" id="cmpdte-fvenc" value="${d.fechaVencimiento||''}" oninput="setCmpDteCampo('fechaVencimiento',this.value)"></div>

        <div class="grp"><label>${rutLbl}</label>
          <input type="text" id="cmpdte-rut" value="${rutFmt2}" placeholder="12345678-9" oninput="setCmpDteRut(this.value)"></div>
        <div class="grp"><label>Razón social / Nombre</label>
          <input type="text" id="cmpdte-razon" value="${(d.razonSocial||'').replace(/"/g,'&quot;')}" oninput="setCmpDteCampo('razonSocial',this.value)"></div>

        <div class="grp"><label>Tipo de documento</label>
          <select id="cmpdte-tipo" onchange="setCmpDteTipo(+this.value)">${dteOpts}</select></div>
        <div class="grp"><label>Folio / N° documento</label>
          <input type="text" id="cmpdte-numero" value="${d.numero||''}" oninput="setCmpDteCampo('numero',this.value)"></div>
      </div>

      <div style="margin-top:10px;padding-top:10px;border-top:1px dashed var(--bd)">
        <div style="font-size:11px;font-weight:600;margin-bottom:8px;color:var(--mt);text-transform:uppercase;letter-spacing:.06em">Montos</div>
        <div class="fg">
          ${esHono?`
          <div class="grp"><label>Bruto (base honorarios)</label>
            <input type="number" class="money-input" id="cmpdte-neto" value="${d.neto||''}" oninput="setCmpDteCampo('neto',pn(this.value))"></div>
          <div class="grp"><label>Retención</label>
            <input type="number" class="money-input" id="cmpdte-ret" value="${d.retencion||''}" oninput="setCmpDteCampo('retencion',pn(this.value))"></div>
          `:`
          <div class="grp"><label>Neto</label>
            <input type="number" class="money-input" id="cmpdte-neto" value="${d.neto||''}" oninput="setCmpDteCampo('neto',pn(this.value));cmpDteAutoTotal()"></div>
          <div class="grp"><label>Exento</label>
            <input type="number" class="money-input" id="cmpdte-exento" value="${d.exento||''}" oninput="setCmpDteCampo('exento',pn(this.value));cmpDteAutoTotal()"></div>
          <div class="grp"><label>IVA</label>
            <input type="number" class="money-input" id="cmpdte-iva" value="${d.iva||''}" oninput="setCmpDteCampo('iva',pn(this.value));cmpDteAutoTotal()"></div>
          <div class="grp"><label>Otros impuestos / Retención</label>
            <input type="number" class="money-input" id="cmpdte-otros" value="${d.otrosImpuestos||d.retencion||''}" oninput="setCmpDteCampo('otrosImpuestos',pn(this.value));cmpDteAutoTotal()"></div>
          `}
          <div class="grp full"><label style="font-weight:700">Total documento</label>
            <input type="number" class="money-input" id="cmpdte-total" style="font-weight:700;font-size:14px" value="${d.total||''}" oninput="setCmpDteCampo('total',pn(this.value))"></div>
        </div>
        ${!esHono?`<div style="font-size:10px;color:var(--mt);margin-top:6px">💡 Neto, IVA, exento, otros impuestos y total se completan desde las líneas del asiento cuando es posible. Normalmente sólo debes elegir el tipo de DTE y la fecha de vencimiento; puedes ajustar un valor si el documento real tiene una situación especial.</div>`:''}
      </div>

      <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:16px">
        <button class="btn btn-g" onclick="cerrarCmpEdDte()">Cancelar</button>
        <button class="btn btn-p" onclick="guardarCmpEdDte()">💾 Guardar datos</button>
      </div>
    </div>`;
}

function setCmpDteCampo(campo,valor){
  if(!CMP_DTE.dte)return;
  if(campo==='neto'||campo==='exento')CMP_DTE.autoBase=false;
  CMP_DTE.dte[campo]=valor;
}
function setCmpDteTipo(valor){
  if(!CMP_DTE.dte)return;
  const tipoDTE=+valor||0;
  CMP_DTE.dte.tipoDTE=tipoDTE;
  // Si Neto/Exento fueron inferidos automáticamente al abrir el DTE, no los
  // tratamos como dato definitivo: al escoger el tipo SII los reconstruimos
  // para que una factura afecta vaya a Neto y una exenta a Exento. Si el
  // usuario ya editó manualmente alguno de ambos campos, se respeta su valor.
  const actual={...CMP_DTE.dte,tipoDTE};
  if(CMP_DTE.autoBase){actual.neto=0;actual.exento=0;}
  CMP_DTE.dte=inferirDteDesdeAsiento({
    movs:CMP_MODAL.edit?.movs||[],lineaIdx:CMP_DTE.lineaIdx,tipoAux:CMP_DTE.tipoAux,
    tipoDTE,actual,
    fecha:CMP_MODAL.edit?.fecha||today(),glosa:CMP_MODAL.edit?.glosa||''
  });
  renderCmpDteModal();
}
function setCmpDteRut(txt){
  if(!CMP_DTE.dte)return;
  const info=rutParse(txt||'');
  CMP_DTE.dte.rutCodigo=info.codigo||'';
  CMP_DTE.dte.rutDV=info.dv||'';
}
function cmpDteAutoTotal(){
  const d=CMP_DTE.dte;if(!d)return;
  const total=(+d.neto||0)+(+d.exento||0)+(+d.iva||0)+(+d.otrosImpuestos||0);
  const inp=document.getElementById('cmpdte-total');
  if(inp&&document.activeElement!==inp){inp.value=total;d.total=total;}
}

function guardarCmpEdDte(){
  const d=CMP_DTE.dte;
  const li=CMP_DTE.lineaIdx;
  if(!d||li<0)return;
  if(!d.rutCodigo){toast('⚠️ Falta el RUT','e');return;}
  if(!d.tipoDTE){toast('⚠️ Falta el tipo de documento','e');return;}
  if(!String(d.numero||'').trim()){toast('⚠️ Falta el folio','e');return;}
  if(!d.fecha){toast('⚠️ Falta la fecha','e');return;}

  CMP_MODAL.edit.movs[li].dte={...d};
  const m=CMP_MODAL.edit.movs[li];
  // Sugerir monto según tipo de cuenta si aún no hay debe/haber
  if(!m.debe&&!m.haber&&d.total){
    const cuentaTipo=CUENTAS_AUX[m.cd];
    if(cuentaTipo==='proveedor'||m.cd==='2102006')m.haber=+d.total;
    else if(cuentaTipo==='cliente')m.debe=+d.total;
    else m.debe=+d.total;
  }
  cerrarCmpEdDte();
  renderCmpModal();
  toast('✅ Datos del documento actualizados');
}

export {buscarComprobantesHdr, cmpHdrBuscar, cmpHdrTecla, cmpHdrCerrar, cmpHdrElegir, abrirComprobantePor, corregirDescuadreCmp,
        setCmpFiltro, limpiarCmpFiltro, toggleCmpDet,
        cmpNumeroBuscar, renderCmpNumeroList, cmpNumeroElegir, cmpNumeroElegirResultado, mismaEntradaCmp,
        abrirCmpModal, cerrarCmpModal, cmpModalEditar, cmpModalCancelar, cmpModalGuardar,
        eliminarComprobante, anularComprobante,
        setCmpEdGlosa, setCmpEdFecha, setCmpEdCuenta, setCmpEdCampo, setCmpEdMonto, setCmpEdMontoBlur, addCmpEdLinea, delCmpEdLinea,
        abrirCmpEdDte, cerrarCmpEdDte, setCmpDteCampo, setCmpDteTipo, setCmpDteRut, cmpDteAutoTotal, guardarCmpEdDte};
