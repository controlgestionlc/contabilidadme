// reportes.js — Libro Diario, Mayor, Balance, Resultados (núcleo de reportes)
// genDiario y buildMayor son la base de casi todos los cálculos.
import {toast, fmtC, fmt, pn, today, MESES, MC, IVA, pdcNm, PDC, CUENTAS_SEL, dteV, dteC} from './core.js';
import {nav} from './ui.js';
import {retencionHonorarios} from './indicadores.js';
import {toggleAgingDetalle} from './auxiliares.js';
import {mesOpts, mesRango} from './helpers.js';
import {pendientesCC} from './asigcc.js';
import {S} from './state.js';
import './storage.js';
import {asientoVenta, asientoCompra} from './motor-contable.js';
import {tasaIDPC} from './regimenes.js';

// ═══ LIBRO DIARIO (auto + manuales) ═══
let DIARIO_Q='';   // texto de búsqueda del libro diario
// Filtros de periodo del Libro Diario y del Libro Mayor. El mes es un atajo:
// al elegirlo se rellenan desde/hasta con el primer y último día del mes.
let DIA_F={mes:'',desde:'',hasta:''};
let MAY_F={mes:'',desde:'',hasta:'',q:''};

// Nombre de archivo estándar para las exportaciones
function nombreArchivoExport(base,f){
  const emp=(S.empresa.nombre||'contabilidad').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'')||'contabilidad';
  const per=f&&(f.desde||f.hasta)?`_${(f.desde||'inicio')}_a_${(f.hasta||'fin')}`:`_${S.empresa.anio}`;
  return `${emp}_${base}${per}.xlsx`;
}
// Etiqueta legible del periodo aplicado
function etiquetaPeriodo(f){
  if(f.mes)return `${MESES[+f.mes-1]} ${S.empresa.anio}`;
  if(f.desde&&f.hasta)return `${f.desde} a ${f.hasta}`;
  if(f.desde)return `desde ${f.desde}`;
  if(f.hasta)return `hasta ${f.hasta}`;
  return `Ejercicio ${S.empresa.anio}`;
}
// Ancho de columnas para las hojas exportadas
function anchosXLSX(hdr,rows){
  return hdr.map((h,i)=>({wch:Math.min(46,Math.max(String(h).length+2,...rows.slice(0,400).map(r=>String(r[i]??'').length+2)))}));
}
function genDiario(){
  const entries=[];let n=1;const anio=S.empresa.anio;

  // ASIENTO N°0 — Balance de Apertura
  if(S.apertura&&S.apertura.movs&&S.apertura.movs.length){
    entries.push({n:0,fecha:S.apertura.fecha,glosa:S.apertura.glosa||'Balance de Apertura',movs:S.apertura.movs.map(m=>({...m})),origen:'apertura'});
  }

  // V2: el asiento persistido es el maestro. Sólo generamos en memoria como
  // compatibilidad para documentos históricos que aún no han sido migrados.
  const tieneAsiento=(fuente,docId)=>(S.asientos||[]).some(a=>!a.anulado&&a.tipo==='documento'&&a.fuente===fuente&&a.docId===docId);
  const automaticos=[];
  (S.ventas||[]).filter(d=>!d.excluidoAuto&&d.estado!=='anulado'&&!tieneAsiento('ventas',d.id)).forEach(d=>automaticos.push(asientoVenta(d)));
  (S.compras||[]).filter(d=>!d.excluidoAuto&&d.estado!=='anulado'&&!tieneAsiento('compras',d.id)).forEach(d=>automaticos.push(asientoCompra(d)));
  automaticos.sort((a,b)=>(a.fecha||'').localeCompare(b.fecha||'')).forEach(e=>{
    entries.push({
      n:e.folioComp||n++,fecha:e.fecha,glosa:e.glosa,movs:e.movs,origen:'legado-auto',
      fuente:e.fuente,docId:e.docId,tipoDTE:e.tipoDTE,folio:e.folio,rutCodigo:e.rutCodigo,
      cuadre:e.cuadre,tributacion:e.tributacion
    });
  });

  // Honorarios V2: los asientos persistidos son el maestro. Para registros
  // históricos aún no migrados, mantenemos un fallback individual (no mensual)
  // que reconoce Honorarios por pagar; nunca presume pago inmediato al Banco.
  const tieneAsientoHon=id=>(S.asientos||[]).some(a=>!a.anulado&&a.fuente==='honorarios'&&a.docId===id&&a.subtipo==='honorario');
  (S.honorarios||[]).filter(h=>h.estado!=='anulado'&&!tieneAsientoHon(h.id)).forEach(h=>{
    const bruto=+(h.bruto||0); if(!bruto)return;
    const sinRet=h.tipoRetencion==='sin_retencion';
    const tasa=sinRet?0:(h.tasaRetencion!=null?+h.tasaRetencion:retencionHonorarios(S.empresa.anio));
    const ret=sinRet?0:(h.retencion!=null?+h.retencion:Math.round(bruto*tasa)),liq=bruto-ret;
    const limpio=String(h.rut||'').replace(/[^0-9kK]/g,'').toUpperCase();
    const rutCodigo=limpio.length>1?limpio.slice(0,-1):'',rutDV=limpio.length>1?limpio.slice(-1):'';
    const fecha=h.fecha||`${anio}-${String(h.mes||1).padStart(2,'0')}-28`;
    const aux={rutCodigo,rutDV,docId:h.id,tipoAux:'honorario',desc:h.nombre||'Honorario'};
    const movs=[
      {cd:'3202019',nm:pdcNm('3202019'),debe:bruto,haber:0,...aux,cc:h.cc||undefined},
      {cd:'2102006',nm:pdcNm('2102006'),debe:0,haber:liq,...aux},
    ];
    if(ret)movs.splice(1,0,{cd:'2103002',nm:pdcNm('2103002'),debe:0,haber:ret,docId:h.id,tributo:'retencion_honorarios'});
    entries.push({n:n++,fecha,glosa:`Honorario — ${h.nombre||'prestador'}`,origen:'legado-auto',fuente:'honorarios',docId:h.id,movs});
  });

  // Asientos persistidos: pagos, remuneraciones, depreciaciones, manuales, etc.
  [...S.asientos].filter(a=>!a.anulado).sort((a,b)=>a.fecha.localeCompare(b.fecha)).forEach(a=>{
    const origen=a.tipo==='manual'?'manual':(a.generadoAutomaticamente||a.origen==='motor-v2')?'auto':'asiento';
    entries.push({n:a.numeroContable||a.folioComp||a.n||n++,fecha:a.fecha,glosa:a.glosa,movs:a.movs,origen,ref:a.n,tipo:a.tipo||'manual',
      asientoId:a.id,numeroContable:a.numeroContable||null,fuente:a.fuente||a.referenciaDoc?.fuente||'',docId:a.docId||a.referenciaDoc?.docId||'',subtipo:a.subtipo||'',
      referenciaDoc:a.referenciaDoc||null,
      cuentaPago:a.cuentaPago||'',documentos:a.documentos||[],generadoAutomaticamente:!!a.generadoAutomaticamente});
  });
  return entries.sort((a,b)=>{
    if(a.origen==='apertura')return -1;if(b.origen==='apertura')return 1;
    return (a.fecha||'').localeCompare(b.fecha||'');
  });
}
function renderDiario(){
  const todas=genDiario(),el=document.getElementById('diario-content');
  if(!todas.length){el.innerHTML=`<div class="empty"><div class="ei">📖</div>No hay asientos registrados.</div>`;return;}

  // Detectar descuadres sobre TODOS los asientos (no solo los visibles).
  const descuadres=[];
  todas.forEach(e=>{
    const eD=e.movs.reduce((s,m)=>s+m.debe,0);
    const eH=e.movs.reduce((s,m)=>s+m.haber,0);
    const dif=Math.round(eD-eH);
    if(Math.abs(dif)>=0.000001){
      descuadres.push({n:e.n,fecha:e.fecha,glosa:e.glosa,debe:eD,haber:eH,dif,origen:e.origen,fuente:e.fuente,docId:e.docId,ref:e.ref});
    }
  });

  // Panel de alerta en el encabezado si hay descuadres
  let alerta='';
  if(descuadres.length){
    alerta=`<div style="background:rgba(248,81,73,.08);border:1px solid var(--err);border-radius:8px;padding:14px 16px;margin-bottom:14px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <span style="font-size:18px">⚠️</span>
        <span style="font-weight:700;color:var(--err)">${descuadres.length} comprobante${descuadres.length===1?'':'s'} descuadrado${descuadres.length===1?'':'s'}</span>
        <span style="font-size:11px;color:var(--mt)">— la partida doble no cuadra en estos asientos</span>
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;color:var(--err)">
        ${descuadres.slice(0,6).map(d=>`<span style="display:inline-block;border:1px solid rgba(248,81,73,.45);border-radius:6px;padding:3px 7px;font-family:var(--mono);font-weight:700">N° ${String(d.n??'S/N').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]))}</span>`).join('')}
        ${descuadres.length>6?`<span style="font-size:11px;color:var(--mt);padding:4px">y ${descuadres.length-6} más</span>`:''}
      </div>
      <div style="max-height:180px;overflow-y:auto">
        <table style="width:100%;font-size:11px">
          <thead><tr style="color:var(--mt);text-transform:uppercase;font-size:10px">
            <th class="tl" style="width:40px;padding:4px 8px">N°</th>
            <th class="tl" style="width:90px;padding:4px 8px">FECHA</th>
            <th class="tl" style="padding:4px 8px">GLOSA</th>
            <th style="text-align:right;padding:4px 8px">DEBE</th>
            <th style="text-align:right;padding:4px 8px">HABER</th>
            <th style="text-align:right;padding:4px 8px">DIFERENCIA</th>
            <th style="padding:4px 8px;text-align:center">CORREGIR</th>
          </tr></thead>
          <tbody>${descuadres.map(d=>{
            let btn='';
            if(d.origen==='manual'){
              btn=`<button class="btn btn-i" style="font-size:10px;padding:2px 8px" onclick="editarAsientoRef(${d.ref})">✏️ Editar</button>`;
            }else if(d.fuente==='compras'){
              btn=`<button class="btn btn-i" style="font-size:10px;padding:2px 8px" onclick="corregirDesdeDiario('compras','${d.docId}')">🧾 Al doc</button>`;
            }else if(d.fuente==='ventas'){
              btn=`<button class="btn btn-i" style="font-size:10px;padding:2px 8px" onclick="corregirDesdeDiario('ventas','${d.docId}')">🛒 Al doc</button>`;
            }else if(d.origen==='apertura'){
              btn=`<button class="btn btn-i" style="font-size:10px;padding:2px 8px" onclick="nav('apertura')">🔰 Abrir</button>`;
            }else{
              btn='<span style="color:var(--mt);font-size:10px">—</span>';
            }
            return `<tr>
              <td class="tl" style="padding:4px 8px;font-family:var(--mono);font-weight:600">${d.n}</td>
              <td class="tl" style="padding:4px 8px;font-family:var(--mono)">${d.fecha}</td>
              <td class="tl" style="padding:4px 8px">${d.glosa}</td>
              <td style="text-align:right;padding:4px 8px;font-family:var(--mono)">${fmtC(d.debe)}</td>
              <td style="text-align:right;padding:4px 8px;font-family:var(--mono)">${fmtC(d.haber)}</td>
              <td style="text-align:right;padding:4px 8px;font-family:var(--mono);color:var(--err);font-weight:700">${fmtC(Math.abs(d.dif))}</td>
              <td style="padding:4px 8px;text-align:center">${btn}</td>
            </tr>`;
          }).join('')}</tbody>
        </table>
      </div>
    </div>`;
  }

  // Filtros de periodo + buscador. Solo re-renderiza la tabla, no la barra,
  // para no perder el foco del input al teclear (importante en móvil).
  const buscador=`<div class="filter-row" style="margin-bottom:12px">
    <span class="f-lbl">Periodo:</span>
    <select id="diario-mes" onchange="onDiarioMes(this.value)">${mesOpts(DIA_F.mes)}</select>
    <input type="date" id="diario-desde" value="${DIA_F.desde}" onchange="setDiarioFecha('desde',this.value)" title="Desde">
    <input type="date" id="diario-hasta" value="${DIA_F.hasta}" onchange="setDiarioFecha('hasta',this.value)" title="Hasta">
    <span class="f-lbl">Buscar:</span>
    <input type="text" id="diario-search" placeholder="N° comprobante, glosa, cuenta o RUT…" value="${DIARIO_Q.replace(/"/g,'&quot;')}"
      oninput="setDiarioQ(this.value)" style="min-width:230px">
    <button class="btn btn-g" onclick="limpiarFiltrosDiario()">Limpiar</button>
    <button class="btn btn-i" onclick="exportarDiarioExcel()" title="Descargar el Libro Diario en Excel">📊 Excel</button>
    <span class="doc-count" id="diario-count"></span>
  </div>`;

  el.innerHTML=alerta+buscador+`<div id="diario-tabla"></div>`;
  renderDiarioTabla();
}

// ── Filtros del Libro Diario ──
function onDiarioMes(v){
  DIA_F.mes=v;
  if(v){const r=mesRango(+v);DIA_F.desde=r.desde;DIA_F.hasta=r.hasta;}
  else{DIA_F.desde='';DIA_F.hasta='';}
  const d=document.getElementById('diario-desde'),h=document.getElementById('diario-hasta');
  if(d)d.value=DIA_F.desde;if(h)h.value=DIA_F.hasta;
  renderDiarioTabla();
}
function setDiarioFecha(k,v){
  DIA_F[k]=v;
  // Ajustar el rango a mano desactiva el atajo de mes
  DIA_F.mes='';const s=document.getElementById('diario-mes');if(s)s.value='';
  renderDiarioTabla();
}
function limpiarFiltrosDiario(){
  DIA_F={mes:'',desde:'',hasta:''};DIARIO_Q='';
  renderDiario();
}
// Aplica periodo + búsqueda a los asientos del diario
function filtrarDiario(entries){
  const {desde,hasta}=DIA_F;
  const q=DIARIO_Q.toLowerCase().trim();
  return entries.filter(e=>{
    const f=e.fecha||'';
    if(desde&&f<desde)return false;
    if(hasta&&f>hasta)return false;
    if(!q)return true;
    if(String(e.n||'').includes(q))return true;
    if((e.glosa||'').toLowerCase().includes(q))return true;
    return e.movs.some(m=>String(m.cd).includes(q)
      ||(m.nm||pdcNm(m.cd)||'').toLowerCase().includes(q)
      ||(m.desc||'').toLowerCase().includes(q));
  });
}

// Renderiza SOLO la tabla del diario (depende de la búsqueda). Separado para
// no destruir el input de búsqueda al teclear (evita perder foco en móvil).
function renderDiarioTabla(){
  const box=document.getElementById('diario-tabla');
  if(!box)return;
  const todasEntries=genDiario();
  let entries=filtrarDiario(todasEntries);

  const hayFiltro=!!(DIARIO_Q.trim()||DIA_F.desde||DIA_F.hasta);
  const totalDisp=entries.length;

  const cnt=document.getElementById('diario-count');
  if(cnt)cnt.textContent=hayFiltro?`${totalDisp} asiento${totalDisp===1?'':'s'} · ${etiquetaPeriodo(DIA_F)}`:'';

  // Sin filtros no se pinta ningún asiento: el diario completo del año son
  // miles de filas. Se muestra solo la barra de filtros y un aviso.
  if(!hayFiltro){
    box.innerHTML=`<div style="text-align:center;padding:40px 20px;color:var(--mt)">
      <div style="font-size:36px;margin-bottom:8px">📖</div>
      <div style="font-size:13px;font-weight:600;color:var(--tx)">Aplica un filtro para ver el Libro Diario</div>
      <div style="font-size:12px;margin-top:6px">Elige un mes, un rango de fechas o busca por N° de comprobante, glosa, cuenta o RUT.</div>
      <div style="font-size:11px;margin-top:10px">${todasEntries.length} asiento${todasEntries.length===1?'':'s'} en el ejercicio ${S.empresa.anio}</div>
    </div>`;
    return;
  }

  if(!entries.length){
    box.innerHTML=`<div style="text-align:center;padding:30px;color:var(--mt)">No hay asientos que coincidan con el filtro.</div>`;
    return;
  }
  const ocultos=0,aviso='';

  // Totales: del periodo filtrado si hay filtro, de todo el diario si no.
  let tD=0,tH=0;
  filtrarDiario(todasEntries).forEach(e=>{tD+=e.movs.reduce((s,m)=>s+m.debe,0);tH+=e.movs.reduce((s,m)=>s+m.haber,0);});

  let h=aviso+`<div class="card-np"><div class="tw"><table class="tbl-fija">
    <colgroup><col style="width:42px"><col style="width:92px"><col><col style="width:82px"><col style="width:118px"><col style="width:118px"><col style="width:70px"><col style="width:92px"></colgroup>
    <thead><tr><th class="tl">N°</th><th class="tl">FECHA</th><th class="tl">GLOSA / CUENTA</th><th class="tl">CÓD.</th><th>DEBE</th><th>HABER</th><th class="tl">ORIGEN</th><th class="tl no-print">EDITAR</th></tr></thead><tbody>`;
  entries.forEach(e=>{
    const eD=e.movs.reduce((s,m)=>s+m.debe,0),eH=e.movs.reduce((s,m)=>s+m.haber,0);
    const asDescuadrado=Math.abs(eD-eH)>=0.000001;
    const estiloTotal=asDescuadrado?'color:var(--err);font-weight:700':'';
    const ob=e.origen==='manual'?`<span class="badge bb">Manual</span>`:`<span class="badge" style="background:rgba(130,130,130,.12);color:var(--mt)">Auto</span>`;
    const trStyle=asDescuadrado?' style="background:rgba(248,81,73,.05)"':'';
    const badgeDescuadre=asDescuadrado?' <span style="background:rgba(248,81,73,.15);color:var(--err);padding:1px 6px;border-radius:3px;font-size:9px;font-weight:700;margin-left:6px">⚠ DESCUADRE</span>':'';
    // Botón de edición por asiento. El destino depende del origen: los manuales
    // se abren en el editor, los automáticos llevan al documento que los genera.
    const d=destinoEdicion(e);
    const btn=d
      ? `<button class="btn btn-i btn-edit-dia" onclick="${d.fn}" title="${attr(d.hint)}">${d.ic} ${d.lbl}</button>`
      : `<span style="color:var(--mt);font-size:10px">—</span>`;
    h+=`<tr class="rth"${trStyle}><td class="tl">${e.n}</td><td class="tl" style="font-family:var(--mono);font-size:11px">${e.fecha}</td><td class="cel-trunc" colspan="2" title="${attr(e.glosa)}">${e.glosa}${badgeDescuadre}</td><td style="${estiloTotal}">${fmtC(eD)}</td><td style="${estiloTotal}">${fmtC(eH)}</td><td>${ob}</td><td class="tl no-print">${btn}</td></tr>`;
    e.movs.forEach(m=>{
      const isH=m.haber>0;
      const nmC=m.nm||pdcNm(m.cd)||'';
      const extra=m.desc?` — ${m.desc}`:'';
      h+=`<tr><td></td><td></td><td class="cel-trunc" title="${attr(nmC+extra)}" style="${isH?'padding-left:28px;color:var(--mt)':''}">${nmC}${extra?`<span style="color:var(--mt);font-size:11px">${extra}</span>`:''}</td><td class="tl" style="font-family:var(--mono);font-size:11px;color:var(--mt)">${m.cd}</td><td>${m.debe?fmtC(m.debe):''}</td><td>${m.haber?fmtC(m.haber):''}</td><td></td><td class="no-print"></td></tr>`;
    });
  });
  const ok=Math.abs(tD-tH)<0.000001;
  h+=`</tbody><tfoot><tr><td class="tl" colspan="4">TOTALES ${hayFiltro?'— '+etiquetaPeriodo(DIA_F):(ocultos?'(todo el diario)':'')}</td><td style="${ok?'':'color:var(--err);font-weight:700'}">${fmtC(tD)}</td><td style="${ok?'':'color:var(--err);font-weight:700'}">${fmtC(tH)}</td><td></td><td class="no-print"></td></tr></tfoot></table></div></div>`;
  h+=`<div style="margin-top:10px;font-size:12px;color:${ok?'var(--ach)':'var(--err)'}">
    ${ok?'✅ Partida doble cuadrada — Debe = Haber = '+fmtC(tD):'⚠️ Descuadre: Debe '+fmtC(tD)+' | Haber '+fmtC(tH)+' | Diferencia '+fmtC(Math.abs(tD-tH))}</div>`;
  box.innerHTML=h;
}

// ── Exportar Libro Diario a Excel (respeta los filtros activos) ──
function exportarDiarioExcel(){
  try{
    if(typeof XLSX==='undefined'){toast('⚠️ Biblioteca Excel no cargada (¿sin internet?)','e');return;}
    const entries=filtrarDiario(genDiario());
    if(!entries.length){toast('⚠️ No hay asientos que exportar con el filtro actual','e');return;}
    const hdr=['N°','FECHA','GLOSA','CÓDIGO','CUENTA','DESCRIPCIÓN','DEBE','HABER','ORIGEN'];
    const rows=[];
    let tD=0,tH=0;
    entries.forEach(e=>{
      const org=e.origen==='manual'?'Manual':(e.origen==='apertura'?'Apertura':'Automático');
      e.movs.forEach(m=>{
        tD+=m.debe||0;tH+=m.haber||0;
        rows.push([e.n,e.fecha,e.glosa||'',m.cd,m.nm||pdcNm(m.cd)||'',m.desc||'',
          Math.round(m.debe||0),Math.round(m.haber||0),org]);
      });
    });
    rows.push(['','','TOTALES','','','',Math.round(tD),Math.round(tH),'']);
    const ws=XLSX.utils.aoa_to_sheet([hdr,...rows]);
    ws['!cols']=anchosXLSX(hdr,rows);
    const wb=XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb,ws,'Libro Diario');
    // Portada con los datos del contribuyente y el periodo exportado
    const meta=[
      ['LIBRO DIARIO'],
      ['Empresa',S.empresa.nombre||''],
      ['RUT',S.empresa.rut||''],
      ['Giro',S.empresa.giro||''],
      ['Periodo',etiquetaPeriodo(DIA_F)],
      ['Búsqueda',DIARIO_Q||'(sin filtro de texto)'],
      ['Asientos',entries.length],
      ['Total Debe',Math.round(tD)],
      ['Total Haber',Math.round(tH)],
      ['Diferencia',Math.round(tD-tH)],
      ['Generado',new Date().toLocaleString('es-CL')],
    ];
    const wsm=XLSX.utils.aoa_to_sheet(meta);
    wsm['!cols']=[{wch:16},{wch:46}];
    XLSX.utils.book_append_sheet(wb,wsm,'Datos');
    XLSX.writeFile(wb,nombreArchivoExport('libro_diario',DIA_F));
    toast(`✅ Libro Diario exportado — ${entries.length} asiento${entries.length===1?'':'s'}, ${rows.length-1} líneas`);
  }catch(e){toast('❌ Error al exportar: '+e.message,'e');}
}

function setDiarioQ(v){
  DIARIO_Q=v;
  renderDiarioTabla();
}

// Puentes usados desde el reporte de descuadres del libro diario y desde Comprobantes.
// - Manuales: abrir editor de asientos
// - Compras/ventas: navegar al libro y filtrar por el número
async function corregirDesdeDiario(fuente,docId){
  if(!docId){nav(fuente);return;}
  nav(fuente);
  // Le damos tiempo a la sección para renderizarse y luego intentamos abrir el
  // editor del documento específico. Los IDs de docs importados llevan
  // prefijo 'c_imp_' o 'v_imp_'.
  setTimeout(()=>{
    try{
      if(fuente==='compras'&&window.editarCompra)window.editarCompra(docId);
      else if(fuente==='ventas'&&window.editarVenta)window.editarVenta(docId);
    }catch(e){}
  },80);
}

// ── A dónde lleva "Editar" un asiento ──
// Un asiento del diario no siempre se edita en el mismo lugar: los manuales se
// abren en el editor de asientos, pero los automáticos son el reflejo de un
// documento y hay que corregir el documento, no el asiento. Esta función
// resuelve el destino una sola vez y la comparten el Libro Diario y
// Comprobantes, para que el botón haga lo mismo en las dos pantallas.
function destinoEdicion(e){
  if(!e)return null;
  if((e.fuente==='ventas'||e.referenciaDoc?.fuente==='ventas')&&(e.docId||e.referenciaDoc?.docId))
    return {ic:'🛒',lbl:'Al doc',hint:'Este asiento está vinculado al Libro de Ventas y debe corregirse en su documento',
            fn:`corregirDesdeDiario('ventas','${e.docId||e.referenciaDoc.docId}')`};
  if((e.fuente==='compras'||e.referenciaDoc?.fuente==='compras')&&(e.docId||e.referenciaDoc?.docId))
    return {ic:'🧾',lbl:'Al doc',hint:'Este asiento está vinculado al Libro de Compras y debe corregirse en su documento',
            fn:`corregirDesdeDiario('compras','${e.docId||e.referenciaDoc.docId}')`};
  if(e.origen==='manual'&&e.ref!=null)
    return {ic:'✏️',lbl:'Editar',hint:`Editar el asiento manual N°${e.ref}`,fn:`editarAsientoRef(${e.ref})`};
  if(e.origen==='apertura')
    return {ic:'🔰',lbl:'Abrir',hint:'Ir al Balance de Apertura',fn:`nav('apertura')`};
  if(e.fuente==='ventas')
    return {ic:'🛒',lbl:'Al doc',hint:'Este asiento lo genera un documento: se edita en el Libro de Ventas',
            fn:e.docId?`corregirDesdeDiario('ventas','${e.docId}')`:`nav('ventas')`};
  if(e.fuente==='compras')
    return {ic:'🧾',lbl:'Al doc',hint:'Este asiento lo genera un documento: se edita en el Libro de Compras',
            fn:e.docId?`corregirDesdeDiario('compras','${e.docId}')`:`nav('compras')`};
  if(e.fuente==='honorarios')
    return {ic:'📝',lbl:'Boleta',hint:'Abrir la boleta de honorarios que origina este comprobante',
            fn:e.docId?`abrirHonComprobante('${e.docId}')`:`nav('honorarios')`};
  return null;
}

// Abre el editor de un asiento manual por su n° correlativo.
// El destino es 'comprobantes', que es donde vive el formulario de asientos
// manuales; 's-asientos' ya no existe como sección.
function editarAsientoRef(n){
  const a=S.asientos.find(x=>String(x.id)===String(n))||S.asientos.find(x=>+x.numeroContable===+n)||S.asientos.find(x=>x.n===n);
  if(!a){toast('⚠️ No se encontró el asiento N°'+n,'e');return;}
  if(a.referenciaDoc?.fuente&&a.referenciaDoc?.docId){
    corregirDesdeDiario(a.referenciaDoc.fuente,a.referenciaDoc.docId);
    return;
  }
  nav('comprobantes');
  setTimeout(()=>{try{window.editarAsiento&&window.editarAsiento(a.id);}catch(e){}},50);
}

// ═══ MAYOR ═══
// buildMayor(desde,hasta) — sin argumentos se comporta exactamente igual que
// antes (todo el ejercicio). Con rango, los movimientos anteriores a `desde` se
// acumulan en `saldoAnterior` (como corresponde a un mayor por periodo) y los
// posteriores a `hasta` se ignoran. El saldo final sigue siendo
// saldoAnterior + debe − haber, así que Balance y Resultados no cambian.
function buildMayor(desde,hasta){
  const M={};
  genDiario().forEach(e=>{
    const f=e.fecha||'';
    const antes=!!(desde&&f<desde);
    const despues=!!(hasta&&f>hasta);
    e.movs.forEach(m=>{
      if(!M[m.cd])M[m.cd]={nm:m.nm||pdcNm(m.cd),debe:0,haber:0,saldoAnterior:0,movs:[]};
      if(antes){M[m.cd].saldoAnterior+=m.debe-m.haber;return;}
      if(despues)return;
      M[m.cd].debe+=m.debe;M[m.cd].haber+=m.haber;
      M[m.cd].movs.push({n:e.n,fecha:e.fecha,glosa:e.glosa,desc:m.desc||'',debe:m.debe,haber:m.haber});
    });
  });
  Object.values(M).forEach(a=>{let s=a.saldoAnterior;a.movs.forEach(m=>{s+=m.debe-m.haber;m.saldo=s;});a.saldo=a.saldoAnterior+a.debe-a.haber;});
  return M;
}

// ── Filtros del Libro Mayor ──
function onMayorMes(v){
  MAY_F.mes=v;
  if(v){const r=mesRango(+v);MAY_F.desde=r.desde;MAY_F.hasta=r.hasta;}
  else{MAY_F.desde='';MAY_F.hasta='';}
  const d=document.getElementById('mayor-desde'),h=document.getElementById('mayor-hasta');
  if(d)d.value=MAY_F.desde;if(h)h.value=MAY_F.hasta;
  renderMayorTabla();
}
function setMayorFecha(k,v){
  MAY_F[k]=v;
  MAY_F.mes='';const s=document.getElementById('mayor-mes');if(s)s.value='';
  renderMayorTabla();
}
function setMayorQ(v){MAY_F.q=v;renderMayorTabla();}
function limpiarFiltrosMayor(){
  MAY_F={mes:'',desde:'',hasta:'',q:''};
  MAY_EXP.clear();
  renderMayor();
}
// La descripción de la línea suele repetir lo que ya dice la glosa
// ("Factura N°539 — PROVEEDOR" + "PROVEEDOR · Factura N°539"). Si todas sus
// palabras ya están en la glosa, no aporta nada y la omitimos.
function descAporta(glosa,desc){
  if(!desc)return false;
  const norm=t=>String(t).toLowerCase().replace(/[^a-z0-9áéíóúñ]+/gi,' ').trim();
  const g=' '+norm(glosa)+' ';
  return norm(desc).split(' ').filter(w=>w.length>2).some(w=>!g.includes(' '+w+' '));
}
// Escapa comillas para usar el texto dentro de un atributo title
const attr=t=>String(t||'').replace(/"/g,'&quot;');

// Cuentas visibles según periodo y búsqueda (código, nombre o glosa del movimiento)
function cuentasMayorFiltradas(M){
  const q=(MAY_F.q||'').toLowerCase().trim();
  const hayPeriodo=!!(MAY_F.desde||MAY_F.hasta);
  return Object.keys(M).filter(cd=>{
    const a=M[cd];
    // Con periodo activo, ocultar cuentas sin movimientos ni saldo de arrastre
    if(hayPeriodo&&!a.movs.length&&Math.abs(a.saldoAnterior)<0.5)return false;
    if(!q)return true;
    if(cd.toLowerCase().includes(q))return true;
    if((a.nm||'').toLowerCase().includes(q))return true;
    return a.movs.some(m=>(m.glosa||'').toLowerCase().includes(q)||(m.desc||'').toLowerCase().includes(q));
  }).sort();
}

// Construye el Mayor de OTRO año leyendo su storage, sin alterar el estado actual.
// Reutiliza genDiario/buildMayor haciendo swap temporal de las colecciones de S.
async function buildMayorAnio(y){
  const bak={ventas:S.ventas,compras:S.compras,honorarios:S.honorarios,asientos:S.asientos,apertura:S.apertura,anio:S.empresa.anio};
  const tmp={ventas:[],compras:[],honorarios:[],asientos:[],apertura:null};
  for(const[k,d] of [['ventas-'+y,'ventas'],['compras-'+y,'compras'],['honorarios-'+y,'honorarios'],['asientos-'+y,'asientos']]){
    try{const r=await window.storage.get(k);if(r){const p=JSON.parse(r.value);if(Array.isArray(p))tmp[d]=p;}}catch(e){}
  }
  try{const r=await window.storage.get('apertura-'+y);if(r)tmp.apertura=JSON.parse(r.value);}catch(e){}
  // Swap
  S.ventas=tmp.ventas;S.compras=tmp.compras;S.honorarios=tmp.honorarios;S.asientos=tmp.asientos;S.apertura=tmp.apertura;S.empresa.anio=y;
  let M;
  try{M=buildMayor();}finally{
    // Restaurar SIEMPRE
    S.ventas=bak.ventas;S.compras=bak.compras;S.honorarios=bak.honorarios;S.asientos=bak.asientos;S.apertura=bak.apertura;S.empresa.anio=bak.anio;
  }
  return M;
}
// Totales agregados de un Mayor (para comparativo)
function totalesDeMayor(M){
  const keys=Object.keys(M);
  const get=cd=>{const a=M[cd];return a?Math.abs(a.saldo):0;};
  return {
    ingresos:sumaPres(M,keys.filter(k=>k.startsWith('4'))),
    costos:keys.filter(k=>k.startsWith('3')).reduce((s,k)=>s+M[k].saldo,0),
    activos:keys.filter(k=>k.startsWith('1')).reduce((s,k)=>s+M[k].saldo,0),
    pasivos:sumaPres(M,keys.filter(k=>k.startsWith('2')&&!k.startsWith('23'))),
    capital:sumaPres(M,keys.filter(k=>k.startsWith('23'))),
  };
}
// Estado del comparativo (año seleccionado para comparar). null = sin comparar.
let CMP_YEAR=null;
function fmtVar(actual,anterior){
  const dif=actual-anterior;
  if(Math.abs(anterior)<0.5){
    if(Math.abs(actual)<0.5)return {txt:'–',color:'var(--mt)',sig:false};
    return {txt:'nuevo',color:'var(--info)',sig:true};
  }
  const pct=dif/Math.abs(anterior)*100;
  const sig=Math.abs(pct)>=20; // variación significativa ≥20%
  const color=dif>0?'var(--ach)':(dif<0?'var(--err)':'var(--mt)');
  return {txt:(pct>0?'+':'')+pct.toFixed(1)+'%',color,sig,dif};
}
function renderMayor(){
  const el=document.getElementById('mayor-content');
  if(!Object.keys(buildMayor()).length){el.innerHTML=`<div class="empty"><div class="ei">📊</div>No hay movimientos.</div>`;return;}
  // Barra de filtros fija; solo se re-renderiza el contenido al filtrar.
  el.innerHTML=`<div class="filter-row" style="margin-bottom:12px">
    <span class="f-lbl">Periodo:</span>
    <select id="mayor-mes" onchange="onMayorMes(this.value)">${mesOpts(MAY_F.mes)}</select>
    <input type="date" id="mayor-desde" value="${MAY_F.desde}" onchange="setMayorFecha('desde',this.value)" title="Desde">
    <input type="date" id="mayor-hasta" value="${MAY_F.hasta}" onchange="setMayorFecha('hasta',this.value)" title="Hasta">
    <span class="f-lbl">Buscar:</span>
    <input type="text" id="mayor-search" placeholder="Código, nombre de cuenta o glosa…" value="${(MAY_F.q||'').replace(/"/g,'&quot;')}"
      oninput="setMayorQ(this.value)" style="min-width:230px">
    <button class="btn btn-g" onclick="limpiarFiltrosMayor()">Limpiar</button>
    <button class="btn btn-i" onclick="exportarMayorExcel()" title="Descargar el Libro Mayor en Excel">📊 Excel</button>
    <span class="doc-count" id="mayor-count"></span>
  </div><div id="mayor-tabla"></div>`;
  renderMayorTabla();
}

// Renderiza SOLO el contenido del mayor (respeta periodo y búsqueda).
// Vista resumida: una fila por cuenta (código, nombre, debe, haber, saldo).
// El detalle de movimientos se arma recién al expandir la cuenta, así la
// pantalla no pinta miles de filas al entrar.
let MAY_M={};              // último Mayor calculado (lo usa el detalle al expandir)
const MAY_EXP=new Set();   // cuentas expandidas (se conservan al filtrar)
function renderMayorTabla(){
  const box=document.getElementById('mayor-tabla');if(!box)return;
  const M=buildMayor(MAY_F.desde,MAY_F.hasta);
  MAY_M=M;
  const keys=cuentasMayorFiltradas(M);

  const cnt=document.getElementById('mayor-count');
  if(cnt)cnt.textContent=`${keys.length} cuenta${keys.length===1?'':'s'} · ${etiquetaPeriodo(MAY_F)}`;

  if(!keys.length){
    box.innerHTML=`<div style="text-align:center;padding:30px;color:var(--mt)">No hay cuentas que coincidan con el filtro.</div>`;
    return;
  }

  // Los KPI se calculan sobre las cuentas visibles del periodo
  const tA=sumaPres(M,keys.filter(k=>k.startsWith('1')));
  const tP=sumaPres(M,keys.filter(k=>k.startsWith('2')&&!k.startsWith('23')));
  const tC=sumaPres(M,keys.filter(k=>k.startsWith('3')));
  const tI=sumaPres(M,keys.filter(k=>k.startsWith('4')));
  let tD=0,tH=0;
  let h=`<div class="kpi-grid">
    <div class="kpi"><div class="kpi-lbl">Total Activos</div><div class="kpi-val pos">${fmtC(tA)}</div></div>
    <div class="kpi"><div class="kpi-lbl">Total Pasivos</div><div class="kpi-val neg">${fmtC(tP)}</div></div>
    <div class="kpi"><div class="kpi-lbl">Total Ingresos</div><div class="kpi-val pos">${fmtC(tI)}</div></div>
    <div class="kpi"><div class="kpi-lbl">Total Costos</div><div class="kpi-val neg">${fmtC(tC)}</div></div>
  </div>
  <div class="card-np"><div class="tw"><table class="tbl-fija may-res">
    <colgroup><col style="width:28px"><col style="width:92px"><col><col style="width:130px"><col style="width:130px"><col style="width:140px"></colgroup>
    <thead><tr><th></th><th class="tl">CÓDIGO</th><th class="tl">CUENTA</th><th>DEBE</th><th>HABER</th><th>SALDO</th></tr></thead><tbody>`;
  keys.forEach(cd=>{
    const a=M[cd];
    tD+=a.debe;tH+=a.haber;
    const abierta=MAY_EXP.has(cd);
    h+=`<tr class="may-cta${abierta?' open':''}" data-cd="${cd}" onclick="toggleMayorCuenta('${cd}')" style="cursor:pointer">
      <td class="may-chev" style="text-align:center;color:var(--mt)">${abierta?'▾':'▸'}</td>
      <td class="tl" style="font-family:var(--mono);font-size:11px">${cd}</td>
      <td class="cel-trunc" title="${attr(a.nm)}" style="font-weight:600">${a.nm}</td>
      <td>${a.debe?fmtC(a.debe):'–'}</td>
      <td>${a.haber?fmtC(a.haber):'–'}</td>
      <td style="font-weight:700;color:${a.saldo>=0?'var(--ach)':'var(--err)'}">${fmtC(Math.abs(a.saldo))}</td>
    </tr>`;
    if(abierta)h+=filaDetalleMayor(cd);
  });
  h+=`</tbody><tfoot><tr><td></td><td class="tl" colspan="2">TOTALES</td><td>${fmtC(tD)}</td><td>${fmtC(tH)}</td><td></td></tr></tfoot></table></div></div>`;
  box.innerHTML=h;
}

// Fila con el detalle de una cuenta. Se genera sólo cuando se expande.
function filaDetalleMayor(cd){
  const a=MAY_M[cd];if(!a)return'';
  const hayPeriodo=!!(MAY_F.desde||MAY_F.hasta);
  const filaAnt=hayPeriodo
    ? `<tr style="background:var(--sf2)"><td class="tl" style="font-family:var(--mono);font-size:10px">—</td><td class="cel-trunc" style="font-style:italic;color:var(--mt)">Saldo anterior al ${MAY_F.desde||'inicio'}</td><td>–</td><td>–</td><td style="font-weight:600">${fmtC(Math.abs(a.saldoAnterior))}</td></tr>`
    : '';
  const movs=a.movs.map(m=>{
    const extra=descAporta(m.glosa,m.desc)?` — ${m.desc}`:'';
    const txt=(m.glosa||'')+extra;
    return `<tr><td class="tl" style="font-family:var(--mono);font-size:10px">${m.fecha}</td><td class="cel-trunc" title="${attr(txt)}"><span style="font-family:var(--mono);color:var(--mt);font-size:10px;margin-right:6px">N°${m.n}</span>${m.glosa||''}${extra?`<span style="color:var(--mt)">${extra}</span>`:''}</td><td>${m.debe?fmtC(m.debe):'–'}</td><td>${m.haber?fmtC(m.haber):'–'}</td><td style="font-weight:600">${fmtC(Math.abs(m.saldo))}</td></tr>`;
  }).join('')||`<tr><td colspan="5" style="text-align:center;color:var(--mt);padding:10px">Sin movimientos en el periodo</td></tr>`;
  return `<tr class="may-det" data-det="${cd}"><td colspan="6" style="padding:0 0 10px 28px;background:var(--sf2)">
    <table class="tbl-fija" style="font-size:11px">
      <colgroup><col style="width:92px"><col><col style="width:118px"><col style="width:118px"><col style="width:126px"></colgroup>
      <thead><tr><th class="tl">FECHA</th><th class="tl">GLOSA</th><th>DEBE</th><th>HABER</th><th>SALDO</th></tr></thead>
      <tbody>${filaAnt}${movs}</tbody>
    </table></td></tr>`;
}

// Expande/colapsa una cuenta sin volver a calcular ni redibujar el Mayor
function toggleMayorCuenta(cd){
  const fila=document.querySelector(`#mayor-tabla tr.may-cta[data-cd="${cd}"]`);
  if(!fila)return;
  const det=document.querySelector(`#mayor-tabla tr.may-det[data-det="${cd}"]`);
  const chev=fila.querySelector('.may-chev');
  if(det){
    det.remove();MAY_EXP.delete(cd);fila.classList.remove('open');
    if(chev)chev.textContent='▸';
  }else{
    fila.insertAdjacentHTML('afterend',filaDetalleMayor(cd));
    MAY_EXP.add(cd);fila.classList.add('open');
    if(chev)chev.textContent='▾';
  }
}

// ── Exportar Libro Mayor a Excel (respeta los filtros activos) ──
// Genera dos hojas: "Mayor" con el detalle línea a línea y "Resumen" con los
// saldos por cuenta (formato balance de comprobación).
function exportarMayorExcel(){
  try{
    if(typeof XLSX==='undefined'){toast('⚠️ Biblioteca Excel no cargada (¿sin internet?)','e');return;}
    const M=buildMayor(MAY_F.desde,MAY_F.hasta);
    const keys=cuentasMayorFiltradas(M);
    if(!keys.length){toast('⚠️ No hay cuentas que exportar con el filtro actual','e');return;}
    const hayPeriodo=!!(MAY_F.desde||MAY_F.hasta);

    const hdr=['CÓDIGO','CUENTA','N°','FECHA','GLOSA','DESCRIPCIÓN','DEBE','HABER','SALDO'];
    const rows=[];
    keys.forEach(cd=>{
      const a=M[cd];
      if(hayPeriodo)rows.push([cd,a.nm,'','','Saldo anterior','',0,0,Math.round(a.saldoAnterior)]);
      a.movs.forEach(m=>rows.push([cd,a.nm,m.n,m.fecha,m.glosa||'',m.desc||'',
        Math.round(m.debe||0),Math.round(m.haber||0),Math.round(m.saldo)]));
      rows.push([cd,a.nm,'','','TOTAL CUENTA','',Math.round(a.debe),Math.round(a.haber),Math.round(a.saldo)]);
    });
    const ws=XLSX.utils.aoa_to_sheet([hdr,...rows]);
    ws['!cols']=anchosXLSX(hdr,rows);
    const wb=XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb,ws,'Mayor');

    // Hoja resumen — balance de comprobación y saldos
    const rHdr=['CÓDIGO','CUENTA','SALDO ANTERIOR','DEBE','HABER','SALDO FINAL','MOVIMIENTOS'];
    let sAnt=0,sD=0,sH=0,sF=0;
    const rRows=keys.map(cd=>{
      const a=M[cd];
      sAnt+=a.saldoAnterior;sD+=a.debe;sH+=a.haber;sF+=a.saldo;
      return [cd,a.nm,Math.round(a.saldoAnterior),Math.round(a.debe),Math.round(a.haber),Math.round(a.saldo),a.movs.length];
    });
    rRows.push(['','TOTALES',Math.round(sAnt),Math.round(sD),Math.round(sH),Math.round(sF),'']);
    const wsr=XLSX.utils.aoa_to_sheet([rHdr,...rRows]);
    wsr['!cols']=anchosXLSX(rHdr,rRows);
    XLSX.utils.book_append_sheet(wb,wsr,'Resumen');

    const meta=[
      ['LIBRO MAYOR'],
      ['Empresa',S.empresa.nombre||''],
      ['RUT',S.empresa.rut||''],
      ['Giro',S.empresa.giro||''],
      ['Periodo',etiquetaPeriodo(MAY_F)],
      ['Búsqueda',MAY_F.q||'(sin filtro de texto)'],
      ['Cuentas',keys.length],
      ['Total Debe',Math.round(sD)],
      ['Total Haber',Math.round(sH)],
      ['Diferencia',Math.round(sD-sH)],
      ['Generado',new Date().toLocaleString('es-CL')],
    ];
    const wsm=XLSX.utils.aoa_to_sheet(meta);
    wsm['!cols']=[{wch:16},{wch:46}];
    XLSX.utils.book_append_sheet(wb,wsm,'Datos');

    XLSX.writeFile(wb,nombreArchivoExport('libro_mayor',MAY_F));
    toast(`✅ Libro Mayor exportado — ${keys.length} cuenta${keys.length===1?'':'s'}, ${rows.length} líneas`);
  }catch(e){toast('❌ Error al exportar: '+e.message,'e');}
}

// ═══ BALANCE ═══
// ═══ SIGNO DE PRESENTACIÓN ═══
//
// buildMayor guarda `saldo = debe − haber`. Con esa convención:
//   · activo (1) y costo (3) — naturaleza deudora  → saldo POSITIVO
//   · pasivo/patrimonio (2) e ingreso (4) — acreedora → saldo NEGATIVO
//
// Para presentarlos en un informe hay que INVERTIR el signo de las acreedoras,
// nunca tomar su valor absoluto.
//
// Por qué importa: con Math.abs, una cuenta de activo con saldo acreedor
// (un banco sobregirado, por ejemplo) se muestra SUMANDO en vez de restando, y
// el balance descuadra exactamente en el doble de ese saldo. Fue justo lo que
// pasó con "1101202 BANCO DE CHILE 04": saldo acreedor de $182.311.185 que
// aparecía como activo positivo y descuadraba el balance en $364.622.370.
const naturalezaAcreedora=cd=>String(cd).startsWith('2')||String(cd).startsWith('4');
const saldoPres=(cd,saldo)=>naturalezaAcreedora(cd)?-saldo:saldo;
const sumaPres=(M,keys)=>keys.reduce((s,k)=>s+saldoPres(k,M[k].saldo),0);

// Cuentas correctoras de activo: restan del activo por diseño, así que su
// saldo acreedor es NORMAL y no debe alertarse.
//  - Depreciación/amortización acumulada: grupo 12 con 5º dígito '2' (1201202)
//  - Estimación de incobrables: subgrupo 1105 (1105001)
const esCorrectoraActivo=cd=>(cd.startsWith('12')&&cd[4]==='2')||cd.startsWith('1105');

// Una cuenta "invertida" es la que quedó con saldo contrario a su naturaleza
// sin ser correctora. Casi siempre es un dato mal cargado —pagos desde un banco
// sin depósitos registrados, un proveedor sobrepagado— y conviene avisarlo.
function saldosInvertidos(M){
  return Object.keys(M).filter(cd=>{
    if(cd.length!==7)return false;
    const v=saldoPres(cd,M[cd].saldo);
    if(v>=-0.5)return false;
    return !(cd.startsWith('1')&&esCorrectoraActivo(cd));
  }).sort();
}

async function renderBalance(){
  const M=buildMayor();
  // Agrupación dinámica: recorre todas las cuentas imputables con saldo y las clasifica por prefijo.
  // Activos: 11 (corriente) / 12 (no corriente). Pasivos: 21 (corriente) / 22 (no corriente). Patrimonio: 23.
  // El resultado del ejercicio (ingresos 04 − costos 03) se calcula aparte y se suma al patrimonio.
  const grpPrefijo=(pref,title)=>{
    let tot=0;
    const cds=Object.keys(M).filter(cd=>cd.length===7&&pref.some(p=>cd.startsWith(p))&&Math.abs(M[cd].saldo)>=0.5)
      .sort();
    const rows=cds.map(cd=>{
      // Signo de presentación: nunca valor absoluto (ver nota arriba)
      const v=saldoPres(cd,M[cd].saldo);
      tot+=v;
      const correctora=cd.startsWith('1')&&esCorrectoraActivo(cd);
      const invertida=v<0&&!correctora;
      const marca=correctora?' <span style="color:var(--mt);font-size:10px">(−)</span>'
        :invertida?` <span style="color:var(--warn);font-size:10px" title="Saldo contrario a la naturaleza de la cuenta — revísala">⚠</span>`:'';
      const color=v<0?'color:var(--err)':'';
      const txt=v<0?'('+fmt(Math.abs(v))+')':(fmt(v)||'–');
      return`<tr><td class="tl" style="padding-left:16px;font-size:12px"><span style="font-family:var(--mono);font-size:10px;color:var(--mt)">${cd}</span> ${M[cd].nm||pdcNm(cd)}${marca}</td><td style="font-family:var(--mono);${color}">${txt}</td></tr>`;
    }).join('')||`<tr><td class="tl" style="padding-left:16px;font-size:11px;color:var(--mt)">Sin movimientos</td><td>–</td></tr>`;
    return{h:`<tr class="rth"><td colspan="2" class="tl" style="padding:8px 10px">${title}</td></tr>${rows}`,tot};
  };
  const gAC=grpPrefijo(['11'],'ACTIVOS CORRIENTES');
  const gAF=grpPrefijo(['12'],'ACTIVOS NO CORRIENTES');
  const gPC=grpPrefijo(['21'],'PASIVOS CORRIENTES');
  const gPNC=grpPrefijo(['22'],'PASIVOS NO CORRIENTES');
  // Patrimonio: cuentas del prefijo 23 (capital, revalorización, resultados acumulados)
  const gPat=grpPrefijo(['23'],'PATRIMONIO');
  const tI=sumaPres(M,Object.keys(M).filter(k=>k.startsWith('4')));
  const tC=sumaPres(M,Object.keys(M).filter(k=>k.startsWith('3')));
  const res=tI-tC;
  const totAct=gAC.tot+gAF.tot;
  const totPas=gPC.tot+gPNC.tot;
  const totPat=gPat.tot+res; // patrimonio contable + resultado del ejercicio corriente
  const totPasYPat=totPas+totPat;
  const ok=Math.abs(totAct-totPasYPat)<2;
  const invertidas=saldosInvertidos(M);
  document.getElementById('balance-content').innerHTML=`<div class="card">
    <div style="text-align:center;margin-bottom:18px">
      <div style="font-size:15px;font-weight:700">${S.empresa.nombre||'(sin empresa)'}</div>
      <div style="color:var(--mt);font-size:12px;margin-top:3px">Balance General al 31 de Diciembre de ${S.empresa.anio}</div>
    </div>
    <div class="bal-layout">
      <div>
        <div class="card-title">ACTIVOS</div>
        <table class="report-money-table balance-money-table"><colgroup><col class="report-col-desc"><col class="report-col-money"></colgroup><tbody>
          ${gAC.h}<tr class="rtot"><td class="tl" style="padding:8px 10px;font-size:11px">Total Activos Corrientes</td><td style="font-family:var(--mono)">${fmtC(gAC.tot)}</td></tr>
          ${gAF.h}<tr class="rtot"><td class="tl" style="padding:8px 10px;font-size:11px">Total Activos No Corrientes</td><td style="font-family:var(--mono)">${fmtC(gAF.tot)}</td></tr>
          <tr style="background:rgba(46,160,67,.12)"><td class="tl" style="padding:10px;font-weight:700;font-size:13px">TOTAL ACTIVOS</td><td style="font-family:var(--mono);font-weight:700;font-size:13px;color:var(--ach)">${fmtC(totAct)}</td></tr>
        </tbody></table>
      </div>
      <div>
        <div class="card-title">PASIVOS Y PATRIMONIO</div>
        <table class="report-money-table balance-money-table"><colgroup><col class="report-col-desc"><col class="report-col-money"></colgroup><tbody>
          ${gPC.h}<tr class="rtot"><td class="tl" style="padding:8px 10px;font-size:11px">Total Pasivos Corrientes</td><td style="font-family:var(--mono)">${fmtC(gPC.tot)}</td></tr>
          ${gPNC.h}<tr class="rtot"><td class="tl" style="padding:8px 10px;font-size:11px">Total Pasivos No Corrientes</td><td style="font-family:var(--mono)">${fmtC(gPNC.tot)}</td></tr>
          <tr class="rtot" style="background:rgba(248,81,73,.08)"><td class="tl" style="padding:8px 10px;font-size:11px">Total Pasivos</td><td style="font-family:var(--mono)">${fmtC(totPas)}</td></tr>
          ${gPat.h}
          <tr><td class="tl" style="padding-left:16px;font-size:12px">Resultado del Ejercicio</td><td style="font-family:var(--mono);color:${res>=0?'var(--ach)':'var(--err)'}">${fmtC(res)}</td></tr>
          <tr class="rtot"><td class="tl" style="padding:8px 10px;font-size:11px">Total Patrimonio</td><td style="font-family:var(--mono)">${fmtC(totPat)}</td></tr>
          <tr style="background:rgba(46,160,67,.12)"><td class="tl" style="padding:10px;font-weight:700;font-size:13px">TOTAL PASIVOS + PATRIMONIO</td><td style="font-family:var(--mono);font-weight:700;font-size:13px;color:var(--ach)">${fmtC(totPasYPat)}</td></tr>
        </tbody></table>
      </div>
    </div>
    <div style="margin-top:12px;font-size:12px;color:${ok?'var(--ach)':'var(--warn)'}">${ok?'✅ Balance cuadrado':'⚠️ Diferencia: '+fmtC(Math.abs(totAct-totPasYPat))}</div>
    ${invertidas.length?`<div class="info-tip" style="margin-top:10px;font-size:11px;line-height:1.6;border-color:var(--warn)">
      ⚠️ <strong>${invertidas.length===1?'Una cuenta tiene':`${invertidas.length} cuentas tienen`} saldo contrario a su naturaleza</strong>
      y en el balance ${invertidas.length===1?'aparece restando':'aparecen restando'}, entre paréntesis:
      <div style="margin-top:6px">${invertidas.map(cd=>`<div style="font-family:var(--mono);font-size:11px">${cd} ${M[cd].nm||pdcNm(cd)} — ${fmtC(Math.abs(saldoPres(cd,M[cd].saldo)))} ${String(cd).startsWith('1')?'acreedor':'deudor'}</div>`).join('')}</div>
      <div style="margin-top:6px">
        El balance cuadra igual, pero esto casi siempre es un dato pendiente: un banco del que se
        pagó sin registrar los depósitos o la apertura, un proveedor sobrepagado, un cliente con
        notas de crédito de más. Revisa el auxiliar o el mayor de esas cuentas.
      </div>
    </div>`:''}
  </div>`;
  poblarCmpSelect('cmp-year-bal');
  if(CMP_YEAR)await renderComparativo('balance-content','balance');
}

// Poblar selector de años a comparar (todos menos el actual)
function poblarCmpSelect(id){
  const sel=document.getElementById(id);if(!sel)return;
  const actual=S.empresa.anio;
  const cy=new Date().getFullYear();
  const años=[];for(let y=cy+1;y>=cy-6;y--){if(y!==actual)años.push(y);}
  sel.innerHTML='<option value="">— sin comparar —</option>'+años.map(y=>`<option value="${y}" ${CMP_YEAR==y?'selected':''}>${y}</option>`).join('');
}
async function onCmpYear(v){
  CMP_YEAR=v?+v:null;
  // Sincronizar ambos selects
  ['cmp-year-bal','cmp-year-res'].forEach(id=>{const s=document.getElementById(id);if(s)s.value=v||'';});
  // Re-render de la sección activa
  const activa=document.querySelector('.section.active')?.id||'';
  if(activa==='s-balance')await renderBalance();
  else if(activa==='s-resultados')await renderResultados();
}
// Panel comparativo Actual vs Anterior con variación %
async function renderComparativo(targetId,tipo){
  const cont=document.getElementById(targetId);if(!cont)return;
  const actual=S.empresa.anio;
  const Mact=buildMayor();
  let Mant;
  try{Mant=await buildMayorAnio(CMP_YEAR);}catch(e){Mant={};}
  const tA=totalesDeMayor(Mact),tB=totalesDeMayor(Mant);
  const resA=tA.ingresos-tA.costos,resB=tB.ingresos-tB.costos;
  // Filas según tipo de reporte
  let filas;
  if(tipo==='resultados'){
    filas=[
      ['Ingresos de explotación',tA.ingresos,tB.ingresos],
      ['Costos y gastos',tA.costos,tB.costos],
      ['Resultado del ejercicio',resA,resB],
    ];
  }else{
    filas=[
      ['Total activos',tA.activos,tB.activos],
      ['Total pasivos',tA.pasivos,tB.pasivos],
      ['Capital',tA.capital,tB.capital],
      ['Resultado del ejercicio',resA,resB],
    ];
  }
  const rows=filas.map(([lbl,a,b])=>{
    const v=fmtVar(a,b);
    return `<tr${v.sig?' style="background:rgba(210,153,34,.08)"':''}>
      <td class="tl" style="font-size:12px">${v.sig?'⚡ ':''}${lbl}</td>
      <td style="text-align:right;font-family:var(--mono)">${fmtC(a)}</td>
      <td style="text-align:right;font-family:var(--mono);color:var(--mt)">${fmtC(b)}</td>
      <td style="text-align:right;font-family:var(--mono);font-weight:600;color:${v.color}">${v.txt}</td>
    </tr>`;
  }).join('');
  const panel=`<div class="card" style="margin-bottom:16px;border-color:var(--info)">
    <div style="font-size:13px;font-weight:700;margin-bottom:10px">📊 Comparativo ${actual} vs ${CMP_YEAR}</div>
    <table style="font-size:12px"><thead><tr>
      <th class="tl">CONCEPTO</th><th style="text-align:right">${actual}</th><th style="text-align:right">${CMP_YEAR}</th><th style="text-align:right">VAR. %</th>
    </tr></thead><tbody>${rows}</tbody></table>
    <div style="margin-top:8px;font-size:10px;color:var(--mt)">⚡ Variación significativa (≥20%). Variación positiva en verde, negativa en rojo — el signo es aritmético (no implica mejora o empeoramiento según la naturaleza de la cuenta).</div>
  </div>`;
  cont.insertAdjacentHTML('afterbegin',panel);
}

// ═══ RESULTADOS ═══
async function renderResultados(){
  const M=buildMayor();
  // Suma el saldo (valor absoluto) de todas las cuentas imputables cuyo código empieza con un prefijo dado
  const sumaPref=pref=>sumaPres(M,Object.keys(M).filter(k=>k.length===7&&k.startsWith(pref)&&Math.abs(M[k].saldo)>=0.5));
  // Filas de detalle por prefijo (cuentas con saldo)
  const detallePref=pref=>Object.keys(M).filter(k=>k.length===7&&k.startsWith(pref)&&Math.abs(M[k].saldo)>=0.5).sort()
    .map(k=>`<tr><td class="tl" style="padding:5px 6px 5px 34px;font-size:11px;color:var(--mt)"><span style="font-family:var(--mono);font-size:10px">${k}</span> ${M[k].nm||pdcNm(k)}</td><td style="font-family:var(--mono);font-size:11px;color:var(--mt)">${fmtC(saldoPres(k,M[k].saldo))}</td></tr>`).join('');

  // Niveles del EERR
  const ingExp=sumaPref('41');   // Ingresos de explotación
  const costoExp=sumaPref('31'); // Costo de explotación
  const margenBruto=ingExp-costoExp;

  const gastosOp=sumaPref('32');   // Gastos operacionales (admin y ventas)
  const otrosGastosOp=sumaPref('33'); // Otros gastos operacionales
  const resultadoOp=margenBruto-gastosOp-otrosGastosOp;

  const ingFuera=sumaPref('42');   // Ingresos fuera de explotación
  const ingFinanc=sumaPref('43');  // Ingresos financieros
  const gastosNoOp=sumaPref('34'); // Gastos no operacionales
  const correccMon=sumaPref('35'); // Corrección monetaria
  const resAntesImp=resultadoOp+ingFuera+ingFinanc-gastosNoOp-correccMon;

  // Impuesto a la renta: si hay cuenta contabilizada (36) se usa; si no, se estima con tasa del régimen
  const impContab=sumaPref('36');
  // 0 es una tasa válida (14 D N°8). Además se protege a las empresas que
  // pudieron quedar históricamente guardadas con 25 por el antiguo `0 || 25`.
  const regimen=S.empresa.regimen||'14D3';
  const tasaGuardada=S.empresa.tasaRenta!=null?+S.empresa.tasaRenta:null;
  const TASA_RENTA=(regimen==='14D8'?0:(tasaGuardada!=null?tasaGuardada:tasaIDPC(regimen,S.empresa.anio)))/100;
  const impEstimado=resAntesImp>0?Math.round(resAntesImp*TASA_RENTA):0;
  const usaEstimado=impContab<0.5&&resAntesImp>0;
  const impuesto=impContab>=0.5?impContab:impEstimado;
  const utilidadNeta=resAntesImp-impuesto;

  // Helper para renderizar una línea de nivel con detalle expandible
  let idc=0;
  const nivel=(lbl,valor,pref,opts={})=>{
    idc++;const id='eerr-d'+idc;
    const det=pref?detallePref(pref):'';
    const tieneDet=det.length>0;
    const signo=opts.resta?'−':(opts.suma?'+':'');
    const color=opts.color||'var(--tx)';
    return `<tr class="${tieneDet?'rth':''}" style="cursor:${tieneDet?'pointer':'default'}" ${tieneDet?`onclick="toggleAgingDetalle('${id}')"`:''}>
        <td class="tl" style="padding:7px 12px;font-size:12px">${tieneDet?'▸ ':''}${signo?`<span style="color:var(--mt)">${signo}</span> `:''}${lbl}</td>
        <td style="font-family:var(--mono);color:${color}">${fmtC(valor)}</td>
      </tr>${tieneDet?`<tr><td colspan="2" style="padding:0"><div class="aux-body" id="${id}"><table style="width:100%"><tbody>${det}</tbody></table></div></td></tr>`:''}`;
  };
  const subtotal=(lbl,valor,fuerte)=>`<tr class="rtot" style="${fuerte?'background:rgba(88,166,255,.10)':''}">
      <td class="tl" style="padding:9px 12px;font-weight:700;font-size:${fuerte?'13':'12'}px">${lbl}</td>
      <td style="font-family:var(--mono);font-weight:700;color:${valor>=0?'var(--ach)':'var(--err)'};font-size:${fuerte?'13':'12'}px">${fmtC(valor)}</td>
    </tr>`;
  const espacio=`<tr><td colspan="2" style="height:6px;border:none"></td></tr>`;

  // Aviso de gasto sin costear. El EERR es donde se mira el gasto, así que es
  // el lugar natural para enterarse de que una parte no está llegando a ningún
  // centro de costo — y para ir a repararlo de un clic.
  let avisoCC='';
  try{
    const p=pendientesCC();
    if(p.n){
      avisoCC=`<div class="eerr-aviso no-print">
        <span style="font-size:16px">🎯</span>
        <span><strong>${p.n} movimiento${p.n===1?'':'s'} de gasto por ${fmtC(p.monto)}</strong>
        no tiene${p.n===1?'':'n'} centro de costo, así que no suma${p.n===1?'':'n'} en el costo del predio ni del cuartel.</span>
        <button class="btn btn-g" style="margin-left:auto;font-size:11px" onclick="nav('asigcc')">Asignar centros</button>
      </div>`;
    }
  }catch(e){}

  document.getElementById('resultados-content').innerHTML=avisoCC+`<div class="card" style="max-width:720px">
    <div style="text-align:center;margin-bottom:22px">
      <div style="font-size:16px;font-weight:700">${S.empresa.nombre||'(sin empresa)'}</div>
      <div style="color:var(--mt);font-size:12px;margin-top:3px">Estado de Resultados — Año ${S.empresa.anio}</div>
      <div style="color:var(--mt);font-size:11px;margin-top:2px">Régimen 14 D N°3 Pro-Pyme General</div>
    </div>
    <table class="report-money-table eerr-money-table"><colgroup><col class="report-col-desc"><col class="report-col-money"></colgroup><tbody>
      ${nivel('Ingresos de explotación',ingExp,'41',{color:'var(--ach)'})}
      ${nivel('Costo de explotación',costoExp,'31',{resta:true,color:'var(--err)'})}
      ${subtotal('= MARGEN BRUTO',margenBruto)}
      ${espacio}
      ${nivel('Gastos de administración y ventas',gastosOp,'32',{resta:true,color:'var(--err)'})}
      ${nivel('Otros gastos operacionales',otrosGastosOp,'33',{resta:true,color:'var(--err)'})}
      ${subtotal('= RESULTADO OPERACIONAL',resultadoOp)}
      ${espacio}
      ${nivel('Ingresos fuera de explotación',ingFuera,'42',{suma:true,color:'var(--ach)'})}
      ${nivel('Ingresos financieros',ingFinanc,'43',{suma:true,color:'var(--ach)'})}
      ${nivel('Gastos no operacionales',gastosNoOp,'34',{resta:true,color:'var(--err)'})}
      ${nivel('Corrección monetaria',correccMon,'35',{resta:true,color:'var(--err)'})}
      ${subtotal('= RESULTADO ANTES DE IMPUESTO',resAntesImp)}
      ${espacio}
      <tr>
        <td class="tl" style="padding:7px 12px;font-size:12px"><span style="color:var(--mt)">−</span> Impuesto a la renta (${(TASA_RENTA*100).toFixed(1)}%)${usaEstimado?' <span style="color:var(--warn);font-size:10px">estimado</span>':''}</td>
        <td style="font-family:var(--mono);color:var(--err)">${fmtC(impuesto)}</td>
      </tr>
      ${espacio}
      <tr style="background:${utilidadNeta>=0?'rgba(46,160,67,.14)':'rgba(248,81,73,.14)'}">
        <td class="tl" style="padding:13px 12px;font-size:15px;font-weight:700">UTILIDAD NETA DEL EJERCICIO</td>
        <td style="font-family:var(--mono);font-size:15px;font-weight:700;color:${utilidadNeta>=0?'var(--ach)':'var(--err)'}">${fmtC(utilidadNeta)}</td>
      </tr>
    </tbody></table>
    ${usaEstimado?`<div class="info-tip" style="margin-top:14px;font-size:11px">ℹ️ El impuesto a la renta es una <strong>estimación</strong> (${(TASA_RENTA*100).toFixed(1)}% sobre el resultado antes de impuesto). No hay cuenta del grupo 36 contabilizada. Puedes cambiar la tasa en Empresa → Configuración tributaria.</div>`:''}
    <div style="margin-top:12px;font-size:12px;color:var(--mt);display:flex;gap:16px;flex-wrap:wrap">
      <span>Margen bruto: <strong style="color:var(--tx)">${ingExp>0?(margenBruto/ingExp*100).toFixed(1):'0'}%</strong></span>
      <span>Margen operacional: <strong style="color:var(--tx)">${ingExp>0?(resultadoOp/ingExp*100).toFixed(1):'0'}%</strong></span>
      <span>Margen neto: <strong style="color:var(--tx)">${ingExp>0?(utilidadNeta/ingExp*100).toFixed(1):'0'}%</strong></span>
    </div>
  </div>`;
  poblarCmpSelect('cmp-year-res');
  if(CMP_YEAR)await renderComparativo('resultados-content','resultados');
}


// ═══ BALANCE TABULAR DE 8 COLUMNAS (hoja de trabajo, tipo IFRS) ═══
// Por cada cuenta imputable: Sumas (Debe/Haber), Saldos (Deudor/Acreedor),
// Balance (Activo/Pasivo+Patrimonio) y Resultado (Pérdida/Ganancia). El
// resultado del ejercicio cuadra ambos pares finales.
function calcularBalance8(){
  const M=buildMayor();
  const filas=[];
  const T={sd:0,sh:0,dd:0,da:0,act:0,pas:0,per:0,gan:0};
  Object.keys(M).filter(cd=>cd.length===7&&(Math.abs(M[cd].debe)>=0.5||Math.abs(M[cd].haber)>=0.5))
    .sort().forEach(cd=>{
      const debe=M[cd].debe, haber=M[cd].haber, saldo=debe-haber;
      const deudor=saldo>0?saldo:0, acreedor=saldo<0?-saldo:0;
      const esResultado=cd.startsWith('3')||cd.startsWith('4');
      const act=(!esResultado)?deudor:0, pas=(!esResultado)?acreedor:0;
      const per=esResultado?deudor:0, gan=esResultado?acreedor:0;
      filas.push({cd,nm:M[cd].nm||pdcNm(cd),debe,haber,deudor,acreedor,act,pas,per,gan});
      T.sd+=debe;T.sh+=haber;T.dd+=deudor;T.da+=acreedor;T.act+=act;T.pas+=pas;T.per+=per;T.gan+=gan;
    });
  // Resultado del ejercicio: cuadra Pérdida/Ganancia y Activo/Pasivo.
  const resultado=T.gan-T.per;   // >0 utilidad · <0 pérdida
  return {filas,T,resultado};
}

async function renderBalance8(){
  const cont=document.getElementById('balance8-content');
  if(!cont)return;
  const {filas,T,resultado}=calcularBalance8();
  const num=v=>v?fmt(Math.round(v)):'–';
  if(!filas.length){cont.innerHTML=`<div class="empty"><div class="ei">📋</div>No hay movimientos para armar el balance tabular.</div>`;return;}

  const rows=filas.map(f=>`<tr>
    <td class="tl" style="font-family:var(--mono);font-size:10px;color:var(--mt)">${f.cd}</td>
    <td class="tl" style="font-size:11px">${f.nm}</td>
    <td class="c-num">${num(f.debe)}</td><td class="c-num">${num(f.haber)}</td>
    <td class="c-num">${num(f.deudor)}</td><td class="c-num">${num(f.acreedor)}</td>
    <td class="c-num">${num(f.act)}</td><td class="c-num">${num(f.pas)}</td>
    <td class="c-num">${num(f.per)}</td><td class="c-num">${num(f.gan)}</td>
  </tr>`).join('');

  // Fila del resultado del ejercicio (cuadra los dos últimos pares).
  // La UTILIDAD cierra las cuentas de resultado por el DEBE (columna Pérdida) y
  // aumenta el patrimonio (columna Pasivo). La PÉRDIDA hace lo inverso.
  // Orden de las 4 últimas columnas: Activo · Pasivo · Pérdida · Ganancia.
  const utilidad=resultado>=0, p=Math.abs(resultado);
  const resRow=`<tr style="background:rgba(88,166,255,.06);font-weight:600">
    <td class="tl" colspan="6" style="text-align:right;padding-right:10px">${utilidad?'Utilidad del ejercicio':'Pérdida del ejercicio'}</td>
    <td class="c-num">${utilidad?'–':num(p)}</td>
    <td class="c-num">${utilidad?num(p):'–'}</td>
    <td class="c-num">${utilidad?num(p):'–'}</td>
    <td class="c-num">${utilidad?'–':num(p)}</td>
  </tr>`;
  // Totales finales (ya cuadrados con el resultado)
  const actF=T.act+(utilidad?0:p), pasF=T.pas+(utilidad?p:0);
  const perF=T.per+(utilidad?p:0), ganF=T.gan+(utilidad?0:p);
  const cuadra=Math.abs(T.sd-T.sh)<2&&Math.abs(T.dd-T.da)<2&&Math.abs(actF-pasF)<2&&Math.abs(perF-ganF)<2;
  const totRow=`<tr class="rtot" style="font-weight:700;background:var(--sf2)">
    <td class="tl" colspan="2" style="padding:8px 10px">TOTALES</td>
    <td class="c-num">${num(T.sd)}</td><td class="c-num">${num(T.sh)}</td>
    <td class="c-num">${num(T.dd)}</td><td class="c-num">${num(T.da)}</td>
    <td class="c-num">${num(actF)}</td><td class="c-num">${num(pasF)}</td>
    <td class="c-num">${num(perF)}</td><td class="c-num">${num(ganF)}</td>
  </tr>`;

  cont.innerHTML=`
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px">
      <div style="font-size:12px;color:var(--mt)">Hoja de trabajo · Balance de 8 columnas · Ejercicio ${S.empresa.anio}</div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-g" onclick="window.print()">🖨️ Imprimir</button>
        <button class="btn btn-g" onclick="exportarBalance8Excel()">📊 Excel</button>
      </div>
    </div>
    <div class="card-np"><div class="tw"><table class="tbl-bal8" style="font-size:11px">
      <thead>
        <tr>
          <th rowspan="2" class="tl">CÓD</th><th rowspan="2" class="tl">CUENTA</th>
          <th colspan="2" style="text-align:center">SUMAS</th>
          <th colspan="2" style="text-align:center">SALDOS</th>
          <th colspan="2" style="text-align:center">BALANCE (INVENTARIO)</th>
          <th colspan="2" style="text-align:center">RESULTADO (P y G)</th>
        </tr>
        <tr>
          <th class="c-num">Debe</th><th class="c-num">Haber</th>
          <th class="c-num">Deudor</th><th class="c-num">Acreedor</th>
          <th class="c-num">Activo</th><th class="c-num">Pasivo</th>
          <th class="c-num">Pérdida</th><th class="c-num">Ganancia</th>
        </tr>
      </thead>
      <tbody>${rows}${resRow}</tbody>
      <tfoot>${totRow}</tfoot>
    </table></div></div>
    <div style="margin-top:10px;font-size:12px;color:${cuadra?'var(--ach)':'var(--warn)'}">
      ${cuadra?'✅ Balance tabular cuadrado':'⚠️ Revisa: alguna columna no cuadra'}
      <span style="color:var(--mt);margin-left:10px">Resultado del ejercicio: <strong style="color:${utilidad?'var(--ach)':'var(--err)'}">${fmtC(resultado)}</strong></span>
    </div>`;
}

function exportarBalance8Excel(){
  try{
    if(typeof XLSX==='undefined'){toast('⚠️ No se pudo cargar el generador de Excel','e');return;}
    const {filas,T,resultado}=calcularBalance8();
    const utilidad=resultado>=0, p=Math.abs(resultado);
    const rows=[];
    rows.push(['BALANCE DE 8 COLUMNAS (HOJA DE TRABAJO)']);
    rows.push([S.empresa.nombre||'', S.empresa.rut||'', 'Ejercicio', S.empresa.anio]);
    rows.push([]);
    rows.push(['Código','Cuenta','Debe','Haber','Deudor','Acreedor','Activo','Pasivo','Pérdida','Ganancia']);
    filas.forEach(f=>rows.push([f.cd,f.nm,f.debe,f.haber,f.deudor,f.acreedor,f.act,f.pas,f.per,f.gan]));
    rows.push(['', utilidad?'Utilidad del ejercicio':'Pérdida del ejercicio','','','','',
      utilidad?0:p, utilidad?p:0, utilidad?p:0, utilidad?0:p]);
    rows.push(['','TOTALES',T.sd,T.sh,T.dd,T.da,
      T.act+(utilidad?0:p), T.pas+(utilidad?p:0),
      T.per+(utilidad?p:0), T.gan+(utilidad?0:p)]);
    const ws=XLSX.utils.aoa_to_sheet(rows);
    ws['!cols']=[{wch:10},{wch:34},{wch:13},{wch:13},{wch:13},{wch:13},{wch:13},{wch:13},{wch:13},{wch:13}];
    const wb=XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb,ws,'Balance 8 columnas');
    XLSX.writeFile(wb,`balance_8_columnas_${S.empresa.anio}.xlsx`);
    toast('📊 Balance de 8 columnas exportado');
  }catch(e){toast('❌ No se pudo exportar: '+e.message,'e');}
}

export {genDiario, renderDiario, setDiarioQ, buildMayor, buildMayorAnio, totalesDeMayor, CMP_YEAR, fmtVar, renderMayor, renderBalance, renderBalance8, calcularBalance8, exportarBalance8Excel, poblarCmpSelect, onCmpYear, renderComparativo, renderResultados, corregirDesdeDiario, editarAsientoRef, destinoEdicion,
        onDiarioMes, setDiarioFecha, limpiarFiltrosDiario, exportarDiarioExcel,
        onMayorMes, setMayorFecha, setMayorQ, limpiarFiltrosMayor, renderMayorTabla, exportarMayorExcel, toggleMayorCuenta};
